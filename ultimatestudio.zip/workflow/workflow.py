"""
UltimateStudio
workflow/workflow.py

Drives a `Project` through every registered engine in order.

Compared to the original: the engine name list now matches what
engines actually register themselves as (several names here were
subtly wrong before -- e.g. "viralintelligence_engine" vs the real
"viral_intelligence_engine" -- so those stages were silently skipped
every single run instead of raising an error). The motif and video
stages (motif, storyboard, thumbnail, renderer) existed as working
code but were never in this list at all, so they never ran; they're
included now.
"""

from __future__ import annotations

import json
import time

from core.config import CONFIG_DIR
from core.logger import info, warning
from core.plugin_loader import plugin_loader
from core.registry import registry

STAGE_TIMING_FILE = CONFIG_DIR / "stage_timings.json"
SLOW_STAGE_MULTIPLIER = 4.0  # flag a stage if it takes >4x its own historical average
MIN_SAMPLES_BEFORE_FLAGGING = 3

PIPELINE: list[str] = [
    # AI direction
    "music_director_engine",
    "music_brain",
    # project setup
    "sample_loader",
    "composer",
    "composition_planner",
    "producer_brain",
    # real AI-generated song (only active when SETTINGS.music_mode == "ai";
    # a no-op otherwise). On success this makes every stage below --
    # up through master_engine -- redundant, so they're skipped.
    "ai_music_engine",
    # melody & musical identity
    "melody_engine",
    "motif_engine",
    "variation_engine",
    "velocity_engine",
    "swing_engine",
    "groove_engine",
    "humanizer_engine",
    # harmony
    "harmony_engine",
    "chord_voicing_engine",
    # instruments
    "piano_engine",
    "counter_melody_engine",
    "drum_engine",
    "bass_engine",
    "synth_engine",
    "atmosphere_engine",
    "fx_engine",
    # arrangement
    "transition_engine",
    "automation_engine",
    "structure_engine",
    "arrangement_engine",
    # mix & master
    "mixer_engine",
    "master_engine",
    # export
    "midi_exporter",
    "audio_exporter",
    # AI evaluation
    "genre_dna",
    "genre_fit_engine",
    "hit_engine",
    "learning_engine",
    # content & metadata
    "title_engine",
    "prompt_engine",
    "seo_engine",
    "viral_intelligence_engine",
    # video
    "storyboard_engine",
    "thumbnail_engine",
    "video_renderer",
]

# stages that produce/process locally-synthesized audio -- redundant
# once ai_music_engine has already produced a finished, mastered track.
# midi_exporter is also skipped: there's no note-level data for an
# externally generated song to export.
_SYNTHESIS_STAGES = {
    "melody_engine",
    "motif_engine",
    "variation_engine",
    "velocity_engine",
    "swing_engine",
    "groove_engine",
    "humanizer_engine",
    "harmony_engine",
    "chord_voicing_engine",
    "piano_engine",
    "counter_melody_engine",
    "drum_engine",
    "bass_engine",
    "synth_engine",
    "atmosphere_engine",
    "fx_engine",
    "transition_engine",
    "automation_engine",
    "mixer_engine",
    "master_engine",
    "midi_exporter",
    "audio_exporter",
}

# project keys worth a one-line sanity check after their stage runs
_CHECKS = {
    "composition_planner": lambda p: (
        f"COMPOSITION CHECK -> {len(p.get('composition_plan', {}).get('sections', []))} sections"
    ),
    "producer_brain": lambda p: (
        f"PRODUCER CHECK -> {len(p.get('producer_brain', {}).get('sections', []))} sections"
    ),
    "arrangement_engine": lambda p: f"ARRANGEMENT CHECK -> {len(p.get('arrangement', []))} sections",
    "master_engine": lambda p: f"MASTER EXISTS -> {'master_audio' in p}",
    "audio_exporter": lambda p: f"AUDIO FILE -> {p.get('audio_file')}",
    "midi_exporter": lambda p: f"MIDI FILE -> {p.get('midi_file')}",
}


class StageTimingTracker:
    """
    Rolling per-stage timing history, persisted to disk, so a stage
    that suddenly takes far longer than its own established baseline
    gets flagged automatically -- instead of relying on someone to
    notice a 7-minute mixer_engine call in a log and report it.
    """

    MAX_SAMPLES_PER_STAGE = 30

    def __init__(self):
        self.history = self._load()

    def _load(self) -> dict[str, list[float]]:
        if not STAGE_TIMING_FILE.exists():
            return {}
        try:
            return json.loads(STAGE_TIMING_FILE.read_text(encoding="utf8"))
        except (json.JSONDecodeError, OSError):
            return {}

    def _save(self) -> None:
        STAGE_TIMING_FILE.parent.mkdir(parents=True, exist_ok=True)
        try:
            STAGE_TIMING_FILE.write_text(json.dumps(self.history, indent=2), encoding="utf8")
        except OSError:
            pass

    def check_and_record(self, stage_name: str, duration_sec: float) -> None:
        samples = self.history.setdefault(stage_name, [])

        if len(samples) >= MIN_SAMPLES_BEFORE_FLAGGING:
            baseline = sum(samples) / len(samples)
            if baseline > 0.05 and duration_sec > baseline * SLOW_STAGE_MULTIPLIER:
                warning(
                    f"HEALTH -> '{stage_name}' took {duration_sec:.1f}s, "
                    f"~{duration_sec / baseline:.1f}x its usual {baseline:.1f}s average -- "
                    f"possible performance regression, worth investigating"
                )

        samples.append(duration_sec)
        if len(samples) > self.MAX_SAMPLES_PER_STAGE:
            del samples[: len(samples) - self.MAX_SAMPLES_PER_STAGE]

        self._save()


_timing_tracker = StageTimingTracker()


class Workflow:
    def run(self, project):
        plugin_loader.load()

        info(f"REGISTERED -> {registry.names()}")
        info("PIPELINE START")

        for engine_name in PIPELINE:
            if project.get("_ai_music_used") and engine_name in _SYNTHESIS_STAGES:
                info(f"SKIP -> {engine_name} (real AI-generated track already produced)")
                continue
            project = self.safe(engine_name, project)

        info("PIPELINE END")
        return project

    def safe(self, name: str, project):
        engine = registry.get(name)

        if engine is None:
            info(f"SKIP -> {name} (not registered)")
            return project

        try:
            t0 = time.time()
            project = engine.execute(project)
            duration = time.time() - t0

            _timing_tracker.check_and_record(name, duration)

            check = _CHECKS.get(name)
            if check is not None:
                info(check(project))

            info(f"OK -> {name} ({duration:.2f}s)")
            return project

        except Exception as exc:  # noqa: BLE001 - one bad stage shouldn't kill the run
            info(f"ERROR -> {name}: {exc}")
            return project


workflow = Workflow()
