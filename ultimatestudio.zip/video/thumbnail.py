"""
UltimateStudio
video/thumbnail.py
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from pathlib import Path

from core.pipeline import Module
from core.logger import info
from core.registry import registry


# ==========================================================
# THUMBNAIL
# ==========================================================

@dataclass(slots=True)
class Thumbnail:

    title: str

    prompt: str

    background: str

    style: str

    color: str

    text_color: str

    font: str


# ==========================================================
# ENGINE
# ==========================================================

class ThumbnailEngine(Module):

    NAME = "Thumbnail Engine"

    BACKGROUNDS = [

        "Cyberpunk City",

        "Dark Tunnel",

        "Neon Tokyo",

        "Destroyed Future",

        "Industrial Factory",

        "Sci-Fi Skyline",

        "Dark Forest",

        "Red Moon",

        "Rain Street",

        "Abandoned Metro"

    ]

    STYLES = [

        "Ultra Realistic",

        "Cinematic",

        "Hyper Detailed",

        "Concept Art",

        "Photorealistic",

        "Dark Fantasy"

    ]

    COLORS = [

        "Blue",

        "Red",

        "Purple",

        "Orange",

        "Cyan",

        "Green"

    ]

    FONTS = [

        "Bebas Neue",

        "Anton",

        "Montserrat ExtraBold",

        "Oswald",

        "League Spartan"

    ]

    # ======================================================

    def build(self, project):

        background = random.choice(self.BACKGROUNDS)

        style = random.choice(self.STYLES)

        color = random.choice(self.COLORS)

        font = random.choice(self.FONTS)

        prompt = (

            f"{background}, "

            f"{style}, "

            f"{project.genre}, "

            f"{project.mood}, "

            "Ultra realistic, "

            "8K, "

            "Highly detailed, "

            "Cinematic lighting"

        )

        return Thumbnail(

            title=project.title,

            prompt=prompt,

            background=background,

            style=style,

            color=color,

            text_color="White",

            font=font

        )

    # ======================================================

    def save_prompt(

        self,

        project,

        thumbnail

    ):

        png_path = Path(project.thumbnail_file)

        output = png_path.with_name(png_path.stem + "_prompt.txt")

        output.parent.mkdir(

            parents=True,

            exist_ok=True

        )

        with open(

            output,

            "w",

            encoding="utf8"

        ) as f:

            f.write(

                f"TITLE : {thumbnail.title}\n\n"

            )

            f.write(

                f"BACKGROUND : {thumbnail.background}\n"

            )

            f.write(

                f"STYLE : {thumbnail.style}\n"

            )

            f.write(

                f"COLOR : {thumbnail.color}\n"

            )

            f.write(

                f"FONT : {thumbnail.font}\n\n"

            )

            f.write(

                thumbnail.prompt

            )

        return output

    # ======================================================

    def execute(self, project):

        thumbnail = self.build(

            project

        )

        output = self.save_prompt(

            project,

            thumbnail

        )

        project.add_metadata(

            "thumbnail",

            thumbnail

        )

        info(

            f"Thumbnail Prompt Saved -> {output.name}"

        )

        return project


thumbnail_engine = ThumbnailEngine()

registry.register("thumbnail_engine", thumbnail_engine)