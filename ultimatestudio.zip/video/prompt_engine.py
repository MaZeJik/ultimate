"""
UltimateStudio
video/prompt_engine.py

Structured prompt builder for AI background art.

Updated for Synapse Melodic competitive look:
  - Club / tech-house family prioritizes fixed-camera, slow-motion,
    dark-luxury warehouse / underground club aesthetics
  - Less chaotic "crowd energy / confetti / laser spam"
  - More atmospheric fog, volumetric beams, premium interiors
  - Camera dimension biased toward static / slow cinematic frames
"""

from __future__ import annotations

import random


GENRE_FAMILY = {
    "dark trap": "urban_dark",
    "cinematic trap": "urban_dark",
    "phonk": "urban_dark",
    "drill": "urban_dark",
    "dark techno": "techno",
    "future bass": "electronic_bright",
    "melodic dubstep": "electronic_bright",
    "lo-fi": "chill",
    "deep house": "club",
    "tech house": "club",
    "melodic house": "club",
    "progressive house": "club",
    "afro house": "club",
    "festival house": "festival",
}

STYLE_POOLS = {
    # ----------------------------------------------------------
    # CLUB / TECH HOUSE  (Synapse-style core)
    # Fixed camera + slow motion + dark luxury / warehouse
    # ----------------------------------------------------------
    "club": {
        "scene": [
            "dark luxury underground warehouse club",
            "premium industrial nightclub interior",
            "secret warehouse rave space at night",
            "minimalist high-end club corridor",
            "empty VIP lounge with velvet seating",
            "concrete underground club dancefloor",
            "dark luxury club balcony overlooking the floor",
            "abandoned factory converted into a club",
            "black mirrored club hallway with soft fog",
            "intimate dark booth area in an underground club",
        ],
        "lighting": [
            "single volumetric light beam through fog",
            "soft purple and cyan ambient club lighting",
            "subtle warm amber rim light",
            "minimal LED wall glow in the distance",
            "cold blue industrial side lighting",
            "slow moving laser beam across haze",
            "moody low-key cinematic lighting",
            "single spotlight cutting through smoke",
        ],
        "atmosphere": [
            "thick atmospheric fog",
            "slow drifting haze",
            "subtle smoke in the air",
            "dust particles in light beams",
            "empty quiet club before the drop",
            "sparse minimal atmosphere",
            "dark luxury mood, almost no people visible",
        ],
        "camera": [
            "fixed camera angle, locked tripod",
            "static wide establishing shot",
            "slow motion cinematic frame",
            "perfectly still wide shot",
            "subtle slow push in, almost static",
            "locked-off low angle on the dancefloor",
            "static symmetrical composition",
        ],
        "look": [
            "dark luxury cinematic color grade",
            "high contrast moody film look",
            "desaturated shadows, rich highlights",
            "anamorphic subtle lens feel",
            "cinematic film grain",
            "premium nightclub photography style",
            "slow motion aesthetic, no visual chaos",
        ],
    },

    # ----------------------------------------------------------
    # FESTIVAL
    # ----------------------------------------------------------
    "festival": {
        "scene": [
            "outdoor festival main stage at night",
            "festival crowd under LED stage",
            "open field festival grounds after dark",
            "festival stage with soft pyrotechnics",
        ],
        "lighting": [
            "stage laser show through haze",
            "colorful but controlled stage lights",
            "dramatic spotlight beams",
            "golden residual sunset mixed with stage light",
        ],
        "atmosphere": [
            "haze over the crowd",
            "dust and light beams",
            "hands raised in the distance",
            "wide open night air",
        ],
        "camera": [
            "wide static establishing shot",
            "slow motion wide crowd shot",
            "locked-off stage-level wide angle",
            "subtle drone-like slow drift",
        ],
        "look": [
            "cinematic night festival grade",
            "high dynamic range",
            "epic wide composition",
            "controlled color, not oversaturated",
        ],
    },

    # ----------------------------------------------------------
    # TECHNO
    # ----------------------------------------------------------
    "techno": {
        "scene": [
            "industrial warehouse rave",
            "underground concrete club",
            "dark techno basement",
            "abandoned factory rave space",
            "raw concrete tunnel club",
        ],
        "lighting": [
            "cold blue industrial lighting",
            "harsh single white spotlight",
            "red warning light accents",
            "minimal single-source lighting",
            "strobe residual glow in fog",
        ],
        "atmosphere": [
            "thick industrial fog",
            "raw concrete texture",
            "minimal stark atmosphere",
            "empty industrial space",
        ],
        "camera": [
            "fixed camera, locked tripod",
            "static low wide angle",
            "symmetrical wide shot",
            "slow motion industrial frame",
        ],
        "look": [
            "gritty desaturated grade",
            "high contrast cold tone",
            "raw cinematic documentary look",
            "dark industrial film look",
        ],
    },

    # ----------------------------------------------------------
    # URBAN DARK (trap / phonk / drill)
    # ----------------------------------------------------------
    "urban_dark": {
        "scene": [
            "empty city street at night",
            "neon-lit alley",
            "rooftop skyline view",
            "underground parking garage",
            "abandoned urban interior",
            "rain-soaked city intersection",
        ],
        "lighting": [
            "neon sign lighting",
            "moody rim lighting",
            "single street lamp glow",
            "cold blue night lighting",
            "red and purple neon glow",
        ],
        "atmosphere": [
            "light rain and wet reflections",
            "urban fog",
            "steam rising from vents",
            "smoke drifting through frame",
        ],
        "camera": [
            "low angle cinematic shot",
            "wide establishing shot",
            "slow push in",
            "silhouette composition",
            "static locked frame",
        ],
        "look": [
            "moody cinematic grade",
            "high contrast noir look",
            "film grain",
            "desaturated shadows, vibrant neon highlights",
        ],
    },

    # ----------------------------------------------------------
    # ELECTRONIC BRIGHT
    # ----------------------------------------------------------
    "electronic_bright": {
        "scene": [
            "futuristic digital landscape",
            "abstract light tunnel",
            "crystalline structure field",
            "neon grid horizon",
        ],
        "lighting": [
            "bright neon grid lighting",
            "electric blue and magenta glow",
            "pulsing digital light",
            "holographic light beams",
        ],
        "atmosphere": [
            "digital particle field",
            "clean futuristic haze",
            "abstract energy trails",
        ],
        "camera": [
            "wide futuristic establishing shot",
            "slow cinematic drift",
            "static symmetrical frame",
        ],
        "look": [
            "clean high-tech cinematic grade",
            "vibrant but controlled neon colors",
            "sharp digital clarity",
        ],
    },

    # ----------------------------------------------------------
    # CHILL / LO-FI
    # ----------------------------------------------------------
    "chill": {
        "scene": [
            "quiet rainy window view",
            "cozy dimly lit room",
            "soft city lights through curtains",
            "minimalist apartment at night",
        ],
        "lighting": [
            "soft warm lamp light",
            "cool blue window light",
            "gentle practical lighting",
        ],
        "atmosphere": [
            "soft rain on glass",
            "quiet intimate mood",
            "gentle dust in light",
        ],
        "camera": [
            "static calm shot",
            "soft focus wide shot",
            "slow gentle pan",
        ],
        "look": [
            "warm muted color grade",
            "soft film grain",
            "gentle vintage tone",
        ],
    },
}

NEGATIVE_PROMPT = (
    "low quality, low resolution, blurry, deformed, bad anatomy, extra limbs, "
    "duplicate, watermark, text, logo, jpeg artifacts, oversaturated, "
    "oversharpened, cartoon, anime, cgi look, plastic skin, bad lighting, "
    "poor composition, busy crowd, chaotic particles, excessive lasers, "
    "confetti overload, motion blur chaos"
)


def _family_for(genre: str) -> str:
    return GENRE_FAMILY.get(str(genre).lower(), "urban_dark")


def build_prompt(genre: str, mood: str, section_hint: str = "") -> str:
    """
    Builds a rich, varied prompt. Club/tech-house family is biased
    toward fixed-camera dark-luxury warehouse aesthetics so the
    resulting loops feel closer to high-end tech-house channels.
    """
    family = _family_for(genre)
    pools = STYLE_POOLS.get(family, STYLE_POOLS["urban_dark"])

    try:
        from core.variation_tracker import variation_tracker

        scene = variation_tracker.choose(f"{family}:scene", pools["scene"])
        lighting = variation_tracker.choose(f"{family}:lighting", pools["lighting"])
        atmosphere = variation_tracker.choose(f"{family}:atmosphere", pools["atmosphere"])
        camera = variation_tracker.choose(f"{family}:camera", pools["camera"])
        look = variation_tracker.choose(f"{family}:look", pools["look"])
    except ImportError:
        scene = random.choice(pools["scene"])
        lighting = random.choice(pools["lighting"])
        atmosphere = random.choice(pools["atmosphere"])
        camera = random.choice(pools["camera"])
        look = random.choice(pools["look"])

    parts = [
        f"{genre} music video background",
        scene,
        f"{mood} atmosphere" if mood else "",
        lighting,
        atmosphere,
        camera,
        look,
        section_hint,
        "photorealistic, ultra detailed, 8k, no text, no watermark, no logo, no people close-up",
    ]

    return ", ".join(p for p in parts if p)


def combination_count(genre: str) -> int:
    family = _family_for(genre)
    pools = STYLE_POOLS.get(family, STYLE_POOLS["urban_dark"])
    total = 1
    for values in pools.values():
        total *= len(values)
    return total