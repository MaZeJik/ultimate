"""
UltimateStudio
video/visual_engine.py

The pixel-producing engine behind the videos.

Updated to compete with high-end Tech House channels (Synapse Melodic style):
  - Prefer fixed-camera / slow cinematic loops over busy audio-reactive HUD
  - Much less visual chaos on house/tech-house genres
  - Title card + subscribe badge appear rarely and fade softly
  - Stronger dark-luxury cinematic grade
  - Loop library is first-class (one branded loop reused forever)
"""

from __future__ import annotations

import math
import random
import subprocess
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from core.logger import error, info, warning

# ==========================================================
# FONTS
# ==========================================================

_TITLE_FONT_PATH = "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf"
_KICKER_FONT_PATH = "/usr/share/fonts/truetype/google-fonts/Poppins-BoldItalic.ttf"
_UI_FONT_PATH = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"


def _font(path: str, size: int) -> ImageFont.FreeTypeFont:
    try:
        return ImageFont.truetype(path, size)
    except OSError:
        return ImageFont.load_default()


# ==========================================================
# PALETTES  (dark luxury / club oriented)
# ==========================================================

PALETTES: dict[str, tuple[tuple[int, int, int], tuple[int, int, int], tuple[int, int, int]]] = {
    "dark": ((18, 18, 28), (42, 16, 58), (160, 70, 255)),
    "aggressive": ((38, 12, 12), (78, 8, 22), (255, 50, 55)),
    "sad": ((16, 24, 44), (36, 48, 78), (70, 130, 230)),
    "melancholic": ((18, 22, 36), (36, 40, 62), (110, 120, 190)),
    "emotional": ((24, 20, 42), (64, 34, 88), (240, 120, 190)),
    "powerful": ((26, 16, 10), (72, 40, 12), (255, 145, 35)),
    "mysterious": ((12, 20, 24), (24, 52, 58), (35, 210, 190)),
    "energetic": ((24, 12, 36), (72, 12, 78), (255, 55, 210)),
    # new house / tech house oriented
    "luxury": ((14, 14, 22), (32, 28, 48), (180, 140, 255)),
    "underground": ((10, 12, 18), (28, 22, 38), (120, 90, 255)),
    "euphoric": ((20, 18, 40), (50, 30, 80), (200, 100, 255)),
    "sunset": ((30, 18, 20), (70, 35, 25), (255, 120, 60)),
}


def palette_for(mood: str) -> tuple:
    return PALETTES.get(str(mood).lower(), PALETTES["dark"])


def lerp_color(c1: tuple, c2: tuple, t: float) -> tuple:
    return tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))


# ==========================================================
# AUDIO ANALYSIS
# ==========================================================

@dataclass
class AudioFeatures:
    fps: int
    n_frames: int
    envelope: np.ndarray
    bass: np.ndarray
    mid: np.ndarray
    treble: np.ndarray
    spectrum: np.ndarray


def analyze_audio(mono: np.ndarray, sample_rate: int, fps: int, n_bars: int = 32) -> AudioFeatures:
    duration = len(mono) / sample_rate
    n_frames = max(1, int(duration * fps))
    hop = max(1, len(mono) // n_frames)

    envelope = np.zeros(n_frames, dtype=np.float32)
    bass = np.zeros(n_frames, dtype=np.float32)
    mid = np.zeros(n_frames, dtype=np.float32)
    treble = np.zeros(n_frames, dtype=np.float32)
    spectrum = np.zeros((n_frames, n_bars), dtype=np.float32)

    window = np.hanning(hop * 2).astype(np.float32)

    for i in range(n_frames):
        start = i * hop
        chunk = mono[start : start + hop * 2]
        if len(chunk) < hop * 2:
            chunk = np.pad(chunk, (0, hop * 2 - len(chunk)))
        chunk = chunk * window
        envelope[i] = float(np.sqrt(np.mean(chunk ** 2)))

        # simple band energy via FFT
        spec = np.abs(np.fft.rfft(chunk))
        freqs = np.fft.rfftfreq(len(chunk), 1.0 / sample_rate)
        bass[i] = float(np.mean(spec[(freqs >= 30) & (freqs < 150)]) + 1e-8)
        mid[i] = float(np.mean(spec[(freqs >= 150) & (freqs < 2000)]) + 1e-8)
        treble[i] = float(np.mean(spec[(freqs >= 2000) & (freqs < 8000)]) + 1e-8)

        # log-spaced spectrum bars
        for b in range(n_bars):
            lo = 40 * (2 ** (b * 0.25))
            hi = 40 * (2 ** ((b + 1) * 0.25))
            mask = (freqs >= lo) & (freqs < hi)
            spectrum[i, b] = float(np.mean(spec[mask]) + 1e-8) if mask.any() else 0.0

    # normalize
    def _norm(x):
        mx = float(np.max(x)) + 1e-8
        return np.clip(x / mx, 0, 1)

    envelope = _norm(envelope)
    bass = _norm(bass)
    mid = _norm(mid)
    treble = _norm(treble)
    spectrum = _norm(spectrum)

    return AudioFeatures(fps=fps, n_frames=n_frames, envelope=envelope, bass=bass, mid=mid, treble=treble, spectrum=spectrum)


# ==========================================================
# PARTICLE (kept but used lightly)
# ==========================================================

@dataclass
class Particle:
    x: float
    y: float
    vx: float
    vy: float
    size: float
    life: float

    def __init__(self, w: int, h: int):
        self.x = random.uniform(0, w)
        self.y = random.uniform(0, h)
        self.vx = random.uniform(-15, 15)
        self.vy = random.uniform(-25, -5)
        self.size = random.uniform(1.2, 3.5)
        self.life = random.uniform(0.4, 1.0)

    def step(self, w: int, h: int, dt: float):
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.life -= dt * 0.15
        if self.life <= 0 or self.y < -20 or self.x < -20 or self.x > w + 20:
            self.__init__(w, h)


# ==========================================================
# VISUAL ENGINE
# ==========================================================

class VisualEngine:
    WIDTH = 1920
    HEIGHT = 1080
    FPS = 24
    N_BARS = 28
    N_PARTICLES = 18
    SECTION_CROSSFADE_SEC = 1.8
    SUBSCRIBE_EVERY = 48.0          # much rarer
    SUBSCRIBE_VISIBLE = 5.5
    TITLE_VISIBLE_SEC = 9.0         # title only at the beginning

    # genres that should use the clean "Synapse-style" cinematic mode
    CINEMATIC_GENRES = {
        "tech house", "deep house", "tech house", "progressive house",
        "melodic house", "afro house", "festival house", "dark techno",
        "techno", "minimal", "house", "acid tech house", "groovy tech house",
    }

    def __init__(self):
        # pre-build a soft S-curve LUT for color grade
        x = np.linspace(0, 1, 256)
        s = 0.5 + 0.5 * np.tanh((x - 0.5) * 1.55)
        self._scurve_lut = (np.clip(s, 0, 1) * 255).astype(np.uint8)

    # ------------------------------------------------------
    # helpers
    # ------------------------------------------------------

    def _is_cinematic(self, genre: str, mood: str) -> bool:
        g = (genre or "").lower()
        m = (mood or "").lower()
        if any(k in g for k in self.CINEMATIC_GENRES):
            return True
        if m in ("luxury", "underground", "euphoric", "mysterious"):
            return True
        return False

    def _ken_burns_frame(self, img: Image.Image, progress: float, direction: int = 1) -> Image.Image:
        """Very subtle drift — almost fixed camera feel."""
        w, h = self.WIDTH, self.HEIGHT
        # extremely mild zoom (1.0 → 1.06) so it still feels alive but not restless
        scale = 1.0 + 0.06 * progress
        crop_w = int(w / scale)
        crop_h = int(h / scale)
        max_x = max(0, img.width - crop_w)
        max_y = max(0, img.height - crop_h)
        # slow horizontal drift only
        ox = int(max_x * (0.5 + direction * 0.35 * (progress - 0.5)))
        oy = int(max_y * 0.45)
        frame = img.crop((ox, oy, ox + crop_w, oy + crop_h)).resize((w, h), Image.LANCZOS)
        return frame.convert("RGB")

    def _background_frame_for_time(
        self,
        t: float,
        section_timeline: list[dict],
        ai_images: dict[str, Image.Image],
        procedural_fallback: Image.Image,
        clip_frames: dict[str, list[np.ndarray]],
    ) -> Image.Image:
        if not section_timeline:
            return procedural_fallback.convert("RGB")

        idx = 0
        for i, sec in enumerate(section_timeline):
            if sec["start_sec"] <= t < sec["end_sec"]:
                idx = i
                break
            if t >= sec["end_sec"]:
                idx = i

        section = section_timeline[idx]

        if clip_frames and section["name"] in clip_frames:
            local_t = t - section["start_sec"]
            return self._clip_frame_at(clip_frames[section["name"]], local_t, fps=float(self.FPS))

        img = ai_images.get(section["name"])
        if img is None:
            return procedural_fallback.convert("RGB")

        span = max(0.01, section["end_sec"] - section["start_sec"])
        progress = np.clip((t - section["start_sec"]) / span, 0, 1)
        direction = 1 if idx % 2 == 0 else -1
        current_frame = self._ken_burns_frame(img, progress, direction)

        # soft crossfade
        time_to_end = section["end_sec"] - t
        if time_to_end < self.SECTION_CROSSFADE_SEC and idx + 1 < len(section_timeline):
            next_section = section_timeline[idx + 1]
            next_img = ai_images.get(next_section["name"])
            if next_img is not None:
                next_direction = 1 if (idx + 1) % 2 == 0 else -1
                next_frame = self._ken_burns_frame(next_img, 0.0, next_direction)
                blend = 1.0 - (time_to_end / self.SECTION_CROSSFADE_SEC)
                current_frame = Image.blend(current_frame, next_frame, float(np.clip(blend, 0, 1)))

        return current_frame

    def _load_clip_frames(self, path: Path, max_frames: int = 240) -> list[np.ndarray] | None:
        try:
            import cv2
        except ImportError:
            return None
        cap = cv2.VideoCapture(str(path))
        if not cap.isOpened():
            return None
        frames = []
        while len(frames) < max_frames:
            ok, frame_bgr = cap.read()
            if not ok:
                break
            frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
            frame_rgb = cv2.resize(frame_rgb, (self.WIDTH, self.HEIGHT), interpolation=cv2.INTER_LANCZOS4)
            frames.append(frame_rgb)
        cap.release()
        return frames or None

    def _clip_frame_at(self, frames: list[np.ndarray], local_t: float, fps: float = 24.0) -> Image.Image:
        n = len(frames)
        if n == 1:
            return Image.fromarray(frames[0], "RGB")
        period = (n - 1) * 2
        idx = int(local_t * fps) % period
        if idx >= n:
            idx = period - idx
        return Image.fromarray(frames[idx], "RGB")

    def _build_background(self, mood: str) -> Image.Image:
        top, bottom, _accent = palette_for(mood)
        h = self.HEIGHT
        gradient = np.linspace(top, bottom, h).astype(np.uint8)
        arr = np.repeat(gradient[:, np.newaxis, :], self.WIDTH, axis=1)
        yy, xx = np.mgrid[0:h, 0 : self.WIDTH]
        cx, cy = self.WIDTH / 2, h / 2
        dist = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2) / math.hypot(cx, cy)
        vignette = np.clip(1.0 - dist * 0.65, 0.25, 1.0)
        arr = (arr * vignette[..., None]).astype(np.uint8)
        return Image.fromarray(arr, "RGB").convert("RGBA")

    def _build_title_card(self, title: str, kicker: str, accent: tuple) -> Image.Image:
        card = Image.new("RGBA", (self.WIDTH, self.HEIGHT), (0, 0, 0, 0))
        # very soft top scrim
        scrim_h = 220
        scrim = np.zeros((scrim_h, self.WIDTH, 4), dtype=np.uint8)
        alpha = np.linspace(130, 0, scrim_h).astype(np.uint8)
        scrim[..., 3] = alpha[:, None]
        card.paste(Image.fromarray(scrim, "RGBA"), (0, 0), Image.fromarray(scrim, "RGBA"))

        draw = ImageDraw.Draw(card)
        kicker_font = _font(_KICKER_FONT_PATH, 24)
        title_font = _font(_TITLE_FONT_PATH, 58)

        kicker = kicker.upper()
        kbbox = draw.textbbox((0, 0), kicker, font=kicker_font)
        kw = kbbox[2] - kbbox[0]
        draw.text(((self.WIDTH - kw) / 2, 48), kicker, font=kicker_font, fill=(*accent, 220))

        title = (title or "Untitled").upper()
        # soft wrap if too long
        if len(title) > 28:
            title = title[:26] + "…"
        tbbox = draw.textbbox((0, 0), title, font=title_font)
        tw = tbbox[2] - tbbox[0]
        tx = (self.WIDTH - tw) / 2
        draw.text((tx + 2, 92 + 2), title, font=title_font, fill=(0, 0, 0, 120))
        draw.text((tx, 92), title, font=title_font, fill=(255, 255, 255, 240))

        underline_w = min(tw * 0.45, 220)
        uy = 92 + 72
        draw.line(
            [(self.WIDTH - underline_w) / 2, uy, (self.WIDTH + underline_w) / 2, uy],
            fill=(*accent, 200),
            width=2,
        )
        return card

    def _build_subscribe_badge(self, accent: tuple) -> Image.Image:
        w, h = 380, 92
        badge = Image.new("RGBA", (w + 16, h + 16), (0, 0, 0, 0))
        draw = ImageDraw.Draw(badge)
        draw.rounded_rectangle([10, 10, w + 10, h + 10], radius=18, fill=(0, 0, 0, 70))
        draw.rounded_rectangle([8, 8, w + 8, h + 8], radius=18, fill=(200, 20, 40, 230))
        font = _font(_UI_FONT_PATH, 26)
        sub_font = _font(_UI_FONT_PATH, 15)
        text = "SUBSCRIBE"
        bbox = draw.textbbox((0, 0), text, font=font)
        tw = bbox[2] - bbox[0]
        draw.text((8 + (w - tw) / 2, 22), text, font=font, fill=(255, 255, 255, 255))
        sub_text = "more tech house every week"
        sbbox = draw.textbbox((0, 0), sub_text, font=sub_font)
        stw = sbbox[2] - sbbox[0]
        draw.text((8 + (w - stw) / 2, 56), sub_text, font=sub_font, fill=(255, 220, 225, 200))
        return badge

    # ------------------------------------------------------
    # dynamic layers — used lightly in cinematic mode
    # ------------------------------------------------------

    def _draw_subtle_glow(self, draw: ImageDraw.ImageDraw, cx: float, cy: float, bass: float, accent: tuple) -> None:
        """Very soft center glow only on strong bass hits."""
        if bass < 0.55:
            return
        base_r = 90 + bass * 70
        for i, alpha in ((0, 28), (1, 16), (2, 8)):
            r = base_r + i * 35
            draw.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(*accent, alpha), width=2)

    def _draw_minimal_progress(self, draw: ImageDraw.ImageDraw, t: float, duration: float, accent: tuple) -> None:
        frac = min(1.0, t / duration) if duration else 0.0
        y = self.HEIGHT - 6
        draw.line([0, y, self.WIDTH, y], fill=(255, 255, 255, 25), width=2)
        draw.line([0, y, self.WIDTH * frac, y], fill=(*accent, 180), width=2)

    # ------------------------------------------------------
    # color grade
    # ------------------------------------------------------

    def _bloom(self, x: np.ndarray, threshold: float = 0.78, strength: float = 0.22) -> np.ndarray:
        h, w = x.shape[:2]
        try:
            import cv2
            small = cv2.resize(x, (w // 8, h // 8), interpolation=cv2.INTER_AREA)
            luma = small[..., 0] * 0.299 + small[..., 1] * 0.587 + small[..., 2] * 0.114
            mask = np.clip((luma - threshold) / max(1e-4, 1 - threshold), 0, 1)
            bright_small = small * mask[..., None]
            blurred = cv2.resize(bright_small, (w, h), interpolation=cv2.INTER_LINEAR)
        except ImportError:
            luma = x[..., 0] * 0.299 + x[..., 1] * 0.587 + x[..., 2] * 0.114
            mask = np.clip((luma - threshold) / max(1e-4, 1 - threshold), 0, 1)
            bright = x * mask[..., None]
            small = bright[: h - h % 8, : w - w % 8].reshape(h // 8, 8, w // 8, 8, 3).mean(axis=(1, 3))
            blurred = np.repeat(np.repeat(small, 8, axis=0), 8, axis=1)
            if blurred.shape[0] != h or blurred.shape[1] != w:
                padded = np.zeros((h, w, 3), dtype=blurred.dtype)
                padded[: blurred.shape[0], : blurred.shape[1]] = blurred
                blurred = padded
        return np.clip(x + blurred * strength, 0, 1)

    def _color_grade(self, frame_arr: np.ndarray, grain: np.ndarray, bass: float = 0.0, cinematic: bool = False) -> np.ndarray:
        try:
            import cv2
            frame_arr = cv2.LUT(frame_arr, self._scurve_lut)
        except ImportError:
            pass

        x = frame_arr.astype(np.float32) / 255.0

        # softer bloom for cinematic look
        x = self._bloom(x, threshold=0.80 if cinematic else 0.72, strength=0.18 if cinematic else 0.28)

        # cooler shadows, very subtle warm highlights
        x[..., 2] += (1 - x[..., 0]) * (0.035 if cinematic else 0.025)
        x[..., 0] += x[..., 0] * 0.006
        np.clip(x, 0, 1, out=x)

        # almost no chromatic aberration in cinematic mode
        if not cinematic and bass > 0.65:
            shift = int(1 + (bass - 0.65) * 3)
            out = x.copy()
            out[:, :, 0] = np.roll(x[:, :, 0], shift, axis=1)
            out[:, :, 2] = np.roll(x[:, :, 2], -shift, axis=1)
            x = out

        x = np.clip(x + grain * (0.7 if cinematic else 1.0), 0, 1)
        return (x * 255).astype(np.uint8)

    def _load_loop_video_frames(self, loop_path: Path, max_frames: int = 400) -> list[np.ndarray] | None:
        try:
            import cv2
        except ImportError:
            warning("VISUAL ENGINE -> opencv not installed, can't use loop video")
            return None
        cap = cv2.VideoCapture(str(loop_path))
        small_w, small_h = self.WIDTH // 2, self.HEIGHT // 2
        frames = []
        while len(frames) < max_frames:
            ok, frame = cap.read()
            if not ok:
                break
            frame = cv2.resize(frame, (small_w, small_h))
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frames.append(frame)
        cap.release()
        return frames or None

    def _loop_frame_at(self, frames: list[np.ndarray], frame_index: int) -> Image.Image:
        raw = frames[frame_index % len(frames)]
        return Image.fromarray(raw, "RGB").resize((self.WIDTH, self.HEIGHT), Image.LANCZOS)

    # ------------------------------------------------------
    # main render
    # ------------------------------------------------------

    def render(self, project) -> Path | None:
        master = project.get("master_audio")
        if master is None:
            info("VISUAL ENGINE -> no master_audio, skipping")
            return None

        master = np.asarray(master, dtype=np.float32)
        mono = master.mean(axis=0) if master.ndim == 2 else master
        sample_rate = int(project.get("master_info", {}).get("sample_rate", 44100))

        title = project.get("title") or "Untitled"
        mood = project.get("mood") or "dark"
        genre = project.get("genre") or ""
        _top, _bottom, accent = palette_for(mood)

        cinematic = self._is_cinematic(genre, mood)
        info(f"VISUAL ENGINE -> mode={'CINEMATIC (Synapse-style)' if cinematic else 'REACTIVE'} | genre={genre}")

        features = analyze_audio(mono, sample_rate, self.FPS, self.N_BARS)

        procedural_bg = self._build_background(mood)
        section_timeline: list[dict] = []
        ai_images: dict[str, Image.Image] = {}
        clip_frames: dict[str, list[np.ndarray]] = {}
        loop_frames: list[np.ndarray] | None = None

        from core.config import SETTINGS

        if SETTINGS.visual_mode == "ai":
            try:
                from video.loop_library import loop_library
                loop_path = loop_library.get_loop(genre, mood)
                if loop_path:
                    loop_frames = self._load_loop_video_frames(loop_path)
                    if loop_frames:
                        info(f"VISUAL ENGINE -> using persistent background loop ({len(loop_frames)} frames)")
            except Exception as exc:
                warning(f"VISUAL ENGINE -> loop library unavailable ({exc})")

            if not loop_frames:
                ai_result = self._build_ai_backgrounds(project)
                if ai_result:
                    section_timeline, ai_images = ai_result
                    info(f"VISUAL ENGINE -> using AI backgrounds for {len(ai_images)} section(s)")
                else:
                    info("VISUAL ENGINE -> AI background unavailable, using procedural")

        kicker = f"{genre} type beat".strip() or "type beat"
        if cinematic:
            kicker = f"{genre}".strip() or "tech house"
        title_card = self._build_title_card(title, kicker, accent)
        subscribe_badge = self._build_subscribe_badge(accent)

        particles = [Particle(self.WIDTH, self.HEIGHT) for _ in range(self.N_PARTICLES if not cinematic else 6)]
        cx, cy = self.WIDTH / 2, self.HEIGHT / 2 - 40

        audio_wav = project.get("audio_file")
        if not audio_wav or not Path(audio_wav).exists():
            info("VISUAL ENGINE -> exported audio file missing, skipping")
            return None

        out_path = Path(project.get("video_file", "output.mp4")).with_suffix(".mp4")
        out_path.parent.mkdir(parents=True, exist_ok=True)

        ffmpeg_cmd = [
            "ffmpeg", "-y", "-loglevel", "error",
            "-f", "rawvideo", "-pixel_format", "rgb24",
            "-video_size", f"{self.WIDTH}x{self.HEIGHT}",
            "-framerate", str(self.FPS),
            "-i", "-",
            "-i", str(audio_wav),
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "17",
            "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "192k",
            "-shortest",
            str(out_path),
        ]

        info(f"VISUAL ENGINE -> rendering {features.n_frames} frames @ {self.FPS}fps")

        proc = subprocess.Popen(ffmpeg_cmd, stdin=subprocess.PIPE, stderr=subprocess.PIPE)
        dt = 1.0 / self.FPS
        duration = features.n_frames / self.FPS
        grain_tile = (np.random.default_rng(0).standard_normal((self.HEIGHT * 2, self.WIDTH * 2)).astype(np.float32) * 0.012)

        try:
            for i in range(features.n_frames):
                t = i * dt

                if loop_frames:
                    frame = self._loop_frame_at(loop_frames, i).convert("RGBA")
                    # darker overlay so text stays readable but atmosphere remains
                    overlay = Image.new("RGBA", frame.size, (0, 0, 0, 55 if cinematic else 70))
                    frame = Image.alpha_composite(frame, overlay)
                else:
                    frame = self._background_frame_for_time(
                        t, section_timeline, ai_images, procedural_bg, clip_frames
                    ).convert("RGBA")
                    if ai_images:
                        overlay = Image.new("RGBA", frame.size, (0, 0, 0, 50 if cinematic else 70))
                        frame = Image.alpha_composite(frame, overlay)

                draw = ImageDraw.Draw(frame, "RGBA")

                if cinematic:
                    # almost pure atmosphere — only subtle glow on strong hits + thin progress
                    self._draw_subtle_glow(draw, cx, cy, float(features.bass[i]), accent)
                    self._draw_minimal_progress(draw, t, duration, accent)
                else:
                    # classic reactive mode (trap / phonk etc.)
                    self._draw_subtle_glow(draw, cx, cy, float(features.bass[i]), accent)
                    # light particles only
                    for p in particles:
                        p.step(self.WIDTH, self.HEIGHT, dt)
                    for p in particles:
                        r = p.size * (1.0 + float(features.treble[i]) * 0.8)
                        draw.ellipse([p.x - r, p.y - r, p.x + r, p.y + r], fill=(*accent, 90))
                    self._draw_minimal_progress(draw, t, duration, accent)

                # Title card only at the very beginning
                if t < self.TITLE_VISIBLE_SEC:
                    fade = 1.0
                    if t > self.TITLE_VISIBLE_SEC - 1.8:
                        fade = max(0.0, (self.TITLE_VISIBLE_SEC - t) / 1.8)
                    if fade >= 0.99:
                        frame.alpha_composite(title_card)
                    else:
                        alpha = title_card.split()[3].point(lambda a: int(a * fade))
                        tmp = title_card.copy()
                        tmp.putalpha(alpha)
                        frame.alpha_composite(tmp)

                # Subscribe badge — rare and soft
                cycle_t = t % self.SUBSCRIBE_EVERY
                if cycle_t < self.SUBSCRIBE_VISIBLE and t > 20:
                    edge = min(cycle_t, self.SUBSCRIBE_VISIBLE - cycle_t)
                    fade = min(1.0, edge * 2.0)
                    slide = min(1.0, edge * 2.5)
                    badge = subscribe_badge
                    bx = self.WIDTH - badge.width + int((1 - slide) * (badge.width + 40)) - 40
                    by = self.HEIGHT - badge.height - 80
                    if fade < 1.0:
                        alpha = badge.split()[3].point(lambda a: int(a * fade))
                        badge = badge.copy()
                        badge.putalpha(alpha)
                    frame.alpha_composite(badge, (bx, by))

                rgb_arr = np.asarray(frame.convert("RGB"))
                gy = np.random.randint(0, self.HEIGHT)
                gx = np.random.randint(0, self.WIDTH)
                grain_slice = grain_tile[gy : gy + self.HEIGHT, gx : gx + self.WIDTH, None]
                graded = self._color_grade(rgb_arr, grain_slice, bass=float(features.bass[i]), cinematic=cinematic)

                proc.stdin.write(graded.tobytes())

            proc.stdin.close()
            proc.wait()
        except BrokenPipeError:
            warning("VISUAL ENGINE -> ffmpeg pipe closed early")
        except Exception as exc:
            error(f"VISUAL ENGINE -> frame generation crashed at frame {i}: {exc}")
            proc.kill()
            proc.wait()
            if out_path.exists():
                out_path.unlink()
            return None
        finally:
            if proc.stdin and not proc.stdin.closed:
                proc.stdin.close()

        stderr_text = proc.stderr.read().decode(errors="ignore") if proc.stderr else ""

        if proc.returncode not in (0, None) or not out_path.exists():
            if out_path.exists():
                out_path.unlink()
            self._log_ffmpeg_failure(out_path, stderr_text)
            return None

        if not self._verify_playable(out_path):
            error(f"VISUAL ENGINE -> {out_path} is not a valid playable video")
            self._log_ffmpeg_failure(out_path, stderr_text)
            out_path.unlink()
            return None

        info(f"VISUAL ENGINE -> rendered {out_path}")
        return out_path

    def _log_ffmpeg_failure(self, out_path: Path, stderr_text: str) -> None:
        warning(f"VISUAL ENGINE -> ffmpeg failed for {out_path.name}")
        error(f"VISUAL ENGINE -> ffmpeg stderr:\n{stderr_text[-4000:]}")
        try:
            log_path = out_path.parent / f"{out_path.stem}_ffmpeg_error.log"
            log_path.write_text(stderr_text, encoding="utf8")
        except OSError:
            pass

    def _verify_playable(self, path: Path) -> bool:
        try:
            result = subprocess.run(
                ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(path)],
                capture_output=True,
                text=True,
                timeout=30,
            )
        except (subprocess.SubprocessError, OSError):
            return False
        if result.returncode != 0 or not result.stdout.strip():
            return False
        try:
            return float(result.stdout.strip()) > 0
        except ValueError:
            return False

    def _build_ai_backgrounds(self, project):
        """Kept for compatibility — returns (section_timeline, images) or None."""
        try:
            from video.ai_background import ai_background_generator
            from video.storyboard import storyboard_engine
        except ImportError:
            return None
        # minimal implementation: let the existing modules do the work if present
        return None


visual_engine = VisualEngine()