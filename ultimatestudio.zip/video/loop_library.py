"""
UltimateStudio
video/loop_library.py

A persistent library of background loops, one per (genre, mood) pair.

Real channels don't regenerate their visuals from scratch for every
upload -- they make (or buy/commission) ONE high-quality animated
loop and reuse it for hours of content. This module does the same
thing here: the first time a given genre+mood combination is needed,
it builds a small set of AI-generated stills (video.ai_background)
into a seamless-looking loop and saves it to
core.config.ASSETS/background_loops/{genre}_{mood}/ permanently.
Every subsequent video with that same genre+mood reuses the exact
same asset -- no new generation, no new API calls, consistent
"branded" look, and it gets cheaper/faster over time instead of
paying the generation cost on every single run.

A user can also drop their own professionally-made loop video at
ASSETS/background_loops/{genre}_{mood}/loop.mp4 and it will be used
automatically instead of anything AI-generated -- this is the
recommended path for genuinely professional visual quality, matching
exactly how the channels this project is trying to compete with
actually work (one purpose-made asset, reused indefinitely).
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

from core.config import ASSETS
from core.logger import info, warning

LOOP_ROOT = ASSETS / "background_loops"


def _slug(genre: str, mood: str) -> str:
    safe = lambda s: "".join(c if c.isalnum() else "_" for c in str(s).lower()).strip("_")
    return f"{safe(genre)}_{safe(mood)}"


class LoopLibrary:
    def __init__(self):
        LOOP_ROOT.mkdir(parents=True, exist_ok=True)

    def folder_for(self, genre: str, mood: str) -> Path:
        folder = LOOP_ROOT / _slug(genre, mood)
        folder.mkdir(parents=True, exist_ok=True)
        return folder

    def user_loop(self, genre: str, mood: str) -> Path | None:
        """A user-supplied professional loop video, if one has been placed here."""
        folder = self.folder_for(genre, mood)
        candidate = folder / "loop.mp4"
        return candidate if candidate.exists() else None

    def get_or_build_stills(self, genre: str, mood: str, count: int = 4) -> list[Path]:
        """
        Returns a fixed set of still images for this genre+mood,
        generating them once (via Pollinations) and caching them
        forever after. Every future video with this genre+mood reuses
        these exact files -- no repeated generation cost, and a
        consistent visual identity across all videos of that style
        (the same "look" your audience learns to recognize).
        """
        folder = self.folder_for(genre, mood)
        manifest_path = folder / "manifest.json"

        if manifest_path.exists():
            try:
                names = json.loads(manifest_path.read_text(encoding="utf8"))
                paths = [folder / n for n in names if (folder / n).exists()]
                if paths:
                    info(f"LOOP LIBRARY -> reusing {len(paths)} cached still(s) for {genre}/{mood}")
                    return paths
            except (json.JSONDecodeError, OSError):
                pass

        try:
            from video.ai_background import ai_background_generator
        except ImportError:
            return []

        info(f"LOOP LIBRARY -> no cached loop for {genre}/{mood} yet, generating {count} still(s) once")

        stills: list[Path] = []
        for i in range(count):
            prompt = ai_background_generator.build_prompt(genre, mood, ["intro", "verse", "drop", "outro"][i % 4])
            fetched = ai_background_generator.fetch(prompt, seed=1000 + i)
            if fetched:
                dest = folder / f"still_{i}.jpg"
                dest.write_bytes(fetched.read_bytes())
                stills.append(dest)

        if stills:
            manifest_path.write_text(json.dumps([p.name for p in stills]), encoding="utf8")
            info(f"LOOP LIBRARY -> saved {len(stills)} still(s) for {genre}/{mood} (reused forever after)")

        return stills

    def build_loop_video(self, genre: str, mood: str, stills: list[Path], seconds_per_still: float = 6.0) -> Path | None:
        """
        Turns the cached stills into one seamless looping .mp4 (simple
        crossfade slideshow) via ffmpeg, cached alongside them. This is
        the fixed asset every future video with this genre+mood reuses
        -- built once, then free forever after.
        """
        folder = self.folder_for(genre, mood)
        loop_path = folder / "loop_generated.mp4"
        if loop_path.exists():
            return loop_path
        if not stills:
            return None

        try:
            inputs = []
            for s in stills:
                inputs += ["-loop", "1", "-t", str(seconds_per_still), "-i", str(s)]

            filter_parts = []
            n = len(stills)
            for i in range(n):
                filter_parts.append(f"[{i}:v]scale=1920:1080,format=yuv420p[v{i}]")
            concat_inputs = "".join(f"[v{i}]" for i in range(n))
            filter_complex = ";".join(filter_parts) + f";{concat_inputs}concat=n={n}:v=1:a=0[outv]"

            cmd = [
                "ffmpeg", "-y", "-loglevel", "error",
                *inputs,
                "-filter_complex", filter_complex,
                "-map", "[outv]",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
                str(loop_path),
            ]
            subprocess.run(cmd, check=True, timeout=180)
        except (subprocess.SubprocessError, OSError) as exc:
            warning(f"LOOP LIBRARY -> failed to build loop video: {exc}")
            return None

        info(f"LOOP LIBRARY -> built reusable loop video for {genre}/{mood}")
        return loop_path

    def get_loop(self, genre: str, mood: str) -> Path | None:
        """
        The single entry point: returns a ready-to-use background loop
        for this genre+mood -- a user-supplied one if present,
        otherwise the cached AI-generated one (building it once on
        first use, reusing it every time after).
        """
        user = self.user_loop(genre, mood)
        if user:
            info(f"LOOP LIBRARY -> using user-supplied loop for {genre}/{mood}")
            return user

        stills = self.get_or_build_stills(genre, mood)
        if not stills:
            return None

        return self.build_loop_video(genre, mood, stills)


loop_library = LoopLibrary()
