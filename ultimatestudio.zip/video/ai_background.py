"""
UltimateStudio
video/ai_background.py

Generates real AI artwork for video backgrounds via Pollinations
(Flux, free, no key). One image per section, cached to disk.

Section hints tuned for Tech House / club tracks so intros feel
minimal and atmospheric, drops feel intense but still cinematic
(not chaotic), matching the fixed-camera dark-luxury direction.
"""

from __future__ import annotations

import hashlib
import io
import time
import urllib.parse
from pathlib import Path

import requests
from PIL import Image

from core.config import CACHE, SETTINGS
from core.logger import info, warning


# Section energy language — house-aware
SECTION_STYLE_HINTS = {
    "intro": "slow build, minimal, atmospheric, wide fixed shot, almost empty space",
    "verse": "moody, cinematic, moderate energy, locked camera",
    "build": "rising tension, dramatic volumetric lighting, slow motion feel",
    "drop": "intense energy, high contrast, powerful but clean composition, fixed camera",
    "break": "stripped back, quiet, atmospheric, negative space, minimal light",
    "drop2": "intense energy, high contrast, powerful but clean composition, fixed camera",
    "outro": "fading energy, calm, wide shot, soft residual light",
    "main": "cinematic, moody, controlled energy, fixed camera",
}


class AIBackgroundGenerator:
    WIDTH = 1920
    HEIGHT = 1080
    TIMEOUT = 60
    MAX_RETRIES = 4
    MIN_REQUEST_GAP_SEC = 6.0

    def __init__(self):
        self.cache_dir = CACHE / "ai_backgrounds"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._last_request_at = 0.0

    def build_prompt(self, genre: str, mood: str, section_name: str) -> str:
        hint = SECTION_STYLE_HINTS.get(section_name.lower(), "cinematic, moody, fixed camera")
        try:
            from video.prompt_engine import build_prompt as build_rich_prompt
            return build_rich_prompt(genre, mood, hint)
        except ImportError:
            return (
                f"{genre} music video background, {mood} atmosphere, {hint}, "
                f"dark luxury underground club, volumetric fog, fixed camera, "
                f"photorealistic, ultra detailed, 8k, no text, no watermark"
            )

    def _cache_key(self, prompt: str, seed: int) -> str:
        h = hashlib.sha256(f"{prompt}|{seed}".encode()).hexdigest()[:16]
        return h

    def _throttle(self) -> None:
        elapsed = time.time() - self._last_request_at
        if elapsed < self.MIN_REQUEST_GAP_SEC:
            time.sleep(self.MIN_REQUEST_GAP_SEC - elapsed)
        self._last_request_at = time.time()

    def fetch(self, prompt: str, seed: int = 0) -> Path | None:
        key = self._cache_key(prompt, seed)
        cached = self.cache_dir / f"{key}.jpg"
        if cached.exists():
            return cached

        encoded_prompt = urllib.parse.quote(prompt)
        url = (
            f"{SETTINGS.pollinations_base}/prompt/{encoded_prompt}"
            f"?width={self.WIDTH}&height={self.HEIGHT}&seed={seed}&nologo=true&model=flux"
        )

        resp = None
        for attempt in range(1, self.MAX_RETRIES + 1):
            self._throttle()
            try:
                resp = requests.get(
                    url,
                    timeout=self.TIMEOUT,
                    headers={"User-Agent": "Mozilla/5.0 (compatible; UltimateStudio/1.0)"},
                )
            except requests.RequestException as exc:
                warning(f"AI BACKGROUND -> network error ({exc}), attempt {attempt}/{self.MAX_RETRIES}")
                resp = None
                time.sleep(2 ** attempt)
                continue

            if resp.status_code == 429:
                wait = 2 ** attempt * 3
                warning(f"AI BACKGROUND -> rate-limited (429), retrying in {wait}s (attempt {attempt}/{self.MAX_RETRIES})")
                time.sleep(wait)
                continue

            if resp.status_code >= 400:
                warning(f"AI BACKGROUND -> HTTP {resp.status_code}, attempt {attempt}/{self.MAX_RETRIES}")
                time.sleep(2 ** attempt)
                continue

            break
        else:
            warning("AI BACKGROUND -> all retries failed")
            return None

        if resp is None or resp.status_code >= 400:
            return None

        try:
            img = Image.open(io.BytesIO(resp.content)).convert("RGB")
            if img.size != (self.WIDTH, self.HEIGHT):
                img = img.resize((self.WIDTH, self.HEIGHT), Image.LANCZOS)
            img.save(cached, "JPEG", quality=92)
            info(f"AI BACKGROUND -> cached {cached.name}")
            return cached
        except Exception as exc:
            warning(f"AI BACKGROUND -> failed to decode/save image: {exc}")
            return None

    def generate_for_sections(self, genre: str, mood: str, section_names: list[str]) -> dict[str, Path]:
        """
        One image per unique section name. Returns {section_name: path}.
        """
        results: dict[str, Path] = {}
        for i, name in enumerate(section_names):
            prompt = self.build_prompt(genre, mood, name)
            path = self.fetch(prompt, seed=1000 + i * 17)
            if path:
                results[name] = path
        return results


ai_background_generator = AIBackgroundGenerator()