"""
UltimateStudio
video/renderer.py

Orchestrates the actual video render. The original version of this
file only ever wrote a JSON dump of the storyboard scenes and left a
comment saying real rendering (ffmpeg/moviepy/opencv) was a future
"V2" -- no video was ever produced. This now calls VisualEngine to
render a real, audio-reactive .mp4 and keeps the storyboard JSON as
a debug sidecar next to it.
"""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

from core.pipeline import Module
from core.logger import info
from core.registry import registry
from video.visual_engine import visual_engine


class VideoRenderer(Module):

    NAME = "Video Renderer"

    def render(self, project):
        storyboard = project.get_metadata("storyboard")

        if storyboard is None or not storyboard.scenes:
            info("VIDEO RENDER -> no storyboard, skipping")
            return None

        # debug sidecar: the planned scene list, useful for review even
        # though the render itself is audio-reactive rather than
        # scene-by-scene at this stage.
        sidecar = Path(project.video_file).with_suffix(".storyboard.json")
        sidecar.parent.mkdir(parents=True, exist_ok=True)
        with open(sidecar, "w", encoding="utf8") as f:
            json.dump(
                {
                    "project": project.get("id"),
                    "title": project.get("title"),
                    "genre": project.get("genre"),
                    "mood": project.get("mood"),
                    "duration": project.get("duration"),
                    "scene_count": len(storyboard.scenes),
                    "scenes": [asdict(scene) for scene in storyboard.scenes],
                },
                f,
                indent=4,
                ensure_ascii=False,
            )

        output = visual_engine.render(project)
        return output

    def execute(self, project):
        output = self.render(project)

        if output is None:
            return project

        project.add_metadata("video", {"output": str(output)})
        project["video_file"] = str(output)

        info(f"Video Render Finished -> {output.name}")

        return project


video_renderer = VideoRenderer()

registry.register("video_renderer", video_renderer)
