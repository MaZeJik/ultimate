"""
UltimateStudio
video/storyboard.py
"""

from __future__ import annotations

import random
from dataclasses import dataclass

from core.pipeline import Module
from core.logger import info
from core.registry import registry


# ==========================================================
# SCENE
# ==========================================================

@dataclass(slots=True)
class Scene:

    index: int

    section: str

    start: float

    duration: float

    background: str

    camera: str

    transition: str

    effects: list[str]

    prompt: str


# ==========================================================
# STORYBOARD
# ==========================================================

@dataclass(slots=True)
class Storyboard:

    scenes: list[Scene]

    total_duration: float


# ==========================================================
# ENGINE
# ==========================================================

class StoryboardEngine(Module):

    NAME = "Storyboard Engine"

    BACKGROUNDS = [

        "Cyber City",

        "Dark Forest",

        "Neon Street",

        "Tokyo Night",

        "Industrial Factory",

        "Abandoned Building",

        "Rain Highway",

        "Dark Space",

        "Future Skyline",

        "Underground Tunnel"

    ]

    CAMERAS = [

        "Static",

        "Slow Zoom",

        "Orbit",

        "Tracking",

        "Handheld",

        "Drone",

        "Tilt",

        "Pan"

    ]

    TRANSITIONS = [

        "Fade",

        "Flash",

        "Blur",

        "Zoom",

        "Whip",

        "Glitch"

    ]

    EFFECTS = [

        "Bloom",

        "Glow",

        "Fog",

        "Rain",

        "Dust",

        "Film Grain",

        "Chromatic",

        "Particles"

    ]

    # ======================================================

    def build(self, project):

        sections = project.get("arrangement") or []

        if not sections:
            return Storyboard(scenes=[], total_duration=project.get("duration", 0))

        duration = project.get("duration", 180)
        section_duration = duration / len(sections)

        scenes = []

        current = 0.0

        for index, section in enumerate(sections, start=1):

            section_name = section.get("name", f"section_{index}")

            scene = Scene(
                index=index,
                section=section_name,
                start=round(current, 2),
                duration=round(section_duration, 2),
                background=random.choice(self.BACKGROUNDS),
                camera=random.choice(self.CAMERAS),
                transition=random.choice(self.TRANSITIONS),
                effects=random.sample(self.EFFECTS, k=3),
                prompt=(
                    f"{project.get('genre', '')}, "
                    f"{project.get('mood', '')}, "
                    f"{section_name}, "
                    f"Cinematic, "
                    f"Ultra Realistic"
                ),
            )

            scenes.append(scene)
            current += section_duration

        return Storyboard(scenes=scenes, total_duration=duration)

    # ======================================================

    def execute(self, project):

        storyboard = self.build(

            project

        )

        project.add_metadata(

            "storyboard",

            storyboard

        )

        info(

            f"Storyboard Generated ({len(storyboard.scenes)} scenes)"

        )

        return project


storyboard_engine = StoryboardEngine()

registry.register("storyboard_engine", storyboard_engine)