"""
UltimateStudio
audio/bass.py

Bass engine with two distinct families:

  1. Trap / 808 style  — short pitch glide, bright attack → dark sustain
  2. House / Tech House — rolling, longer notes, filtered movement,
     almost no glide (the club "rolling bass" feel)

Genre is read from project so tech house tracks no longer get
trap-style 808 slides by accident.
"""

from __future__ import annotations

import numpy as np

from audio import dsp, theory
from core.logger import info
from core.registry import registry


HOUSE_GENRES = {
    "tech house", "deep house", "melodic house", "progressive house",
    "afro house", "festival house", "dark techno", "techno", "minimal",
}


class BassEngine:
    SAMPLE_RATE = dsp.SAMPLE_RATE

    # ------------------------------------------------------------------
    # trap / 808 note
    # ------------------------------------------------------------------

    def note_808(self, freq: float, length: int, glide_from: float | None = None) -> np.ndarray:
        t = np.arange(length) / self.SAMPLE_RATE

        if glide_from and glide_from != freq:
            glide_len = min(length, int(self.SAMPLE_RATE * 0.06))
            glide_env = np.linspace(0, 1, glide_len) ** 1.5
            freq_curve = np.full(length, freq, dtype=np.float32)
            freq_curve[:glide_len] = glide_from + (freq - glide_from) * glide_env
            phase = np.cumsum(2 * np.pi * freq_curve / self.SAMPLE_RATE)
        else:
            phase = 2 * np.pi * freq * t

        sub = np.sin(phase)
        third = np.sin(phase * 1.5) * 0.18
        wave = sub * 0.85 + third

        env = dsp.adsr(length, attack=0.004, decay=0.08, sustain=0.75, release=0.12, sample_rate=self.SAMPLE_RATE)
        wave = wave * env
        wave = dsp.swept_lowpass(wave, start_hz=1200, end_hz=180, sample_rate=self.SAMPLE_RATE)
        wave = dsp.saturate(wave, drive=1.6)
        return wave.astype(np.float32)

    # ------------------------------------------------------------------
    # house / tech-house rolling note
    # ------------------------------------------------------------------

    def note_rolling(self, freq: float, length: int, filter_mod: float = 0.0) -> np.ndarray:
        """
        Longer sustain, soft attack, mild saturation, and a slow
        filter movement — the classic tech-house rolling bass feel.
        """
        t = np.arange(length) / self.SAMPLE_RATE
        phase = 2 * np.pi * freq * t

        # pure sub + a little mid harmonic for small speakers
        sub = np.sin(phase)
        mid = np.sin(phase * 2.0) * 0.12
        wave = sub * 0.88 + mid

        # soft attack, long sustain, short release so notes connect
        env = dsp.adsr(
            length,
            attack=0.012,
            decay=0.04,
            sustain=0.88,
            release=0.08,
            sample_rate=self.SAMPLE_RATE,
        )
        wave = wave * env

        # filter: starts a bit open, settles lower (gives movement without glide)
        start_hz = 420 + filter_mod * 280
        end_hz = 140 + filter_mod * 60
        wave = dsp.swept_lowpass(wave, start_hz=start_hz, end_hz=end_hz, sample_rate=self.SAMPLE_RATE)
        wave = dsp.saturate(wave, drive=1.25)
        return wave.astype(np.float32)

    # ------------------------------------------------------------------

    def execute(self, project):
        producer = project.get("producer_brain", {})
        samples = project.get("samples", {})
        dna = project.get("genre_dna", {})

        bpm = producer.get("bpm", project.get("bpm", 140))
        bars = producer.get("bars", 64)
        genre = str(project.get("genre", "dark trap")).lower()

        is_house = genre in HOUSE_GENRES or dna.get("bass") in ("rolling", "deep_sub", "filtered", "acid_bass")

        beat_samples = int(60 / bpm * self.SAMPLE_RATE)
        total = beat_samples * bars * 4
        audio = np.zeros(total, dtype=np.float32)

        if is_house:
            # house patterns: root-heavy, longer notes, fewer changes
            pattern_options = {
                "root_pulse": [0, 0, 0, 0],
                "root_fifth": [0, 0, 5, 5],
                "walking_house": [0, 0, 3, 5],
                "octave_roll": [0, 7, 0, 7],
                "minor_drive": [0, 0, 5, 3],
            }
            note_len = int(beat_samples * 1.85)   # almost 2 beats long → rolling feel
        else:
            pattern_options = {
                "root_heavy": [0, 0, 5, 4],
                "walking": [0, 2, 4, 5],
                "octave_bounce": [0, 7, 0, 5],
                "descending": [7, 5, 3, 0],
                "syncopated_root": [0, 0, 0, 4],
                "fifth_drive": [0, 4, 5, 4],
            }
            note_len = int(beat_samples * 0.95)

        try:
            from core.variation_tracker import variation_tracker
            pattern_name = variation_tracker.choose("bass:pattern", list(pattern_options.keys()))
        except ImportError:
            import random
            pattern_name = random.choice(list(pattern_options.keys()))

        degree_pattern = pattern_options[pattern_name]
        prev_freq = None

        # house: place a note every 2 beats (rolling)
        # trap: place a note every beat
        step = 2 if is_house else 1

        for beat in range(0, bars * 4, step):
            degree = degree_pattern[(beat // step) % len(degree_pattern)]
            freq = theory.degree_freq(project, degree, octave=1)

            if is_house:
                # mild filter modulation so consecutive notes don't sound identical
                filter_mod = 0.15 * np.sin(beat * 0.35)
                wave = self.note_rolling(freq, note_len, filter_mod=filter_mod)
            else:
                wave = self.note_808(freq, note_len, glide_from=prev_freq if beat % 4 != 0 else None)

            prev_freq = freq
            pos = beat * beat_samples
            end = min(total, pos + note_len)
            gain = 0.90 if is_house else 0.92
            audio[pos:end] += wave[: end - pos] * gain

        audio = dsp.soft_clip(audio, 0.88 if is_house else 0.9)

        project["bass_audio"] = audio
        project["bass_info"] = {
            "sample": samples.get("808"),
            "bpm": bpm,
            "bars": bars,
            "notes": (bars * 4) // step,
            "key": project.get("key"),
            "scale": project.get("scale"),
            "style": "rolling_house" if is_house else "808_trap",
            "synthesis": "dsp-v3",
        }

        info(
            f"BASS ENGINE -> {genre} | style={'rolling' if is_house else '808'} | "
            f"{project.get('key', '?')} {project.get('scale', '?')}"
        )
        return project


bass_engine = BassEngine()
registry.register("bass_engine", bass_engine)