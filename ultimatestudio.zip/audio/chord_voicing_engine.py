"""
UltimateStudio
audio/chord_voicing_engine.py
"""

from __future__ import annotations

import random

from core.logger import info
from core.registry import registry


class ChordVoicingEngine:

    NAME = "Chord Voicing Engine"

    # =====================================================

    VOICINGS = {

        "maj": [

            [0, 4, 7],
            [0, 7, 12],
            [0, 4, 11],
            [0, 7, 16],

        ],

        "min": [

            [0, 3, 7],
            [0, 7, 12],
            [0, 3, 10],
            [0, 7, 15],

        ],

    }

    # =====================================================

    def chord_type(self, chord):

        if "m" in chord and "maj" not in chord:

            return "min"

        return "maj"

    # =====================================================

    def root_note(self, chord):

        roots = {

            "C":60,
            "C#":61,
            "Db":61,
            "D":62,
            "D#":63,
            "Eb":63,
            "E":64,
            "F":65,
            "F#":66,
            "Gb":66,
            "G":67,
            "G#":68,
            "Ab":68,
            "A":69,
            "A#":70,
            "Bb":70,
            "B":71,

        }

        for key in sorted(

            roots.keys(),

            key=len,

            reverse=True,

        ):

            if chord.startswith(key):

                return roots[key]

        return 60

    # =====================================================

    def build(self, chord):

        root = self.root_note(chord)

        quality = self.chord_type(chord)

        pattern = random.choice(

            self.VOICINGS[quality]

        )

        return [

            root + i

            for i

            in pattern

        ]

    # =====================================================

    def execute(self, project):

        harmony = project.get(

            "harmony",

            {},

        )

        voiced = {}

        for section, chords in harmony.items():

            voiced[section] = [

                self.build(ch)

                for ch

                in chords

            ]

        project["voiced_chords"] = voiced

        info("CHORD VOICING COMPLETE")

        return project


chord_voicing_engine = ChordVoicingEngine()

registry.register(

    "chord_voicing_engine",

    chord_voicing_engine,

)