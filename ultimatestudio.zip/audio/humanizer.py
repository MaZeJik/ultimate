"""
UltimateStudio
audio/humanizer_engine.py
"""

from __future__ import annotations

import random

from core.logger import info
from core.registry import registry


class HumanizerEngine:

    NAME = "Humanizer Engine"

    # =====================================================

    def velocity(self, value):

        value += random.randint(-10, 10)

        value = max(40, value)

        value = min(127, value)

        return value

    # =====================================================

    def timing(self, step):

        shift = random.choice(
            [
                -0.05,
                -0.025,
                0,
                0.025,
                0.05,
            ]
        )

        return step + shift

    # =====================================================

    def note_length(self):

        return random.uniform(
            0.85,
            1.15,
        )

    # =====================================================

    def process(self, notes):

        result = []

        for note in notes:

            n = dict(note)

            n["velocity"] = self.velocity(
                note.get(
                    "velocity",
                    90,
                )
            )

            n["step"] = self.timing(
                note.get(
                    "step",
                    0,
                )
            )

            n["gate"] = self.note_length()

            result.append(n)

        return result

    # =====================================================

    def execute(self, project):

        if "melody" in project:

            project["melody"] = self.process(
                project["melody"]
            )

        if "counter_melody" in project:

            project["counter_melody"] = self.process(
                project["counter_melody"]
            )

        if "bass_notes" in project:

            project["bass_notes"] = self.process(
                project["bass_notes"]
            )

        if "piano_notes" in project:

            project["piano_notes"] = self.process(
                project["piano_notes"]
            )

        info("HUMANIZER COMPLETE")

        return project


humanizer_engine = HumanizerEngine()

registry.register(
    "humanizer_engine",
    humanizer_engine,
)