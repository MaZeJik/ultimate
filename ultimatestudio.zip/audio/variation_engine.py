"""
UltimateStudio
audio/variation_engine.py
"""

from __future__ import annotations

import copy
import random

from core.logger import info
from core.registry import registry


class VariationEngine:

    NAME = "Variation Engine"

    # =====================================================

    def vary_velocity(self, note):

        note["velocity"] = max(
            45,
            min(
                127,
                note.get("velocity", 90)
                + random.randint(-8, 8),
            ),
        )

    # =====================================================

    def octave_jump(self, note):

        if random.random() < 0.08:

            note["note"] += random.choice(
                [-12, 12]
            )

    # =====================================================

    def remove_note(self, notes):

        if len(notes) < 8:

            return notes

        index = random.randint(
            0,
            len(notes) - 1,
        )

        del notes[index]

        return notes

    # =====================================================

    def duplicate_note(self, notes):

        if not notes:

            return notes

        note = copy.deepcopy(
            random.choice(notes)
        )

        note["step"] += 0.25

        notes.append(note)

        return notes

    # =====================================================

    def mutate(self, notes):

        notes = copy.deepcopy(notes)

        for note in notes:

            self.vary_velocity(note)

            self.octave_jump(note)

        if random.random() < 0.35:

            notes = self.remove_note(notes)

        if random.random() < 0.35:

            notes = self.duplicate_note(notes)

        notes.sort(
            key=lambda x: (
                x["bar"],
                x["step"],
            )
        )

        return notes

    # =====================================================

    def execute(self, project):

        targets = [

            "melody",

            "counter_melody",

            "bass_notes",

            "piano_notes",

        ]

        processed = 0

        for target in targets:

            if target not in project:

                continue

            project[target] = self.mutate(
                project[target]
            )

            processed += 1

        project["variation"] = {

            "processed": processed

        }

        info(
            f"VARIATION -> {processed} tracks"
        )

        return project


variation_engine = VariationEngine()

registry.register(
    "variation_engine",
    variation_engine,
)