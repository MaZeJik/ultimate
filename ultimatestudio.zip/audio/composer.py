from __future__ import annotations

import random

from core.registry import registry
from core.logger import info


class Composer:

    PROGRESSIONS = {

        "minor": [

            ["i", "VI", "III", "VII"],
            ["i", "iv", "VI", "V"],
            ["i", "VII", "VI", "VII"],
            ["i", "VI", "iv", "V"],

        ],

        "major": [

            ["I", "V", "vi", "IV"],
            ["I", "IV", "V", "IV"],
            ["vi", "IV", "I", "V"],

        ],

    }

    KEYS = [

        "C","C#","D","D#","E",
        "F","F#","G","G#","A",
        "A#","B"

    ]

    def execute(self, project):

        genre = (project.get("genre") or "dark trap").lower()

        mood = (project.get("mood") or "dark").lower()

        bpm = project.get(
            "bpm",
            140
        )

        scale = "minor"

        if "happy" in mood:

            scale = "major"

        key = project.get(

            "key",

            random.choice(self.KEYS)

        )

        progression = random.choice(

            self.PROGRESSIONS[scale]

        )

        composition = {

            "genre": genre,

            "mood": mood,

            "key": key,

            "scale": scale,

            "bpm": bpm,

            "progression": progression,

            "hook_style": "dark",

            "drop_style": "trap",

            "melody_style": "modern",

            "bass_style": "808",

            "synth_style": "analog",

            "swing": 0.12,

            "groove": 0.18,

        }

        project["composition"] = composition

        project["key"] = key

        project["scale"] = scale

        info(

            f"COMPOSER -> {key} {scale}"

        )

        return project


composer = Composer()

registry.register(

    "composer",

    composer

)