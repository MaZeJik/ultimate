"""
UltimateStudio
audio/midi_exporter.py
"""

from __future__ import annotations

from core.config import OUTPUT_MIDI
from core.logger import info
from core.registry import registry

try:
    from midiutil import MIDIFile
except ImportError:
    MIDIFile = None


class MidiExporter:
    # (label, project key). Not every key is produced by every run --
    # only melody_notes and counter_notes exist today, the rest are
    # here so the exporter picks them up automatically if/when those
    # engines start recording note-level data too.
    TRACKS = [
        ("melody", "melody_notes"),
        ("counter", "counter_notes"),
        ("piano", "piano_notes"),
        ("bass", "bass_notes"),
        ("drums", "drum_notes"),
    ]

    DEFAULT_DURATION = 0.5

    def _normalize_note(self, note, index: int):
        """
        Each instrument engine records notes in its own shape:
          - melody_notes: {"bar": int, "midi": int, "freq": float}
          - counter_notes: a bare MIDI pitch integer
          - a fuller {"pitch"/"midi", "start", "duration", "velocity"} dict

        Normalize any of these into one consistent
        {"pitch", "start", "duration", "velocity"} shape, or return
        None if it isn't usable.
        """
        if isinstance(note, dict):
            pitch = note.get("pitch", note.get("midi"))
            if pitch is None:
                return None
            return {
                "pitch": int(pitch),
                "start": float(note.get("start", note.get("bar", index) * self.DEFAULT_DURATION)),
                "duration": float(note.get("duration", self.DEFAULT_DURATION)),
                "velocity": int(note.get("velocity", 100)),
            }

        if isinstance(note, (int, float)):
            return {
                "pitch": int(note),
                "start": index * self.DEFAULT_DURATION,
                "duration": self.DEFAULT_DURATION,
                "velocity": 100,
            }

        return None

    def execute(self, project):
        if MIDIFile is None:
            info("MIDI EXPORT -> midiutil not installed")
            return project

        bpm = project.get("bpm", 140)
        midi = MIDIFile(1)
        midi.addTempo(0, 0, bpm)

        exported_tracks = 0

        for _, key in self.TRACKS:
            raw_notes = project.get(key)
            if not raw_notes:
                continue

            exported_tracks += 1
            for index, raw_note in enumerate(raw_notes):
                note = self._normalize_note(raw_note, index)
                if note is None:
                    continue
                midi.addNote(
                    track=0,
                    channel=0,
                    pitch=note["pitch"],
                    time=note["start"],
                    duration=note["duration"],
                    volume=note["velocity"],
                )

        if exported_tracks == 0:
            info("MIDI EXPORT -> no note data available")
            return project

        OUTPUT_MIDI.mkdir(parents=True, exist_ok=True)

        title = project.get("title") or project.get("genre") or "ultimate_track"
        filename = str(title).replace(" ", "_").replace("/", "_")
        project_id = (project.get("id") or "")[:8]
        if project_id:
            filename = f"{filename}_{project_id}"

        outfile = OUTPUT_MIDI / f"{filename}.mid"
        with open(outfile, "wb") as f:
            midi.writeFile(f)

        project["midi_file"] = str(outfile)
        info(f"MIDI EXPORTED -> {outfile}")

        return project


midi_exporter = MidiExporter()

registry.register("midi_exporter", midi_exporter)
