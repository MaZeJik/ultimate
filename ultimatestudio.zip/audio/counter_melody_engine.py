"""
UltimateStudio
audio/counter_melody_engine.py

Higher-register answer to the lead.

House: only active on high-energy sections conceptually (engine still
writes full buffer; mixer/producer_map decides presence). Pattern is
sparser and quieter so it doesn't fight the groove.
"""

from __future__ import annotations

import random

import numpy as np

from audio import dsp, theory
from core.logger import info
from core.registry import registry


HOUSE_GENRES = {
    "tech house", "deep house", "melodic house", "progressive house",
    "afro house", "festival house", "dark techno", "techno", "minimal",
}


class CounterMelodyEngine:
    SAMPLE_RATE = dsp.SAMPLE_RATE

    def osc(self, freq: float, length: int, house: bool = False) -> np.ndarray:
        t = np.arange(length, dtype=np.float32) / self.SAMPLE_RATE
        if house:
            wave = 0.80 * np.sin(2 * np.pi * freq * t) + 0.15 * np.sin(2 * np.pi * freq * 2.0 * t)
            env = dsp.adsr(
                length, attack=0.01, decay=0.10, sustain=0.30, release=0.15,
                sample_rate=self.SAMPLE_RATE,
            )
        else:
            wave = 0.70 * np.sin(2 * np.pi * freq * t) + 0.30 * np.sin(2 * np.pi * freq * 3.0 * t)
            env = dsp.adsr(
                length, attack=0.02, decay=0.15, sustain=0.5, release=0.25,
                sample_rate=self.SAMPLE_RATE,
            )
        return (wave * env).astype(np.float32)

    def execute(self, project):
        producer = project.get("producer_brain", {})
        genre = str(project.get("genre", "")).lower()
        is_house = genre in HOUSE_GENRES or "house" in genre or "techno" in genre

        bpm = producer.get("bpm", project.get("bpm", 124 if is_house else 140))
        bars = producer.get("bars", 64)

        beat_samples = int((60.0 / bpm) * self.SAMPLE_RATE)
        total_samples = beat_samples * bars * 4
        audio = np.zeros(total_samples, dtype=np.float32)

        scale = theory.scale_for(project.get("scale", "minor"))
        root = theory.root_midi(project, octave=5 if is_house else 5)

        if is_house:
            motif = [5, -1, 3, -1]   # sparse
            gain = 0.12
            mutate = 0.20
        else:
            motif = [6, 5, 3, 2]
            gain = 0.18
            mutate = 0.35

        notes = []
        for bar in range(bars):
            seq = motif.copy()
            if random.random() < mutate:
                idx = random.randrange(len(seq))
                seq[idx] = random.randrange(len(scale)) if seq[idx] >= 0 else seq[idx]

            for step, degree in enumerate(seq):
                if degree < 0:
                    continue
                degree = degree % len(scale)
                midi = root + scale[degree]
                freq = theory.note_freq(midi)

                wave = self.osc(freq, beat_samples, house=is_house)
                wave *= gain

                start = bar * beat_samples * 4 + step * beat_samples
                end = min(total_samples, start + beat_samples)
                if start >= total_samples:
                    continue
                audio[start:end] += wave[: end - start]
                notes.append(midi)

        audio = dsp.normalize(dsp.soft_clip(audio, 0.88), 0.92)

        project["counter_audio"] = audio
        project["counter_notes"] = notes
        info(f"COUNTER MELODY -> {len(notes)} notes | {'sparse house' if is_house else 'trap'} | {bars} bars")
        return project


counter_melody_engine = CounterMelodyEngine()
registry.register("counter_melody_engine", counter_melody_engine)