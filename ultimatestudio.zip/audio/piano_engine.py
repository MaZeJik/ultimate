"""
UltimateStudio
audio/piano_engine.py

Chord / keys layer.

Trap: present mid-energy chords.
House: very soft sustained pad-like chords (or near-silent) so the
four-on-floor + bass stay in focus — matches producer_brain house map
(piano=False by default on house).
"""

from __future__ import annotations

import numpy as np

from audio import dsp, theory
from core.logger import info
from core.registry import registry


HOUSE_GENRES = {
    "tech house", "deep house", "melodic house", "progressive house",
    "afro house", "festival house", "dark techno", "techno", "minimal",
}


class PianoEngine:
    SAMPLE_RATE = dsp.SAMPLE_RATE

    CHORDS = [
        [0, 3, 7],
        [5, 8, 12],
        [7, 10, 14],
        [3, 7, 10],
    ]

    def osc(self, freq: float, length: int, soft: bool = False) -> np.ndarray:
        t = np.arange(length) / self.SAMPLE_RATE
        wave = (
            np.sin(2 * np.pi * freq * t)
            + 0.25 * np.sin(2 * np.pi * freq * 2 * t)
            + 0.15 * np.sin(2 * np.pi * freq * 3 * t)
        )
        if soft:
            env = dsp.adsr(
                length, attack=0.08, decay=0.6, sustain=0.45, release=0.9,
                sample_rate=self.SAMPLE_RATE,
            )
        else:
            env = dsp.adsr(
                length, attack=0.015, decay=0.5, sustain=0.55, release=0.6,
                sample_rate=self.SAMPLE_RATE,
            )
        return (wave * env).astype(np.float32)

    def execute(self, project):
        producer = project.get("producer_brain", {})
        samples = project.get("samples", {})
        genre = str(project.get("genre", "")).lower()
        is_house = genre in HOUSE_GENRES or "house" in genre or "techno" in genre

        bpm = producer.get("bpm", project.get("bpm", 124 if is_house else 140))
        bars = producer.get("bars", 64)

        beat = int(60 / bpm * self.SAMPLE_RATE)
        total = beat * bars * 4
        audio = np.zeros(total, dtype=np.float32)

        root = theory.root_midi(project, octave=3)
        # house: much quieter pad; trap: normal chord bed
        voice_gain = 0.04 if is_house else 0.12

        for bar in range(bars):
            chord = self.CHORDS[bar % len(self.CHORDS)]
            start = bar * beat * 4
            length = beat * 4

            for note in chord:
                freq = theory.note_freq(root + note)
                wave = self.osc(freq, length, soft=is_house)
                wave *= voice_gain
                end = min(total, start + length)
                audio[start:end] += wave[: end - start]

        audio = dsp.soft_clip(audio, 0.85 if is_house else 0.9)

        project["piano_audio"] = audio
        project["piano_info"] = {
            "sample": samples.get("piano"),
            "bars": bars,
            "bpm": bpm,
            "voices": 3,
            "key": project.get("key"),
            "style": "soft_pad" if is_house else "chord_bed",
        }

        info(f"PIANO -> {bars} chords | {'soft pad (house)' if is_house else 'chord bed'} | {project.get('key', '?')}")
        return project


piano_engine = PianoEngine()
registry.register("piano_engine", piano_engine)