"""
UltimateStudio
audio/velocity_engine.py
"""

from __future__ import annotations

import random

from core.logger import info
from core.registry import registry


class VelocityEngine:

    NAME = "Velocity Engine"

    # =====================================================

    def section_multiplier(self, energy):

        if energy >= 0.90:
            return 1.20

        if energy >= 0.70:
            return 1.10

        if energy >= 0.50:
            return 1.00

        if energy >= 0.30:
            return 0.90

        return 0.80

    # =====================================================

    def process(self, notes, sections):

        if not notes:
            return notes

        bars_per_section = {}

        current = 0

        for section in sections:

            start = current
            end = current + section["bars"]

            bars_per_section[(start, end)] = section["energy"]

            current = end

        for note in notes:

            energy = 0.5

            for (start, end), value in bars_per_section.items():

                if start <= note["bar"] < end:

                    energy = value

                    break

            velocity = note.get("velocity", 90)

            velocity *= self.section_multiplier(energy)

            velocity += random.randint(-5, 5)

            velocity = max(40, min(127, int(velocity)))

            note["velocity"] = velocity

        return notes

    # =====================================================

    def execute(self, project):

        sections = project.get(
            "composition_plan",
            {},
        ).get(
            "sections",
            [],
        )

        if not sections:

            info("VELOCITY -> SKIPPED")

            return project

        targets = [

            "melody",

            "counter_melody",

            "bass_notes",

            "piano_notes",

        ]

        processed = 0

        for target in targets:

            notes = project.get(target)

            if notes is None:

                continue

            project[target] = self.process(
                notes,
                sections,
            )

            processed += 1

        project["velocity"] = {

            "processed_tracks": processed

        }

        info(
            f"VELOCITY -> {processed} tracks"
        )

        return project


velocity_engine = VelocityEngine()

registry.register(
    "velocity_engine",
    velocity_engine,
)