from __future__ import annotations

from pathlib import Path
import random

from core.registry import registry
from core.logger import info


class SampleLoader:

    ROOT = Path("assets/samples")

    SAMPLE_TYPES = {

        "kick": "drums/kick",
        "snare": "drums/snare",
        "clap": "drums/clap",
        "hat": "drums/hat",
        "open_hat": "drums/openhat",
        "perc": "drums/perc",
        "crash": "drums/crash",

        "808": "bass/808",
        "bass": "bass",

        "piano": "piano",
        "synth": "synth",
        "pad": "pad",
        "counter": "counter",

        "fx": "fx",
        "impact": "fx/impact",
        "riser": "fx/riser",

        "atmosphere": "atmosphere"

    }

    def choose(self, folder):

        path = self.ROOT / folder

        if not path.exists():

            return None

        files = []

        for ext in ("*.wav","*.mp3","*.flac"):

            files.extend(path.glob(ext))

        if not files:

            return None

        return str(random.choice(files))

    def execute(self, project):

        samples = {}

        missing = []

        for key, folder in self.SAMPLE_TYPES.items():

            sample = self.choose(folder)

            samples[key] = sample

            if sample is None:

                missing.append(key)

        project["samples"] = samples

        info(f"SAMPLE LOADER -> {len(samples)-len(missing)}/{len(samples)} loaded")

        if missing:

            info(f"MISSING -> {', '.join(missing)}")

        return project


sample_loader = SampleLoader()

registry.register(
    "sample_loader",
    sample_loader
)