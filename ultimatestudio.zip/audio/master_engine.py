"""
UltimateStudio
audio/master_engine.py

Final mastering chain: DC-blocking highpass -> saturation -> 2-band
(low/high) compression -> loudness normalization -> stereo widening
-> a lookahead brickwall limiter.

Two upgrades over the previous version:

  1. The single-band compressor treated the whole mix as one signal,
     so a loud kick/808 hit would pull gain down on the cymbals and
     vocals riding along with it too ("pumping"). Splitting into a
     low band (sub/kick/808, compressed harder) and a high band
     (everything else, compressed lighter) is standard practice in
     commercial mastering specifically to avoid that.
  2. The final stage was a plain `tanh()` soft-clip -- simple, but it
     audibly saturates/distorts anything that actually needs limiting
     (it's a waveshaper, not a limiter). A real limiter needs to
     *reduce gain* ahead of a peak, not distort the peak itself. This
     adds a short lookahead peak limiter (look a few ms ahead, ramp
     gain down smoothly before the peak, back up after) for a louder,
     cleaner master with less audible distortion.

(The earlier fix here -- vectorizing the highpass filter, which used
to be a pure-Python per-sample loop -- still applies.)
"""

from __future__ import annotations

import numpy as np
from scipy.signal import lfilter

from core.logger import info
from core.registry import registry


class MasterEngine:
    TARGET_PEAK = 0.83  # average of two independent reference measurements (~0.79, ~0.86)
    TARGET_RMS = 0.195  # average of two independent reference measurements (~0.208, ~0.187)
    HIGHPASS_ALPHA = 0.995
    CROSSOVER_HZ = 180.0  # low/high split point for 2-band compression

    LOW_THRESHOLD = 0.62
    LOW_RATIO = 2.2
    HIGH_THRESHOLD = 0.78
    HIGH_RATIO = 1.6

    LIMITER_LOOKAHEAD_MS = 5.0
    LIMITER_RELEASE_MS = 60.0

    def highpass(self, audio: np.ndarray) -> np.ndarray:
        """DC-blocking one-pole highpass, vectorized per channel."""
        alpha = self.HIGHPASS_ALPHA
        b = [alpha, -alpha]
        a = [1.0, -alpha]
        return lfilter(b, a, audio, axis=-1).astype(np.float32)

    def saturator(self, audio: np.ndarray) -> np.ndarray:
        return np.tanh(audio * 1.08)

    def _band_split(self, audio: np.ndarray, sample_rate: int = 44100):
        from scipy.signal import butter

        b_lo, a_lo = butter(4, self.CROSSOVER_HZ / (sample_rate / 2), btype="low")
        low = lfilter(b_lo, a_lo, audio, axis=-1).astype(np.float32)
        high = (audio - low).astype(np.float32)
        return low, high

    def _compress(self, audio: np.ndarray, threshold: float, ratio: float) -> np.ndarray:
        out = audio.copy()
        mask = np.abs(out) > threshold
        out[mask] = np.sign(out[mask]) * (threshold + (np.abs(out[mask]) - threshold) / ratio)
        return out

    def compressor(self, audio: np.ndarray, sample_rate: int = 44100) -> np.ndarray:
        """2-band compression: the low band (kick/808/sub) is
        controlled independently from the high band so a heavy low-end
        hit doesn't pump/duck the rest of the mix."""
        low, high = self._band_split(audio, sample_rate)
        low = self._compress(low, self.LOW_THRESHOLD, self.LOW_RATIO)
        high = self._compress(high, self.HIGH_THRESHOLD, self.HIGH_RATIO)
        return (low + high).astype(np.float32)

    def rms(self, audio: np.ndarray) -> float:
        return float(np.sqrt(np.mean(audio**2)))

    def loudness(self, audio: np.ndarray) -> np.ndarray:
        rms = self.rms(audio)
        if rms > 0:
            audio = audio * (self.TARGET_RMS / rms)
        return audio

    def normalize(self, audio: np.ndarray) -> np.ndarray:
        peak = np.max(np.abs(audio))
        if peak > 0:
            audio = audio * (self.TARGET_PEAK / peak)
        return audio

    def stereo_width(self, audio: np.ndarray) -> np.ndarray:
        left, right = audio[0], audio[1]
        mid = (left + right) * 0.5
        side = (left - right) * 0.5
        side *= 1.20
        return np.stack([mid + side, mid - side])

    def exciter(self, audio: np.ndarray, sample_rate: int = 44100, amount: float = 0.05) -> np.ndarray:
        """
        A harmonic exciter: isolate the high end (above ~3.5kHz),
        run it through a soft saturator to generate subtle new
        harmonics, then blend a small amount back in on top of the
        untouched full-band signal. This is what gives a commercial
        master its "sheen"/"air" on top -- straightforward EQ boosts
        just make existing highs louder, an exciter adds harmonic
        content that wasn't there before, which reads as clarity
        rather than harshness.
        """
        from audio.dsp import highpass as dsp_highpass

        high = dsp_highpass(audio, 3500, sample_rate, order=2)
        excited = np.tanh(high * 3.0) * 0.6
        return (audio + excited * amount).astype(np.float32)

    def limiter(self, audio: np.ndarray, sample_rate: int = 44100) -> np.ndarray:
        """
        A real (if simple) lookahead brickwall limiter: for every
        sample, look a few ms ahead for the loudest upcoming peak and
        compute the gain needed to keep it under TARGET_PEAK, then
        smooth that gain curve (fast attack, slower release) so it
        reduces level ahead of transients instead of clipping/
        distorting them the way a plain tanh waveshaper does.
        """
        lookahead = max(1, int(sample_rate * self.LIMITER_LOOKAHEAD_MS / 1000))
        release = max(1, int(sample_rate * self.LIMITER_RELEASE_MS / 1000))

        peak_env = np.max(np.abs(audio), axis=0)  # mono envelope across channels
        n = len(peak_env)

        # rolling max lookahead via a simple maximum filter (vectorized)
        from scipy.ndimage import maximum_filter1d

        future_peak = maximum_filter1d(peak_env, size=lookahead, mode="nearest", origin=-(lookahead // 2))

        target = self.TARGET_PEAK
        desired_gain = np.where(future_peak > target, target / np.maximum(future_peak, 1e-9), 1.0).astype(np.float32)

        # smooth the gain curve: fast to duck (attack), slow to recover (release)
        smoothed = np.empty_like(desired_gain)
        g = 1.0
        attack_coeff = 0.35
        release_coeff = 1.0 / release
        for i in range(n):
            target_g = desired_gain[i]
            if target_g < g:
                g += (target_g - g) * attack_coeff
            else:
                g += (target_g - g) * release_coeff
            smoothed[i] = g

        limited = audio * smoothed[np.newaxis, :]
        # final hard safety clip -- should rarely trigger given the above
        return np.clip(limited, -1.0, 1.0).astype(np.float32)

    def execute(self, project):
        mix = project.get("final_mix")

        if mix is None:
            info("MASTER -> no mix")
            return project

        mix = np.asarray(mix, dtype=np.float32)
        if mix.ndim == 1:
            mix = np.vstack([mix, mix])

        sample_rate = 44100

        mix = self.highpass(mix)
        mix = self.saturator(mix)
        mix = self.compressor(mix, sample_rate)
        mix = self.loudness(mix)
        mix = self.stereo_width(mix)
        mix = self.exciter(mix, sample_rate)
        mix = self.limiter(mix, sample_rate)

        project["master_audio"] = mix
        project["master_info"] = {
            "peak": float(np.max(np.abs(mix))),
            "rms": self.rms(mix),
            "channels": 2,
            "samples": int(mix.shape[1]),
            "sample_rate": sample_rate,
            "mastering": "2-band-compression + lookahead-limiter",
        }

        info(
            f"MASTER COMPLETE | Peak={project['master_info']['peak']:.3f} "
            f"RMS={project['master_info']['rms']:.3f}"
        )

        return project


master_engine = MasterEngine()

registry.register("master_engine", master_engine)
