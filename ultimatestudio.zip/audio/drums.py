"""
UltimateStudio
audio/drums.py

Full drum synthesis with genre-specific patterns.

Tech House / House family now has real four-on-the-floor + offbeat
closed hats + light claps — the rhythmic signature that channels
like Synapse Melodic are built on. Trap/phonk/drill patterns kept.
"""

from __future__ import annotations

import numpy as np

from audio import dsp
from core.logger import info
from core.registry import registry


# per-genre rhythmic signature
GENRE_PATTERNS = {
    # --- trap family ---
    "dark trap": dict(
        kick=[0, 2, 2.75], snare=[1], clap=[3],
        four_on_floor=False, cowbell=False, swing=0.0, hat_density=1.0, gain=1.0,
    ),
    "cinematic trap": dict(
        kick=[0, 2], snare=[1], clap=[3],
        four_on_floor=False, cowbell=False, swing=0.0, hat_density=0.9, gain=0.95,
    ),
    "phonk": dict(
        kick=[0, 1.5, 2, 3.5], snare=[1], clap=[3],
        four_on_floor=False, cowbell=True, swing=0.08, hat_density=1.0, gain=1.05,
    ),
    "drill": dict(
        kick=[0, 1.75, 2.5], snare=[2], clap=[],
        four_on_floor=False, cowbell=False, swing=0.12, hat_density=1.1, gain=1.0,
    ),

    # --- house / tech house family (Synapse competitive) ---
    "tech house": dict(
        kick=[0, 1, 2, 3], snare=[], clap=[1, 3],
        four_on_floor=True, cowbell=False, swing=0.0, hat_density=0.85, gain=1.0,
        offbeat_hat=True,
    ),
    "deep house": dict(
        kick=[0, 1, 2, 3], snare=[], clap=[1, 3],
        four_on_floor=True, cowbell=False, swing=0.02, hat_density=0.75, gain=0.95,
        offbeat_hat=True,
    ),
    "melodic house": dict(
        kick=[0, 1, 2, 3], snare=[], clap=[1, 3],
        four_on_floor=True, cowbell=False, swing=0.0, hat_density=0.80, gain=1.0,
        offbeat_hat=True,
    ),
    "progressive house": dict(
        kick=[0, 1, 2, 3], snare=[], clap=[1, 3],
        four_on_floor=True, cowbell=False, swing=0.0, hat_density=0.90, gain=1.02,
        offbeat_hat=True,
    ),
    "afro house": dict(
        kick=[0, 1, 2, 3], snare=[], clap=[1, 3],
        four_on_floor=True, cowbell=False, swing=0.04, hat_density=1.05, gain=1.0,
        offbeat_hat=True, perc_extra=True,
    ),
    "festival house": dict(
        kick=[0, 1, 2, 3], snare=[], clap=[1, 3],
        four_on_floor=True, cowbell=False, swing=0.0, hat_density=1.0, gain=1.05,
        offbeat_hat=True,
    ),
    "dark techno": dict(
        kick=[0, 1, 2, 3], snare=[], clap=[1, 3],
        four_on_floor=True, cowbell=False, swing=0.0, hat_density=0.65, gain=0.98,
        offbeat_hat=True,
    ),

    # --- other ---
    "future bass": dict(
        kick=[0, 1.5], snare=[], clap=[2],
        four_on_floor=False, cowbell=False, swing=0.0, hat_density=0.8, gain=1.0,
    ),
    "melodic dubstep": dict(
        kick=[0, 1.5], snare=[], clap=[2],
        four_on_floor=False, cowbell=False, swing=0.0, hat_density=0.7, gain=1.0,
    ),
    "lo-fi": dict(
        kick=[0, 2.75], snare=[2], clap=[],
        four_on_floor=False, cowbell=False, swing=0.12, hat_density=0.6, gain=0.85,
    ),
}

DEFAULT_PATTERN = GENRE_PATTERNS["dark trap"]


class DrumEngine:
    SAMPLE_RATE = dsp.SAMPLE_RATE

    # ------------------------------------------------------
    # synthesis primitives
    # ------------------------------------------------------

    def kick(self, length: int) -> np.ndarray:
        t = np.arange(length) / self.SAMPLE_RATE
        # pitch drop from ~180 Hz → 45 Hz
        freq = 45 + 135 * np.exp(-t * 28)
        phase = np.cumsum(2 * np.pi * freq / self.SAMPLE_RATE)
        body = np.sin(phase)
        click = dsp.highpass(dsp.noise(length), 3000) * dsp.exp_decay(length, rate=80) * 0.35
        env = dsp.exp_decay(length, rate=9)
        return dsp.normalize((body * env + click) * 0.95, 0.95)

    def snare(self, length: int) -> np.ndarray:
        t = np.arange(length) / self.SAMPLE_RATE
        tone = np.sin(2 * np.pi * 180 * t) * dsp.exp_decay(length, rate=22)
        noise = dsp.bandpass(dsp.noise(length), 800, 9000) * dsp.exp_decay(length, rate=14)
        return dsp.normalize(tone * 0.35 + noise * 0.75, 0.9)

    def clap(self, length: int) -> np.ndarray:
        out = np.zeros(length, dtype=np.float32)
        for delay_ms in (0, 12, 22, 35):
            off = int(self.SAMPLE_RATE * delay_ms / 1000)
            burst_len = min(length - off, int(self.SAMPLE_RATE * 0.04))
            if burst_len <= 0:
                continue
            burst = dsp.bandpass(dsp.noise(burst_len), 1000, 7000) * dsp.exp_decay(burst_len, rate=45)
            end = off + burst_len
            out[off:end] += burst
        tail = dsp.bandpass(dsp.noise(length), 700, 6000) * dsp.exp_decay(length, rate=16) * 0.5
        out += tail
        return dsp.normalize(out, 0.85)

    def hat(self, length: int, open_: bool = False) -> np.ndarray:
        rate = 10 if open_ else 60
        n = dsp.highpass(dsp.noise(length), 7500, order=2)
        return dsp.normalize(n * dsp.exp_decay(length, rate=rate), 0.6)

    def ride(self, length: int) -> np.ndarray:
        n = dsp.highpass(dsp.noise(length), 5000, order=2)
        return dsp.normalize(n * dsp.exp_decay(length, rate=3), 0.5)

    def cowbell(self, length: int) -> np.ndarray:
        t = np.arange(length) / self.SAMPLE_RATE
        tone = dsp.square(800, t) * 0.5 + dsp.square(540, t) * 0.5
        env = dsp.exp_decay(length, rate=25)
        return dsp.normalize(dsp.saturate(tone * env, 1.5), 0.7)

    def vinyl_noise(self, length: int) -> np.ndarray:
        n = dsp.noise(length)
        n = dsp.bandpass(n, 2000, 9000)
        crackle_mask = (dsp.noise(length) > 2.6).astype(np.float32)
        return (n * 0.15 + crackle_mask * 0.4).astype(np.float32)

    # ------------------------------------------------------
    # hi-hat patterns
    # ------------------------------------------------------

    def hat_pattern(self, steps_per_beat: int, beats: int, energy: float, density: float) -> list[tuple[int, bool]]:
        """Generic 16th-note style (trap etc.)."""
        total_steps = steps_per_beat * beats
        hits: list[tuple[int, bool]] = []
        step = 0
        stride = max(1, round(2 / max(density, 0.1)))
        while step < total_steps:
            bar_pos = step % (steps_per_beat * 4)
            in_fill_zone = (step // (steps_per_beat * 4)) % 4 == 3 and bar_pos >= steps_per_beat * 3
            if in_fill_zone and energy > 0.4 and density > 0.4:
                hits.append((step, False))
                step += 1
            else:
                hits.append((step, bar_pos % (steps_per_beat // 2 or 1) == 0))
                step += stride
        return hits

    def offbeat_hat_pattern(self, steps_per_beat: int, beats: int) -> list[tuple[int, bool]]:
        """
        Classic tech-house / house offbeat closed hats:
        hits on the "and" of every beat (0.5, 1.5, 2.5, 3.5).
        Occasional open hat on the last offbeat of every 4th bar.
        """
        hits: list[tuple[int, bool]] = []
        total_steps = steps_per_beat * beats
        # 8th-note offbeats → step = 2 when steps_per_beat=4
        for step in range(2, total_steps, 2):
            bar = step // (steps_per_beat * 4)
            pos_in_bar = step % (steps_per_beat * 4)
            is_open = (bar % 4 == 3) and (pos_in_bar >= steps_per_beat * 3)
            hits.append((step, is_open))
        return hits

    # ------------------------------------------------------

    def execute(self, project):
        producer = project.get("producer_brain", {})
        samples = project.get("samples", {})

        bpm = producer.get("bpm", project.get("bpm", 140))
        bars = producer.get("bars", 64)
        energy = float(producer.get("energy", 0.7)) if isinstance(producer, dict) else 0.7
        genre = str(project.get("genre", "dark trap")).lower()
        pattern = GENRE_PATTERNS.get(genre, DEFAULT_PATTERN)

        beats = bars * 4
        beat_samples = int(60 / bpm * self.SAMPLE_RATE)
        step_samples = beat_samples // 4  # 16th note
        swing_offset = int(step_samples * pattern.get("swing", 0.0))
        total = beat_samples * beats

        drums = np.zeros(total, dtype=np.float32)

        kick = self.kick(int(self.SAMPLE_RATE * 0.35))
        snare = self.snare(int(self.SAMPLE_RATE * 0.20))
        clap = self.clap(int(self.SAMPLE_RATE * 0.16))
        hat_closed = self.hat(int(self.SAMPLE_RATE * 0.045))
        hat_open = self.hat(int(self.SAMPLE_RATE * 0.16), open_=True)
        ride = self.ride(int(self.SAMPLE_RATE * 0.5))
        cowbell = self.cowbell(int(self.SAMPLE_RATE * 0.12)) if pattern.get("cowbell") else None

        def place(sample: np.ndarray, pos: int, gain: float = 1.0) -> None:
            pos = max(0, pos)
            end = min(total, pos + len(sample))
            if end <= pos:
                return
            drums[pos:end] += sample[: end - pos] * gain

        def swing_for(offset_in_bar: float) -> int:
            is_offbeat = abs((offset_in_bar * 4) % 2) >= 1
            return swing_offset if is_offbeat else 0

        n_bars = beats // 4
        for bar in range(n_bars):
            bar_pos = bar * beat_samples * 4

            if pattern.get("four_on_floor"):
                for b in range(4):
                    place(kick, bar_pos + b * beat_samples, 1.0)
            else:
                for offset in pattern["kick"]:
                    pos = bar_pos + int(offset * beat_samples) + swing_for(offset)
                    place(kick, pos, 0.95 if offset == int(offset) else 0.75)

            for offset in pattern.get("snare", []):
                place(snare, bar_pos + int(offset * beat_samples))

            for offset in pattern.get("clap", []):
                place(clap, bar_pos + int(offset * beat_samples), 0.80)

            if cowbell is not None and bar % 2 == 1:
                place(cowbell, bar_pos + int(2.5 * beat_samples), 0.55)

            # light ride accent every 4th bar (house + trap)
            if bar % 4 == 3 and not pattern.get("four_on_floor"):
                place(ride, bar_pos + beat_samples * 3, 0.35)

        # hats
        if pattern.get("offbeat_hat"):
            # tech-house / house signature: clean offbeat closed hats
            for step, is_open in self.offbeat_hat_pattern(4, beats):
                pos = step * step_samples
                if pos >= total:
                    continue
                place(hat_open if is_open else hat_closed, pos, 0.50 if is_open else 0.42)
        else:
            for step, is_open in self.hat_pattern(4, beats, energy, pattern.get("hat_density", 1.0)):
                pos = step * step_samples
                if pos >= total:
                    continue
                place(hat_open if is_open else hat_closed, pos, 0.55 if is_open else 0.45)

        if genre == "lo-fi":
            drums += self.vinyl_noise(total) * 0.55

        drums *= pattern.get("gain", 1.0)
        drums = dsp.soft_clip(drums, 0.85)

        project["drums_audio"] = drums
        project["drum_info"] = {
            "kick_sample": samples.get("kick"),
            "snare_sample": samples.get("snare"),
            "hat_sample": samples.get("hat"),
            "bars": bars,
            "bpm": bpm,
            "genre_pattern": genre if genre in GENRE_PATTERNS else "default",
            "four_on_floor": bool(pattern.get("four_on_floor")),
            "synthesis": "dsp-v3",
        }

        info(
            f"DRUM ENGINE -> {bars} bars @ {bpm} BPM | "
            f"pattern={genre} | 4otf={bool(pattern.get('four_on_floor'))}"
        )
        return project


drum_engine = DrumEngine()
registry.register("drum_engine", drum_engine)