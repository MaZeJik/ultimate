from core.registry import registry
from core.logger import info


class ArrangementEngine:

    def execute(self, project):

        producer = project.get("producer_brain", {})
        plan = project.get("composition_plan", {})

        sections = producer.get("sections")

        if not sections:
            sections = plan.get("sections", [])

        if not sections:
            info("ARRANGEMENT -> no sections found")
            return project

        arrangement = []

        for index, section in enumerate(sections):

            energy = float(section.get("energy", 0.70))
            bars = int(section.get("bars", 8))
            name = section.get("section", section.get("name", f"section_{index}"))

            if energy < 0.30:

                layers = [
                    "atmosphere",
                    "fx",
                ]

            elif energy < 0.55:

                layers = [
                    "bass",
                    "piano",
                    "atmosphere",
                ]

            elif energy < 0.80:

                layers = [
                    "drums",
                    "bass",
                    "melody",
                    "piano",
                    "counter",
                    "fx",
                ]

            else:

                layers = [
                    "drums",
                    "bass",
                    "synth",
                    "melody",
                    "counter",
                    "piano",
                    "fx",
                    "atmosphere",
                ]

            arrangement.append({

                "index": index,
                "name": name,
                "bars": bars,
                "energy": energy,
                "layers": layers,

            })

        project["arrangement"] = arrangement

        info(f"ARRANGEMENT READY -> {len(arrangement)} sections")

        return project


arrangement_engine = ArrangementEngine()

registry.register(
    "arrangement_engine",
    arrangement_engine,
)