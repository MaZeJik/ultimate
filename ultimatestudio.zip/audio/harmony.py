from core.registry import registry


class HarmonyEngine:

    def execute(self, project):

        brain = project.get("music_brain", {})

        chords = brain.get("chords", ["Am", "F", "G", "Em"])

        # structure-aware harmony
        structured = {
            "intro": chords[:2],
            "drop": chords,
            "outro": chords[::-1]
        }

        project["harmony"] = structured

        return project


harmony_engine = HarmonyEngine()
registry.register("harmony_engine", harmony_engine)