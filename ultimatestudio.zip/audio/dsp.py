"""
UltimateStudio
audio/dsp.py

Shared DSP building blocks used by every instrument engine. The
original engines each hand-rolled a bare oscillator + `np.exp` decay
and called it done -- no filtering, no proper envelopes, no space
(reverb/delay), no unison/detune, no saturation. This module is the
toolkit that makes a real production chain possible without needing
sample libraries: filters, ADSR, supersaw/unison oscillators,
algorithmic reverb, delay, chorus, and soft saturation.
"""

from __future__ import annotations

import numpy as np
from scipy.signal import butter, lfilter

SAMPLE_RATE = 44100

# ==========================================================
# OSCILLATORS
# ==========================================================


def sine(freq: np.ndarray | float, t: np.ndarray) -> np.ndarray:
    return np.sin(2 * np.pi * freq * t)


def saw(freq: np.ndarray | float, t: np.ndarray) -> np.ndarray:
    phase = (freq * t) % 1.0
    return 2.0 * phase - 1.0


def square(freq: np.ndarray | float, t: np.ndarray, pulse_width: float = 0.5) -> np.ndarray:
    phase = (freq * t) % 1.0
    return np.where(phase < pulse_width, 1.0, -1.0)


def triangle(freq: np.ndarray | float, t: np.ndarray) -> np.ndarray:
    phase = (freq * t) % 1.0
    return 2.0 * np.abs(2.0 * phase - 1.0) - 1.0


def unison_saw(freq: float, t: np.ndarray, voices: int = 7, detune_cents: float = 18.0, spread: float = 0.9) -> np.ndarray:
    """
    A "supersaw": several detuned saw oscillators summed together,
    panned/weighted so the outer voices sit slightly quieter than the
    center -- the classic thick EDM/trap lead & pad sound. Returns a
    mono signal (apply stereo width downstream if needed).
    """
    if voices <= 1:
        return saw(freq, t)

    out = np.zeros_like(t)
    center = (voices - 1) / 2
    for i in range(voices):
        offset = (i - center) / max(center, 1)  # -1..1
        cents = offset * detune_cents
        detuned_freq = freq * (2 ** (cents / 1200))
        weight = 1.0 - abs(offset) * (1.0 - spread)
        out += saw(detuned_freq, t) * weight
    return out / np.sqrt(voices)


def noise(length: int, seed: int | None = None) -> np.ndarray:
    rng = np.random.default_rng(seed)
    return rng.standard_normal(length).astype(np.float32)


# ==========================================================
# ENVELOPES
# ==========================================================


def adsr(
    length: int,
    attack: float = 0.01,
    decay: float = 0.1,
    sustain: float = 0.7,
    release: float = 0.2,
    sample_rate: int = SAMPLE_RATE,
) -> np.ndarray:
    """A proper ADSR envelope in seconds, time-stretched to fit `length` samples."""
    a = max(1, int(attack * sample_rate))
    d = max(1, int(decay * sample_rate))
    r = max(1, int(release * sample_rate))
    s = max(0, length - a - d - r)

    env = np.concatenate(
        [
            np.linspace(0, 1, a, endpoint=False),
            np.linspace(1, sustain, d, endpoint=False),
            np.full(s, sustain),
            np.linspace(sustain, 0, r),
        ]
    )

    if len(env) < length:
        env = np.pad(env, (0, length - len(env)))
    return env[:length].astype(np.float32)


def exp_decay(length: int, rate: float = 20.0, sample_rate: int = SAMPLE_RATE) -> np.ndarray:
    t = np.arange(length) / sample_rate
    return np.exp(-t * rate).astype(np.float32)


# ==========================================================
# FILTERS
# ==========================================================


def lowpass(signal: np.ndarray, cutoff_hz: float, sample_rate: int = SAMPLE_RATE, order: int = 4) -> np.ndarray:
    nyq = sample_rate / 2
    cutoff = np.clip(cutoff_hz / nyq, 1e-4, 0.999)
    b, a = butter(order, cutoff, btype="low")
    return lfilter(b, a, signal).astype(np.float32)


def highpass(signal: np.ndarray, cutoff_hz: float, sample_rate: int = SAMPLE_RATE, order: int = 2) -> np.ndarray:
    nyq = sample_rate / 2
    cutoff = np.clip(cutoff_hz / nyq, 1e-4, 0.999)
    b, a = butter(order, cutoff, btype="high")
    return lfilter(b, a, signal).astype(np.float32)


def bandpass(signal: np.ndarray, low_hz: float, high_hz: float, sample_rate: int = SAMPLE_RATE, order: int = 2) -> np.ndarray:
    nyq = sample_rate / 2
    low = np.clip(low_hz / nyq, 1e-4, 0.999)
    high = np.clip(high_hz / nyq, low + 1e-4, 0.9999)
    b, a = butter(order, [low, high], btype="band")
    return lfilter(b, a, signal).astype(np.float32)


def swept_lowpass(signal: np.ndarray, start_hz: float, end_hz: float, sample_rate: int = SAMPLE_RATE) -> np.ndarray:
    """
    A cheap filter-envelope effect: crossfades between a bright and a
    dark low-passed copy of the signal over its length, approximating
    a swept cutoff without a per-sample time-varying filter.
    """
    bright = lowpass(signal, max(start_hz, end_hz), sample_rate)
    dark = lowpass(signal, min(start_hz, end_hz), sample_rate)
    n = len(signal)
    ramp = np.linspace(0, 1, n) if end_hz < start_hz else np.linspace(1, 0, n)
    return (bright * (1 - ramp) + dark * ramp).astype(np.float32)


# ==========================================================
# DYNAMICS / TONE
# ==========================================================


def saturate(signal: np.ndarray, drive: float = 2.0) -> np.ndarray:
    return np.tanh(signal * drive)


def soft_clip(signal: np.ndarray, threshold: float = 0.8) -> np.ndarray:
    out = signal.copy()
    mask = np.abs(out) > threshold
    out[mask] = np.sign(out[mask]) * (threshold + (1 - threshold) * np.tanh((np.abs(out[mask]) - threshold) * 4))
    return out


def normalize(signal: np.ndarray, peak: float = 0.95) -> np.ndarray:
    m = np.max(np.abs(signal))
    if m <= 0:
        return signal
    return signal * (peak / m)


# ==========================================================
# SPACE: REVERB / DELAY / CHORUS
# ==========================================================


def _comb_filter(signal: np.ndarray, delay_samples: int, feedback: float) -> np.ndarray:
    """
    y[n] = x[n] + feedback * y[n - delay_samples]

    Only couples samples exactly `delay_samples` apart, so this
    reshapes the signal into `delay_samples` independent interleaved
    phase-streams (each just a plain order-1 IIR recursion) and runs
    them all at once with a single 2D lfilter call -- O(n) instead of
    the O(n * delay_samples) you get from handing lfilter a dense
    order-`delay_samples` polynomial directly.
    """
    d = max(1, delay_samples)
    n = len(signal)

    pad = (-n) % d
    padded = np.pad(signal, (0, pad)).astype(np.float32)
    phases = padded.reshape(-1, d).T  # shape (d, n_per_phase)

    filtered = lfilter([1.0], [1.0, -feedback], phases, axis=1)

    return filtered.T.reshape(-1)[:n].astype(np.float32)


def reverb(signal: np.ndarray, mix: float = 0.25, size: float = 0.6, sample_rate: int = SAMPLE_RATE) -> np.ndarray:
    """
    A lightweight Schroeder-style reverb: a handful of parallel comb
    filters at prime-ish delay times, summed, then softened. This is
    not a convolution reverb, but it's a real, coded algorithmic
    reverb rather than "no space at all" (which is what every engine
    had before).
    """
    if mix <= 0:
        return signal

    base_delays_ms = [29.7, 37.1, 41.3, 43.7]
    fb = 0.55 + size * 0.35

    wet = np.zeros(len(signal), dtype=np.float32)
    for ms in base_delays_ms:
        d = max(1, int(sample_rate * ms / 1000))
        wet += _comb_filter(signal, d, fb)

    wet = wet / len(base_delays_ms)
    wet = lowpass(wet, 6000, sample_rate, order=2)
    return ((1 - mix) * signal + mix * wet).astype(np.float32)


def delay(signal: np.ndarray, time_sec: float, feedback: float = 0.35, mix: float = 0.25, sample_rate: int = SAMPLE_RATE) -> np.ndarray:
    if mix <= 0:
        return signal

    d = max(1, int(time_sec * sample_rate))
    wet = _comb_filter(signal, d, feedback)
    return ((1 - mix) * signal + mix * wet).astype(np.float32)


def chorus(signal: np.ndarray, rate_hz: float = 0.6, depth_ms: float = 4.0, mix: float = 0.35, sample_rate: int = SAMPLE_RATE) -> np.ndarray:
    """Detuned/modulated doubling for width and movement."""
    n = len(signal)
    t = np.arange(n) / sample_rate
    depth_samples = depth_ms / 1000 * sample_rate
    mod = (np.sin(2 * np.pi * rate_hz * t) * 0.5 + 0.5) * depth_samples
    base_idx = np.arange(n)
    src_idx = np.clip(base_idx - mod, 0, n - 1)
    idx_floor = src_idx.astype(int)
    idx_ceil = np.clip(idx_floor + 1, 0, n - 1)
    frac = src_idx - idx_floor
    wet = signal[idx_floor] * (1 - frac) + signal[idx_ceil] * frac
    return ((1 - mix) * signal + mix * wet).astype(np.float32)


# ==========================================================
# STEREO
# ==========================================================


def widen(mono: np.ndarray, amount: float = 0.3, sample_rate: int = SAMPLE_RATE) -> np.ndarray:
    """Cheap stereo widening via a short Haas-effect delay on one side."""
    delay_samples = max(1, int(0.012 * sample_rate * amount))
    right = np.pad(mono, (delay_samples, 0))[: len(mono)]
    return np.stack([mono, right]).astype(np.float32)
