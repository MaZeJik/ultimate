"""
UltimateStudio
audio/groove_engine.py

Tiny humanization of timing + velocity.

House / Tech House stays very tight (machine feel).
Trap / drill get more micro-timing movement.
"""

from __future__ import annotations

import random

from core.logger import info
from core.registry import registry


HOUSE_GENRES = {
    "tech house", "deep house", "melodic house", "progressive house",
    "afro house", "festival house", "dark techno", "techno", "minimal",
}


class GrooveEngine:

    NAME = "Groove Engine"

    def groove_amount(self, genre: str) -> float:
        genre = (genre or "").lower()

        if genre in HOUSE_GENRES or "house" in genre:
            return 0.004          # extremely tight
        if "techno" in genre:
            return 0.006
        if "trap" in genre:
            return 0.018
        if "drill" in genre:
            return 0.022
        if "lo-fi" in genre:
            return 0.020
        return 0.012

    def groove(self, notes, amount: float):
        if not notes:
            return notes

        output = []
        for note in notes:
            n = dict(note)
            step = float(n.get("step", 0))
            shift = random.uniform(-amount, amount)
            n["step"] = max(0.0, step + shift)

            vel = n.get("velocity", 90)
            # house: almost no velocity jitter; trap: a bit more
            jitter = 1 if amount < 0.008 else 3
            vel += random.randint(-jitter, jitter)
            n["velocity"] = max(45, min(127, vel))
            output.append(n)
        return output

    def execute(self, project):
        genre = project.get("genre", "dark trap")
        amount = self.groove_amount(genre)

        targets = [
            "melody",
            "counter_melody",
            "bass_notes",
            "piano_notes",
        ]

        processed = 0
        for target in targets:
            notes = project.get(target)
            if notes is None:
                continue
            project[target] = self.groove(notes, amount)
            processed += 1

        project["groove"] = {
            "amount": amount,
            "processed_tracks": processed,
        }

        info(f"GROOVE -> {processed} tracks | amount={amount:.4f} | genre={genre}")
        return project


groove_engine = GrooveEngine()
registry.register("groove_engine", groove_engine)