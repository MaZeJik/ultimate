"""
UltimateStudio
audio/synth.py

Arp / stab synth layer.

Trap / bright styles: supersaw arp.
House / Tech House: short filtered stabs (less busy, more groove space).
"""

from __future__ import annotations

import numpy as np

from audio import dsp, theory
from core.logger import info
from core.registry import registry


HOUSE_GENRES = {
    "tech house", "deep house", "melodic house", "progressive house",
    "afro house", "festival house", "dark techno", "techno", "minimal",
}


class SynthEngine:
    SAMPLE_RATE = dsp.SAMPLE_RATE

    def supersaw(self, freq: float, length: int) -> np.ndarray:
        t = np.arange(length) / self.SAMPLE_RATE
        wave = dsp.unison_saw(freq, t, voices=7, detune_cents=14.0, spread=0.85)
        env = dsp.adsr(
            length, attack=0.008, decay=0.16, sustain=0.55, release=0.20,
            sample_rate=self.SAMPLE_RATE,
        )
        wave = wave * env
        wave = dsp.swept_lowpass(wave, start_hz=6000, end_hz=2200, sample_rate=self.SAMPLE_RATE)
        wave = dsp.chorus(wave, rate_hz=0.5, depth_ms=3.5, mix=0.3, sample_rate=self.SAMPLE_RATE)
        return wave.astype(np.float32)

    def house_stab(self, freq: float, length: int) -> np.ndarray:
        """Short, filtered, mono-ish stab — classic tech-house seasoning."""
        t = np.arange(length) / self.SAMPLE_RATE
        # fewer voices, less detune = tighter club stab
        wave = dsp.unison_saw(freq, t, voices=3, detune_cents=6.0, spread=0.4)
        env = dsp.adsr(
            length, attack=0.003, decay=0.08, sustain=0.15, release=0.10,
            sample_rate=self.SAMPLE_RATE,
        )
        wave = wave * env
        wave = dsp.swept_lowpass(wave, start_hz=3200, end_hz=900, sample_rate=self.SAMPLE_RATE)
        return wave.astype(np.float32)

    def execute(self, project):
        producer = project.get("producer_brain", {})
        samples = project.get("samples", {})
        genre = str(project.get("genre", "")).lower()
        is_house = genre in HOUSE_GENRES or "house" in genre or "techno" in genre

        bpm = producer.get("bpm", project.get("bpm", 124 if is_house else 140))
        bars = producer.get("bars", 64)

        beat = int(60 / bpm * self.SAMPLE_RATE)
        total = beat * bars * 4
        audio = np.zeros(total, dtype=np.float32)

        scale = theory.scale_for(project.get("scale", "minor"))
        root = theory.root_midi(project, octave=5)

        if is_house:
            # sparse stab pattern (mostly rests + a few hits)
            arp = [0, -1, -1, 5, -1, -1, 3, -1]   # -1 = rest
            steps = 8
            step_len = beat // 2
            gain = 0.12
            synth_fn = self.house_stab
            label = "house_stab"
        else:
            arp = [0, 3, 5, 7, 5, 3, 8, 7]
            steps = 8
            step_len = beat // 2
            gain = 0.16
            synth_fn = self.supersaw
            label = "supersaw"

        notes = []
        for bar in range(bars):
            for step in range(steps):
                deg = arp[step % len(arp)]
                if deg < 0:
                    continue
                degree = deg % len(scale)
                midi = root + scale[degree]
                freq = theory.note_freq(midi)

                wave = synth_fn(freq, step_len)
                wave *= gain

                pos = bar * beat * 4 + step * step_len
                end = min(total, pos + step_len)
                if pos >= total:
                    continue
                audio[pos:end] += wave[: end - pos]
                notes.append(midi)

        audio = dsp.soft_clip(audio, 0.88 if is_house else 0.9)

        project["synth_audio"] = audio
        project["synth_info"] = {
            "sample": samples.get("synth"),
            "notes": len(notes),
            "bars": bars,
            "bpm": bpm,
            "synthesis": label,
        }

        info(f"SYNTH -> {len(notes)} notes ({label})")
        return project


synth_engine = SynthEngine()
registry.register("synth_engine", synth_engine)