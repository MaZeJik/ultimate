"""
UltimateStudio
audio/theory.py

Small shared music-theory helpers.

Before this, `composer.py` picked a real key (e.g. "F#") and wrote it
to `project["key"]`, but `melody.py` used a hardcoded `root = 57`
(A3) and `bass.py` used a hardcoded `root = 43.65` (F1) -- neither
one ever read `project["key"]`. Whatever key the composer picked was
purely decorative; every track was generated in the same fixed
pitch regardless. This module is the one place that turns a key name
into a MIDI root, so every engine can actually follow the song's key.
"""

from __future__ import annotations

NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

MINOR_SCALE = [0, 2, 3, 5, 7, 8, 10]
MAJOR_SCALE = [0, 2, 4, 5, 7, 9, 11]


def key_to_pitch_class(key: str) -> int:
    key = (key or "C").strip().upper().replace("♯", "#").replace("♭", "b")
    if key in NOTE_NAMES:
        return NOTE_NAMES.index(key)
    # accept flats too (Db -> C#, etc.)
    flats = {"DB": 1, "EB": 3, "GB": 6, "AB": 8, "BB": 10}
    return flats.get(key, 0)


def scale_for(scale_name: str) -> list[int]:
    return MAJOR_SCALE if str(scale_name).lower() == "major" else MINOR_SCALE


def root_midi(project, octave: int = 2) -> int:
    """
    The song's root note as a MIDI number in the given octave (2 = a
    low/bass-friendly octave, 3-4 = melody-friendly).
    """
    pitch_class = key_to_pitch_class(project.get("key", "C"))
    return 12 * (octave + 1) + pitch_class


def note_freq(midi: float) -> float:
    return 440.0 * (2 ** ((midi - 69) / 12))


def degree_freq(project, degree_index: int, octave: int = 3) -> float:
    """Frequency of the `degree_index`-th scale degree of the song's key/scale."""
    scale = scale_for(project.get("scale", "minor"))
    root = root_midi(project, octave)
    octave_shift, degree = divmod(degree_index, len(scale))
    midi = root + scale[degree] + 12 * octave_shift
    return note_freq(midi)
