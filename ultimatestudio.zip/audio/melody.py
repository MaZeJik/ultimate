"""
UltimateStudio
audio/melody.py

Lead melody.

Trap: denser 8th-note pluck hooks.
House / Tech House: sparse stabs & short motifs (club tracks leave
space for the groove — melody is seasoning, not the main course).
"""

from __future__ import annotations

import random

import numpy as np

from audio import dsp, theory
from core.logger import info
from core.registry import registry


HOUSE_GENRES = {
    "tech house", "deep house", "melodic house", "progressive house",
    "afro house", "festival house", "dark techno", "techno", "minimal",
}


class MelodyEngine:
    SAMPLE_RATE = dsp.SAMPLE_RATE

    def pluck(self, freq: float, n: int, house: bool = False) -> np.ndarray:
        t = np.arange(n) / self.SAMPLE_RATE
        vibrato = 1.0 + (0.002 if house else 0.004) * np.sin(2 * np.pi * 5.5 * t)
        fundamental = np.sin(2 * np.pi * freq * vibrato * t)
        shimmer = (0.12 if house else 0.22) * np.sin(2 * np.pi * freq * 2.01 * t) * np.exp(-t * 9)
        wave = fundamental * 0.8 + shimmer

        if house:
            # shorter, tighter stab
            env = dsp.adsr(
                n, attack=0.004, decay=0.10, sustain=0.20, release=0.12,
                sample_rate=self.SAMPLE_RATE,
            )
        else:
            env = dsp.adsr(
                n, attack=0.006, decay=0.18, sustain=0.35, release=0.22,
                sample_rate=self.SAMPLE_RATE,
            )
        return (wave * env).astype(np.float32)

    def execute(self, project):
        producer = project.get("producer_brain", {})
        genre = str(project.get("genre", "")).lower()
        is_house = genre in HOUSE_GENRES or "house" in genre or "techno" in genre

        bpm = producer.get("bpm", project.get("bpm", 124 if is_house else 140))
        bars = producer.get("bars", 64)

        beat = int(60 / bpm * self.SAMPLE_RATE)
        total = beat * bars * 4
        melody = np.zeros(total, dtype=np.float32)

        if is_house:
            # sparse club motifs (degrees in scale)
            motif_options = {
                "stab_root": [0, 0, 0, 0, 5, 0, 0, 0],
                "call_sparse": [0, 0, 3, 0, 0, 5, 0, 0],
                "two_note": [0, 0, 5, 5, 0, 0, 3, 0],
                "minimal_hook": [0, 3, 0, 0, 5, 0, 3, 0],
                "offbeat_stab": [0, 0, 0, 5, 0, 0, 0, 3],
            }
            note_gain = 0.22
            steps_per_bar = 4          # quarter notes, not 8ths
            mutate_rate = 0.20
        else:
            motif_options = {
                "rising_return": [0, 2, 3, 2, 5, 3, 2, 0],
                "arpeggio_climb": [0, 2, 4, 7, 4, 2, 0, 2],
                "call_response": [0, 3, 0, 5, 3, 5, 7, 5],
                "descending_hook": [7, 5, 3, 2, 0, 2, 3, 0],
                "syncopated_leap": [0, 5, 3, 7, 5, 2, 0, 3],
                "stepwise_wave": [0, 1, 2, 3, 2, 1, 0, 2],
            }
            note_gain = 0.30
            steps_per_bar = 8
            mutate_rate = 0.40

        try:
            from core.variation_tracker import variation_tracker
            motif_name = variation_tracker.choose("melody:motif", list(motif_options.keys()))
        except ImportError:
            motif_name = random.choice(list(motif_options.keys()))

        motif = motif_options[motif_name]
        scale = theory.scale_for(project.get("scale", "minor"))
        root = theory.root_midi(project, octave=4 if not is_house else 5)

        notes = []
        step_len = beat if is_house else (beat // 2)

        for bar in range(bars):
            current = motif.copy()
            if random.random() < mutate_rate:
                i = random.randrange(len(current))
                current[i] = random.randrange(len(scale))

            for step in range(steps_per_bar):
                degree_idx = current[step % len(current)] % len(scale)
                # house: skip many steps for space
                if is_house and current[step % len(current)] == 0 and step % 2 == 1 and random.random() < 0.55:
                    continue

                midi = root + scale[degree_idx]
                freq = theory.note_freq(midi)
                wave = self.pluck(freq, step_len, house=is_house)
                wave *= note_gain

                pos = bar * beat * 4 + step * step_len
                end = min(total, pos + step_len)
                if pos >= total:
                    continue
                melody[pos:end] += wave[: end - pos]
                notes.append({"bar": bar, "midi": midi, "freq": round(freq, 2)})

        melody = dsp.soft_clip(melody, 0.88 if is_house else 0.9)

        project["melody_audio"] = melody
        project["melody_notes"] = notes
        info(
            f"MELODY -> {len(notes)} notes | {genre or '?'} | "
            f"{'sparse house' if is_house else 'dense trap'} | "
            f"{project.get('key', '?')} {project.get('scale', '?')}"
        )
        return project


melody_engine = MelodyEngine()
registry.register("melody_engine", melody_engine)