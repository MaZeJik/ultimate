"""
UltimateStudio
audio/atmosphere_engine.py

Background atmosphere/pad texture: filtered noise "air" plus a slow
sub-bass drone in the song's key for cinematic depth. The original
lowpass here was a pure-Python per-sample `for` loop over the entire
track (the same kind of performance bug fixed in MasterEngine's
highpass) -- now a vectorized Butterworth lowpass via audio.dsp.
"""

from __future__ import annotations

import numpy as np

from audio import dsp, theory
from core.logger import info
from core.registry import registry


class AtmosphereEngine:
    SAMPLE_RATE = dsp.SAMPLE_RATE

    def execute(self, project):
        producer = project.get("producer_brain", {})
        samples = project.get("samples", {})

        bpm = producer.get("bpm", project.get("bpm", 140))
        bars = producer.get("bars", 64)

        beat = int(60 / bpm * self.SAMPLE_RATE)
        total = beat * bars * 4

        # filtered "air" noise bed
        air = dsp.noise(total)
        air = dsp.lowpass(air, cutoff_hz=900, order=2)

        fade = min(int(self.SAMPLE_RATE * 2), total // 4)
        env = np.ones(total, dtype=np.float32)
        if fade > 1:
            env[:fade] = np.linspace(0, 1, fade)
            env[-fade:] = np.linspace(1, 0, fade)
        air = air * env * 0.035

        # slow sub-bass drone in the song's key, for cinematic low-end weight
        t = np.arange(total) / self.SAMPLE_RATE
        drone_freq = theory.note_freq(theory.root_midi(project, octave=0))
        drone = np.sin(2 * np.pi * drone_freq * t)
        drone *= 1.0 + 0.15 * np.sin(2 * np.pi * 0.08 * t)  # slow swell
        drone *= env * 0.05

        atmosphere = (air + drone).astype(np.float32)

        project["atmosphere_audio"] = atmosphere
        project["atmosphere_info"] = {
            "sample": samples.get("atmosphere"),
            "bars": bars,
            "bpm": bpm,
            "drone_key": project.get("key"),
        }

        info(f"ATMOSPHERE -> {bars} bars (noise bed + key drone)")

        return project


atmosphere_engine = AtmosphereEngine()

registry.register("atmosphere_engine", atmosphere_engine)
