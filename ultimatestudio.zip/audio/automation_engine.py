from core.registry import registry
from core.logger import info


class AutomationEngine:

    def execute(self, project):

        arrangement = project.get("arrangement", [])

        if not arrangement:

            info("AUTOMATION -> no arrangement")

            project["automation"] = []

            return project

        automation = []

        for section in arrangement:

            energy = float(section.get("energy", 0.5))

            cutoff = 200 + energy * 18000
            reverb = 0.15 + energy * 0.25
            delay = 0.05 + energy * 0.20
            width = 0.80 + energy * 0.40
            sidechain = 0.20 + energy * 0.60

            automation.append({

                "section": section["name"],

                "filter_cutoff": round(cutoff, 1),

                "reverb_send": round(reverb, 3),

                "delay_send": round(delay, 3),

                "stereo_width": round(width, 3),

                "sidechain_amount": round(sidechain, 3),

                "volume": round(0.75 + energy * 0.25, 3)

            })

        project["automation"] = automation

        info(
            f"AUTOMATION READY -> {len(automation)} sections"
        )

        return project


automation_engine = AutomationEngine()

registry.register(
    "automation_engine",
    automation_engine
)