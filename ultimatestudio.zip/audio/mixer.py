"""
UltimateStudio
audio/mixer.py

Sums every instrument bus into the final stereo mix.

Two real gaps fixed here:

  1. Instruments were completely dry (no reverb/delay at all). Melodic
     elements are now sent to a shared reverb bus and a shared delay
     bus, processed once (not per-instrument -- far cheaper), mixed
     back in under the dry signal.

  2. `arrangement_engine` already computes which instruments should be
     present in each section (an empty intro, a full drop, etc.) and
     writes it to `project["arrangement"]` -- but nothing ever *used*
     that data. Every instrument played at full volume for the entire
     track regardless of section, so there was no dynamic song
     structure in the actual audio, only in unused metadata. This now
     builds a per-instrument gain envelope from the arrangement (with
     short crossfades at section boundaries so muting doesn't click)
     and applies it before summing.
"""

from __future__ import annotations

import numpy as np

from audio import dsp
from core.logger import info
from core.registry import registry


class MixerEngine:
    HEADROOM = 0.90
    CROSSFADE_SEC = 0.35

    def normalize(self, audio: np.ndarray) -> np.ndarray:
        peak = np.max(np.abs(audio))
        if peak <= 0:
            return audio
        return audio * (self.HEADROOM / peak)

    def limiter(self, audio: np.ndarray) -> np.ndarray:
        return np.tanh(audio * 1.08)

    def stereo(self, mono: np.ndarray) -> np.ndarray:
        """
        Duplicate a mono signal to stereo.

        The original implementation used `np.roll` to fake a right
        channel, which shifts samples in time and creates comb-filter
        phase artifacts (a hollow, flangey sound) instead of a clean
        stereo image. A true mono-to-stereo duplication (identical
        L/R) is the correct default here -- any intentional widening
        is already applied upstream (see MasterEngine.stereo_width).
        """
        return np.stack([mono, mono])

    def sidechain(self, signal: np.ndarray, trigger: np.ndarray, amount: float) -> np.ndarray:
        env = np.abs(trigger)
        peak = np.max(env)
        if peak > 0:
            env = env / peak
        return signal * (1.0 - env * amount)

    def fetch(self, project, key: str, length: int) -> np.ndarray:
        audio = project.get(key)
        if audio is None:
            return np.zeros(length, dtype=np.float32)
        audio = np.asarray(audio, dtype=np.float32)
        if len(audio) < length:
            out = np.zeros(length, dtype=np.float32)
            out[: len(audio)] = audio
            return out
        return audio[:length]

    # ------------------------------------------------------
    # arrangement-driven per-instrument gain envelopes
    # ------------------------------------------------------

    def build_gain_envelopes(self, project, instruments: list[str], length: int, sample_rate: int = 44100) -> dict[str, np.ndarray]:
        """
        For each instrument name, build a [0..1] gain curve over the
        whole track length: 1.0 where `arrangement_engine` says that
        instrument should be present in the current section, 0.0
        where it shouldn't, with a short linear crossfade at every
        section boundary so instruments fade in/out instead of
        clicking on/off.
        """
        arrangement = project.get("arrangement")
        envelopes = {name: np.ones(length, dtype=np.float32) for name in instruments}

        if not arrangement:
            return envelopes

        bpm = project.get("producer_brain", {}).get("bpm") or project.get("bpm", 140)
        bar_samples = int((60.0 / bpm) * 4 * sample_rate)
        fade = max(1, int(self.CROSSFADE_SEC * sample_rate))

        for name in instruments:
            env = np.zeros(length, dtype=np.float32)
            pos = 0

            for section in arrangement:
                bars = int(section.get("bars", 8))
                section_len = min(bar_samples * bars, max(0, length - pos))
                if section_len <= 0:
                    break

                present = name in section.get("layers", [])
                env[pos : pos + section_len] = 1.0 if present else 0.0
                pos += section_len

            if pos < length:
                # arrangement fell short of the track (rounding) -- hold last state
                env[pos:] = env[pos - 1] if pos > 0 else 1.0

            # smooth the on/off steps into short fades so section
            # changes breathe instead of clicking
            if fade > 1:
                from scipy.ndimage import uniform_filter1d

                env = uniform_filter1d(env, size=fade, mode="nearest")

            envelopes[name] = env

        return envelopes

    def execute(self, project):
        names = [
            "drums_audio",
            "bass_audio",
            "melody_audio",
            "counter_audio",
            "piano_audio",
            "synth_audio",
            "atmosphere_audio",
            "fx_audio",
        ]

        lengths = [len(project[n]) for n in names if project.get(n) is not None]

        if not lengths:
            info("MIXER -> nothing to mix")
            return project

        length = min(lengths)

        instruments = ["drums", "bass", "melody", "counter", "piano", "synth", "atmosphere", "fx"]
        gain = self.build_gain_envelopes(project, instruments, length)

        drums = self.fetch(project, "drums_audio", length) * gain["drums"]
        bass = self.sidechain(self.fetch(project, "bass_audio", length), drums, 0.45) * gain["bass"]
        melody = self.sidechain(self.fetch(project, "melody_audio", length), drums, 0.18) * gain["melody"]
        counter = self.sidechain(self.fetch(project, "counter_audio", length), drums, 0.15) * gain["counter"]
        piano = self.sidechain(self.fetch(project, "piano_audio", length), drums, 0.20) * gain["piano"]
        synth = self.sidechain(self.fetch(project, "synth_audio", length), drums, 0.25) * gain["synth"]
        atmosphere = self.fetch(project, "atmosphere_audio", length) * gain["atmosphere"]
        fx = self.fetch(project, "fx_audio", length) * gain["fx"]

        # --- shared reverb send: melodic/harmonic elements only, one
        # reverb pass on the summed send bus (much cheaper than reverb
        # per instrument, and it glues them into the same "room"). ---
        reverb_send = melody * 0.35 + counter * 0.30 + piano * 0.35 + synth * 0.30
        reverb_wet = dsp.reverb(reverb_send, mix=0.55, size=0.55)

        # --- shared delay send: lead + synth get a rhythmic echo tail ---
        delay_send = melody * 0.30 + synth * 0.25
        beat_sec = 60.0 / project.get("bpm", 140) / 2  # 8th-note delay
        delay_wet = dsp.delay(delay_send, time_sec=beat_sec, feedback=0.32, mix=0.5)

        drum_bus = drums * 1.00
        music_bus = bass * 0.62 + melody * 0.78 + counter * 0.48 + piano * 0.52 + synth * 0.62
        space_bus = reverb_wet * 0.5 + delay_wet * 0.35
        fx_bus = atmosphere * 0.25 + fx * 0.35

        mix = drum_bus + music_bus + space_bus + fx_bus
        mix = self.limiter(mix)
        mix = self.normalize(mix)

        project["final_mix"] = self.stereo(mix)
        project["mix_info"] = {
            "length": length,
            "headroom": self.HEADROOM,
            "channels": 2,
            "sidechain": True,
            "drum_bus": True,
            "music_bus": True,
            "space_bus": True,
            "fx_bus": True,
            "arrangement_gated": bool(project.get("arrangement")),
        }

        info("MIX COMPLETE (with reverb/delay sends + arrangement dynamics)")
        return project


mixer_engine = MixerEngine()

registry.register("mixer_engine", mixer_engine)
