from __future__ import annotations

import random
import numpy as np

from core.registry import registry

SAMPLE_RATE = 44100


class GlideEngine:

    def slide(self, start_freq, end_freq, duration):

        length = int(duration * SAMPLE_RATE)

        t = np.linspace(0, duration, length, endpoint=False)

        freq = np.linspace(start_freq, end_freq, length)

        phase = np.cumsum(freq) / SAMPLE_RATE

        wave = np.sin(2 * np.pi * phase)

        env = np.linspace(1.0, 0.0, length)

        return wave * env

    # --------------------------------------------------------

    def execute(self, project):

        bass = project.get("bass_audio")

        if bass is None:
            return project

        output = bass.copy()

        duration = len(output) / SAMPLE_RATE

        events = max(2, int(duration / 18))

        for _ in range(events):

            pos = random.randint(

                SAMPLE_RATE,

                len(output) - SAMPLE_RATE

            )

            start = random.choice([45, 50, 55, 60])

            end = start * random.choice([1.12, 1.25, 1.50])

            glide = self.slide(

                start,

                end,

                0.18

            )

            end_pos = min(

                pos + len(glide),

                len(output)

            )

            output[pos:end_pos] += glide[:end_pos-pos] * 0.25

        peak = np.max(np.abs(output))

        if peak > 0:
            output /= peak

        project["bass_audio"] = output

        return project


glide_engine = GlideEngine()

registry.register(
    "glide_engine",
    glide_engine
)