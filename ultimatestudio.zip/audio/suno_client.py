"""
UltimateStudio
ai/suno_client.py

Music generation client:
  - kie          -> https://api.kie.ai
  - sunoapi_org  -> https://api.sunoapi.org
  - musicapi     -> https://api.musicapi.ai/api/v1
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import requests

from core.logger import info


class SunoAPIError(Exception):
    pass


@dataclass
class SunoTrack:
    id: str
    title: str
    audio_url: Optional[str]
    stream_url: Optional[str]
    duration: Optional[float]
    status: str


class MusicAPIClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.kie.ai",
        provider: str = "kie",
        timeout: int = 30,
    ):
        if not api_key:
            raise SunoAPIError(
                "No music-generation API key configured. "
                "Set SUNOAPI_KEY in .env (kie.ai or sunoapi.org key)."
            )
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.provider = (provider or "kie").lower()
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            }
        )
        info(f"MUSIC API CLIENT -> provider={self.provider} base={self.base_url}")

    def _request(self, method: str, path: str, **kwargs) -> dict:
        url = f"{self.base_url}{path}"
        try:
            resp = self.session.request(method, url, timeout=self.timeout, **kwargs)
        except requests.RequestException as exc:
            raise SunoAPIError(f"Network error calling {url}: {exc}") from exc

        if resp.status_code == 401:
            raise SunoAPIError("API key rejected (401) -- check SUNOAPI_KEY / provider.")
        if resp.status_code in (402, 403):
            raise SunoAPIError(f"Credits/forbidden ({resp.status_code}): {resp.text[:300]}")
        if resp.status_code == 429:
            raise SunoAPIError("Rate-limited (429) -- back off and retry later.")
        if resp.status_code >= 400 and resp.status_code != 202:
            raise SunoAPIError(f"API error {resp.status_code}: {resp.text[:500]}")

        try:
            return resp.json()
        except ValueError as exc:
            raise SunoAPIError(f"API returned non-JSON: {resp.text[:300]}") from exc

    def _generate_kie(self, description: str, title: str, tags: str, instrumental: bool) -> str:
        body = {
            "prompt": description[:500],
            "customMode": True,
            "instrumental": bool(instrumental),
            "model": "V4_5",
            "title": (title or "Track")[:80],
            "style": (tags or "tech house, underground, electronic")[:200],
        }
        data = self._request("POST", "/api/v1/generate", json=body)
        task_id = None
        if isinstance(data, dict):
            task_id = (data.get("data") or {}).get("taskId") or data.get("taskId")
        if not task_id:
            raise SunoAPIError(f"No taskId in generate response: {data}")
        info(f"MUSIC API -> task created: {task_id}")
        return str(task_id)

    def _poll_kie(self, task_id: str, timeout_sec: int = 300) -> SunoTrack:
        deadline = time.time() + timeout_sec
        while time.time() < deadline:
            data = self._request("GET", f"/api/v1/generate/record-info?taskId={task_id}")
            payload = data.get("data") if isinstance(data, dict) else None
            if not isinstance(payload, dict):
                time.sleep(8)
                continue

            status = str(payload.get("status") or "").upper()
            info(f"MUSIC API -> status={status}")

            if status in ("SUCCESS", "FIRST_SUCCESS"):
                resp = payload.get("response") or {}
                items = resp.get("sunoData") or resp.get("data") or []
                if not items:
                    raise SunoAPIError(f"Success but no audio items: {payload}")
                item = items[0]
                audio_url = (
                    item.get("audioUrl")
                    or item.get("audio_url")
                    or item.get("streamAudioUrl")
                    or item.get("stream_audio_url")
                )
                return SunoTrack(
                    id=str(item.get("id") or task_id),
                    title=str(item.get("title") or "Track"),
                    audio_url=audio_url,
                    stream_url=item.get("streamAudioUrl") or item.get("stream_audio_url"),
                    duration=item.get("duration"),
                    status=status,
                )

            if status in (
                "CREATE_TASK_FAILED",
                "GENERATE_AUDIO_FAILED",
                "SENSITIVE_WORD_ERROR",
                "FAILED",
                "ERROR",
            ):
                raise SunoAPIError(f"Generation failed: {status} | {payload}")

            time.sleep(10)

        raise SunoAPIError(f"Timed out waiting for task {task_id}")

    def _generate_musicapi(self, description: str, title: str, tags: str, instrumental: bool) -> str:
        body = {
            "custom_mode": False,
            "gpt_description_prompt": description,
            "mv": "sonic-v4-5",
            "title": title,
            "tags": tags,
            "make_instrumental": instrumental,
        }
        data = self._request("POST", "/sonic/create", json=body)
        task_id = data.get("data") or data.get("task_id") or data.get("id")
        if not task_id:
            raise SunoAPIError(f"No task id from musicapi: {data}")
        return str(task_id)

    def _poll_musicapi(self, task_id: str, timeout_sec: int = 300) -> SunoTrack:
        deadline = time.time() + timeout_sec
        while time.time() < deadline:
            data = self._request("GET", f"/sonic/task/{task_id}")
            status = str(data.get("status") or data.get("state") or "").lower()
            if status in ("succeeded", "complete", "completed", "success"):
                return SunoTrack(
                    id=str(data.get("id") or task_id),
                    title=str(data.get("title") or "Track"),
                    audio_url=data.get("audio_url") or data.get("audioUrl"),
                    stream_url=data.get("stream_url"),
                    duration=data.get("duration"),
                    status=status,
                )
            if status in ("failed", "error"):
                raise SunoAPIError(f"musicapi failed: {data}")
            time.sleep(10)
        raise SunoAPIError(f"Timed out musicapi task {task_id}")

    def generate_and_wait(
        self,
        description: str,
        title: str = "Track",
        tags: str = "",
        instrumental: bool = True,
        timeout_sec: int = 300,
    ) -> SunoTrack:
        if self.provider in ("kie", "sunoapi_org"):
            task_id = self._generate_kie(description, title, tags, instrumental)
            return self._poll_kie(task_id, timeout_sec=timeout_sec)
        task_id = self._generate_musicapi(description, title, tags, instrumental)
        return self._poll_musicapi(task_id, timeout_sec=timeout_sec)

    def download(self, track: SunoTrack, dest: Path) -> Path:
        if not track.audio_url:
            raise SunoAPIError("Track has no audio_url to download")
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        r = self.session.get(track.audio_url, timeout=120)
        if r.status_code >= 400:
            raise SunoAPIError(f"Download failed {r.status_code}")
        dest.write_bytes(r.content)
        info(f"MUSIC API -> downloaded {dest}")
        return dest