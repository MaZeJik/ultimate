"""
UltimateStudio
audio/swing_engine.py

Applies genre-aware swing to note lists.

Tech House / House family gets almost zero swing (straight 4/4 club feel).
Trap / drill keep their characteristic push.
"""

from __future__ import annotations

import random

from core.logger import info
from core.registry import registry


HOUSE_GENRES = {
    "tech house", "deep house", "melodic house", "progressive house",
    "afro house", "festival house", "dark techno", "techno", "minimal",
}


class SwingEngine:

    NAME = "Swing Engine"

    def amount(self, genre: str) -> float:
        genre = (genre or "").lower()

        if genre in HOUSE_GENRES or "house" in genre:
            return 0.02          # almost straight — classic tech house
        if "techno" in genre:
            return 0.015
        if "trap" in genre:
            return 0.12
        if "drill" in genre:
            return 0.15
        if "boom bap" in genre or "lo-fi" in genre:
            return 0.08
        return 0.08

    def process(self, notes, swing: float):
        if not notes or swing < 0.005:
            return notes

        result = []
        for note in notes:
            n = dict(note)
            step = float(n.get("step", 0))
            whole = int(step)
            frac = step - whole

            if frac >= 0.5:
                frac += swing
            else:
                frac -= swing * 0.20

            frac += random.uniform(-0.008, 0.008)
            frac = max(0.0, min(0.99, frac))
            n["step"] = whole + frac
            result.append(n)
        return result

    def execute(self, project):
        genre = project.get("genre", "dark trap")
        # prefer explicit value from genre_dna / music_brain if present
        dna = project.get("genre_dna", {})
        brain = project.get("music_brain", {})
        swing = dna.get("swing")
        if swing is None:
            swing = brain.get("swing")
        if swing is None:
            swing = self.amount(genre)

        targets = [
            "melody",
            "counter_melody",
            "bass_notes",
            "piano_notes",
        ]

        processed = 0
        for target in targets:
            if target not in project:
                continue
            project[target] = self.process(project[target], float(swing))
            processed += 1

        project["swing"] = {
            "amount": float(swing),
            "processed_tracks": processed,
        }

        info(f"SWING -> {processed} tracks | amount={float(swing):.3f} | genre={genre}")
        return project


swing_engine = SwingEngine()
registry.register("swing_engine", swing_engine)