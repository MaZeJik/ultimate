from core.registry import registry
from core.logger import info


class StructureEngine:

    def execute(self, project):

        plan = project.get("composition_plan", {})

        sections = plan.get("sections", [])

        if not sections:

            info("STRUCTURE -> no composition sections")

            project["structure"] = []

            return project

        structure = []

        start_bar = 0

        for index, section in enumerate(sections):

            bars = int(section.get("bars", 8))

            item = {

                "index": index,

                "name": section.get("name", f"section_{index}"),

                "start_bar": start_bar,

                "end_bar": start_bar + bars - 1,

                "bars": bars,

                "energy": float(section.get("energy", 0.7)),

                "genre": section.get(
                    "genre",
                    project.get("genre", "dark trap")
                ),

                "bpm": section.get(
                    "bpm",
                    project.get("bpm", 140)
                )

            }

            structure.append(item)

            start_bar += bars

        project["structure"] = structure

        info(
            f"STRUCTURE READY -> {len(structure)} sections | {start_bar} bars"
        )

        return project


structure_engine = StructureEngine()

registry.register(
    "structure_engine",
    structure_engine
)