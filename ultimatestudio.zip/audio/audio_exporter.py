"""
UltimateStudio
audio/audio_exporter.py

Writes the mastered mix to a .wav file.

The original project had two duplicate implementations (`exporter.py`
and `audio_exporter.py`) registered under the same registry key; this
is the merged, single version. It now writes into the same
`OUTPUT_AUDIO` directory the rest of the app uses (core.config)
instead of a separate hard-coded "output/audio" folder, and includes
the project id in the filename so two projects with the same title
don't overwrite each other.
"""

from __future__ import annotations

import wave
from pathlib import Path

import numpy as np

from core.config import OUTPUT_AUDIO
from core.logger import info
from core.registry import registry


class AudioExporter:
    SAMPLE_RATE = 44100

    STEM_KEYS = [
        ("drums_audio", "drums"),
        ("bass_audio", "bass"),
        ("melody_audio", "melody"),
        ("counter_audio", "counter_melody"),
        ("piano_audio", "piano"),
        ("synth_audio", "synth"),
        ("atmosphere_audio", "atmosphere"),
        ("fx_audio", "fx"),
    ]

    def write_wave(self, path: Path, audio: np.ndarray) -> None:
        audio = np.asarray(audio, dtype=np.float32)

        if audio.ndim == 1:
            audio = np.stack([audio, audio])

        audio = np.nan_to_num(audio)

        peak = np.max(np.abs(audio))
        if peak > 1.0:
            audio = audio / peak

        pcm = (audio.T * 32767.0).astype(np.int16)

        path.parent.mkdir(parents=True, exist_ok=True)
        with wave.open(str(path), "wb") as wav:
            wav.setnchannels(2)
            wav.setsampwidth(2)
            wav.setframerate(self.SAMPLE_RATE)
            wav.writeframes(pcm.tobytes())

    def export_stems(self, project, base_filename: str) -> list[str]:
        """
        Writes each individual instrument's audio as its own WAV file
        (a "stems" folder next to the final mix), so the project can
        be dragged into FL Studio / Ableton / any DAW for manual
        remixing -- not just the pre-mixed master. Only exports stems
        that actually exist on the project (e.g. skipped if AI music
        mode produced one finished track with no separate layers).
        """
        stems_dir = OUTPUT_AUDIO / "stems" / base_filename
        written = []

        for project_key, stem_name in self.STEM_KEYS:
            audio = project.get(project_key)
            if audio is None:
                continue

            path = stems_dir / f"{stem_name}.wav"
            self.write_wave(path, audio)
            written.append(str(path))

        if written:
            info(f"EXPORT -> {len(written)} stem(s) written to {stems_dir}")

        return written

    def execute(self, project):
        master = project.get("master_audio")

        if master is None:
            info("EXPORT -> master_audio missing")
            return project

        title = project.get("title") or project.get("genre", "ultimate_track")
        safe_title = str(title).replace(" ", "_").replace("/", "_").replace("\\", "_")
        project_id = (project.get("id") or "")[:8]

        filename = f"{safe_title}_{project_id}" if project_id else safe_title
        wav_path = OUTPUT_AUDIO / f"{filename}.wav"

        self.write_wave(wav_path, master)
        exists = wav_path.exists()

        stem_paths = self.export_stems(project, filename)

        project["audio_file"] = str(wav_path)
        project["master_path"] = str(wav_path)
        project["stem_files"] = stem_paths
        project["export_info"] = {
            "format": "wav",
            "sample_rate": self.SAMPLE_RATE,
            "channels": 2,
            "path": str(wav_path),
            "exists": exists,
            "stems": len(stem_paths),
        }

        info(f"EXPORT COMPLETE -> {wav_path}")
        info(f"EXPORT EXISTS -> {exists}")

        return project


audio_exporter = AudioExporter()

registry.register("audio_exporter", audio_exporter)
