from __future__ import annotations

import numpy as np

from core.registry import registry
from core.logger import info


class FXEngine:

    SAMPLE_RATE = 44100

    def riser(self, length):

        t = np.linspace(0, 1, length, False)

        freq = 200 + 1800 * t

        wave = np.sin(2 * np.pi * freq * t)

        return wave * t * 0.35

    def impact(self, length):

        t = np.linspace(0, 1, length, False)

        noise = np.random.randn(length)

        env = np.exp(-t * 8)

        return noise * env * 0.40

    def reverse_fx(self, length):

        t = np.linspace(0, 1, length, False)

        noise = np.random.randn(length)

        env = np.linspace(0, 1, length)

        return noise * env * 0.22

    def downlifter(self, length):

        t = np.linspace(0, 1, length, False)

        freq = 1800 - 1700 * t

        wave = np.sin(2 * np.pi * freq * t)

        env = np.exp(-t * 2)

        return wave * env * 0.28

    def execute(self, project):

        producer = project.get("producer_brain", {})
        samples = project.get("samples", {})
        arrangement = project.get("arrangement", [])

        bpm = producer.get("bpm", 140)
        bars = producer.get("bars", 64)

        beat = int(60 / bpm * self.SAMPLE_RATE)

        total = beat * bars * 4

        audio = np.zeros(total, dtype=np.float32)

        fx_len = beat * 2

        for section in arrangement:

            start = section["section"] * beat * 16

            end = min(total, start + fx_len)

            energy = section.get("energy", 0.5)

            if energy > 0.80:

                fx = self.riser(end - start)

            elif energy > 0.60:

                fx = self.impact(end - start)

            elif energy > 0.35:

                fx = self.reverse_fx(end - start)

            else:

                fx = self.downlifter(end - start)

            audio[start:end] += fx

        project["fx_audio"] = audio

        project["fx_info"] = {

            "sample": samples.get("fx"),

            "impact": samples.get("impact"),

            "riser": samples.get("riser"),

            "bars": bars,

            "bpm": bpm

        }

        info(

            f"FX ENGINE -> {len(arrangement)} transitions"

        )

        return project


fx_engine = FXEngine()

registry.register(

    "fx_engine",

    fx_engine

)