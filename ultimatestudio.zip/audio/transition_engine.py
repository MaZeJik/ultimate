from core.registry import registry
from core.logger import info


class TransitionEngine:

    def execute(self, project):

        arrangement = project.get("arrangement", [])

        if not arrangement:

            info("TRANSITION -> no arrangement")

            project["transitions"] = []

            return project

        transitions = []

        for i in range(len(arrangement) - 1):

            current = arrangement[i]
            nxt = arrangement[i + 1]

            e1 = current.get("energy", 0.5)
            e2 = nxt.get("energy", 0.5)

            if e2 > e1:

                effect = "riser"

            elif e2 < e1:

                effect = "downlifter"

            else:

                effect = "impact"

            transitions.append({

                "from": current["name"],
                "to": nxt["name"],
                "effect": effect,
                "bars": 1

            })

        project["transitions"] = transitions

        info(
            f"TRANSITION READY -> {len(transitions)} transitions"
        )

        return project


transition_engine = TransitionEngine()

registry.register(
    "transition_engine",
    transition_engine
)