"""
UltimateStudio
batch_run.py

Unattended batch production.

Examples:
    python batch_run.py --count 5
    python batch_run.py --count 3 --genre "tech house" --duration 180
    python batch_run.py --count 2 --genre "tech house" --publish
    python batch_run.py --refresh-stats
"""

from __future__ import annotations

import argparse

from core import settings as _settings  # noqa: F401 - applying env overrides
from core.logger import info
from core.scheduler import scheduler


def _record_youtube_id(project, video_id: str) -> None:
    try:
        from ai.learning import load_history, save_history
    except ImportError:
        return

    history = load_history()
    if not history:
        return

    history[-1]["youtube_video_id"] = video_id
    history[-1]["project_id"] = project.get("id")
    save_history(history)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="UltimateStudio unattended batch run (Tech House / club ready)"
    )
    parser.add_argument(
        "--count", type=int, default=5,
        help="how many videos to produce (default: 5)",
    )
    parser.add_argument(
        "--duration", type=int, default=None,
        help="target track length in seconds (default: project default ~120-180)",
    )
    parser.add_argument(
        "--genre", type=str, default=None,
        help='force genre for every track, e.g. "tech house", "deep house", "dark trap"',
    )
    parser.add_argument(
        "--mood", type=str, default=None,
        help='force mood, e.g. "underground", "luxury", "dark"',
    )
    parser.add_argument(
        "--publish", action="store_true",
        help="upload each finished video to YouTube (see SETUP_YOUTUBE.md)",
    )
    parser.add_argument(
        "--privacy", type=str, default="public",
        choices=["public", "unlisted", "private"],
        help="YouTube privacy status",
    )
    parser.add_argument(
        "--refresh-stats", action="store_true",
        help="pull real view/like/comment counts into learning history, then exit",
    )
    args = parser.parse_args()

    if args.refresh_stats:
        from ai.youtube_publisher import youtube_publisher
        youtube_publisher.refresh_learning_stats()
        return

    job: dict = {}
    if args.duration:
        job["duration"] = args.duration
    if args.genre:
        job["genre"] = args.genre
    if args.mood:
        job["mood"] = args.mood

    jobs = [dict(job) for _ in range(args.count)]

    genre_label = args.genre or "random (director)"
    info(f"BATCH RUN -> producing {len(jobs)} video(s) | genre={genre_label}")

    on_complete = None
    if args.publish:
        from ai.youtube_publisher import youtube_publisher

        def on_complete(project):
            video_id = youtube_publisher.publish_project(
                project, privacy_status=args.privacy
            )
            if video_id:
                _record_youtube_id(project, video_id)

    results = scheduler.run_batch(jobs, on_complete=on_complete)

    info("=" * 70)
    info(f"BATCH DONE -> {len(results)}/{len(jobs)} succeeded")
    for project in results:
        info(f"  - {project.get('title')}  |  {project.get('video_file')}")
    info("=" * 70)


if __name__ == "__main__":
    main()