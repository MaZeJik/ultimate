"""
UltimateStudio
launcher.py

Entry point. Run with:  python launcher.py
(from this file's directory, so the core/ ai/ audio/ video/ workflow/
packages are importable).
"""

from __future__ import annotations

from core import settings as _settings  # noqa: F401 - importing applies env var overrides
from core.doctor import run_diagnostics
from core.logger import info
from core.project_manager import project_manager
from core.resource_monitor import check_and_warn
from workflow.workflow import workflow


def main() -> None:
    info("=" * 70)
    info("UltimateStudio Started")
    info("=" * 70)

    report = run_diagnostics(repair=True)
    if not report.ok:
        info("DIAGNOSTICS FOUND UNRESOLVED PROBLEMS:")
        for problem in report.problems:
            info(f"  - {problem}")
        info("Continuing anyway -- some stages may fail if a listed dependency is missing.")

    check_and_warn()

    project = project_manager.new()
    info(f"PROJECT CREATED -> {project['id']}")

    try:
        project = workflow.run(project)
    except Exception as exc:
        info(f"FATAL ERROR -> {exc}")
        raise

    try:
        project_manager.autosave(project)
    except Exception as exc:
        info(f"AUTOSAVE FAILED -> {exc}")

    info("=" * 70)
    info("UltimateStudio Finished")
    info("=" * 70)


if __name__ == "__main__":
    main()
