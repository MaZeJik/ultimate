"""
UltimateStudio
ai/genre_profiles.py

Genre DNA Library

Expanded with full Tech House / House family so the pipeline can
produce tracks that compete with high-end club channels
(Synapse Melodic style: groovy four-on-floor, rolling bass,
minimal swing, dark-luxury energy curves).
"""

from __future__ import annotations


# ==========================================================
# SHARED KEY LIST
# ==========================================================

ALL_KEYS = [
    "C", "C#", "D", "D#", "E", "F",
    "F#", "G", "G#", "A", "A#", "B",
]


# ==========================================================
# DARK TRAP
# ==========================================================

DARK_TRAP = {
    "name": "Dark Trap",
    "bpm": (135, 150),
    "keys": ALL_KEYS,
    "scales": [
        "minor",
        "harmonic_minor",
        "phrygian",
    ],
    "progressions": [
        ["i", "VI", "III", "VII"],
        ["i", "iv", "v", "i"],
        ["i", "v", "VI", "iv"],
        ["i", "VII", "VI", "VII"],
    ],
    "lead_styles": [
        "ambient",
        "bell",
        "choir",
        "reverse",
        "pad",
    ],
    "bass_styles": [
        "808",
        "slide808",
        "reese",
    ],
    "drum_styles": [
        "trap",
        "dark_trap",
        "hybrid",
    ],
    "hat_density": "high",
    "melody_density": "medium",
    "humanization": 0.25,
    "structure": [
        "INTRO",
        "VERSE",
        "CHORUS",
        "VERSE",
        "CHORUS",
        "OUTRO",
    ],
    "energy_map": {
        "intro": 30,
        "verse": 60,
        "chorus": 100,
        "bridge": 55,
        "outro": 35,
    },
}


# ==========================================================
# PHONK
# ==========================================================

PHONK = {
    "name": "Phonk",
    "bpm": (135, 170),
    "keys": ALL_KEYS,
    "scales": [
        "phrygian",
        "minor",
    ],
    "progressions": [
        ["i", "VII", "VI", "VII"],
        ["i", "VI", "VII", "VI"],
    ],
    "lead_styles": [
        "cowbell",
        "memphis",
        "bell",
    ],
    "bass_styles": [
        "distorted808",
        "cowbellbass",
    ],
    "drum_styles": [
        "phonk",
    ],
    "hat_density": "very_high",
    "melody_density": "low",
    "humanization": 0.15,
    "structure": [
        "INTRO",
        "DROP",
        "DROP",
        "OUTRO",
    ],
    "energy_map": {
        "intro": 40,
        "drop": 100,
        "outro": 45,
    },
}


# ==========================================================
# DRILL
# ==========================================================

DRILL = {
    "name": "Drill",
    "bpm": (138, 145),
    "keys": ALL_KEYS,
    "scales": [
        "minor",
        "harmonic_minor",
    ],
    "progressions": [
        ["i", "VI", "VII", "i"],
        ["i", "III", "VII", "VI"],
    ],
    "lead_styles": [
        "piano",
        "strings",
        "choir",
    ],
    "bass_styles": [
        "glide808",
    ],
    "drum_styles": [
        "uk_drill",
    ],
    "hat_density": "high",
    "melody_density": "medium",
    "humanization": 0.20,
    "structure": [
        "INTRO",
        "VERSE",
        "HOOK",
        "VERSE",
        "HOOK",
        "OUTRO",
    ],
    "energy_map": {
        "intro": 25,
        "verse": 65,
        "hook": 100,
        "outro": 40,
    },
}


# ==========================================================
# TECH HOUSE  (Synapse Melodic competitive core)
# ==========================================================

TECH_HOUSE = {
    "name": "Tech House",
    "bpm": (122, 128),
    "keys": ALL_KEYS,
    "scales": [
        "minor",
        "harmonic_minor",
        "dorian",
    ],
    "progressions": [
        ["i", "VI", "III", "VII"],
        ["i", "VII", "VI", "VII"],
        ["i", "iv", "VI", "V"],
        ["i", "VI", "iv", "V"],
        ["i", "v", "VI", "iv"],
    ],
    "lead_styles": [
        "pluck",
        "stabs",
        "minimal",
        "acid",
        "filtered",
    ],
    "bass_styles": [
        "rolling",
        "sub",
        "filtered",
        "acid_bass",
    ],
    "drum_styles": [
        "four_on_floor",
        "tech_house",
    ],
    "hat_density": "medium_high",
    "melody_density": "low",
    "humanization": 0.12,
    "structure": [
        "INTRO",
        "BUILD",
        "DROP",
        "BREAK",
        "DROP",
        "OUTRO",
    ],
    "energy_map": {
        "intro": 35,
        "build": 65,
        "drop": 100,
        "break": 40,
        "outro": 30,
    },
}


# ==========================================================
# DEEP HOUSE
# ==========================================================

DEEP_HOUSE = {
    "name": "Deep House",
    "bpm": (118, 124),
    "keys": ALL_KEYS,
    "scales": [
        "minor",
        "dorian",
    ],
    "progressions": [
        ["i", "VI", "III", "VII"],
        ["i", "iv", "v", "i"],
        ["i", "VII", "VI", "VII"],
    ],
    "lead_styles": [
        "chord_stab",
        "pad",
        "vocal_chop",
        "soft_pluck",
    ],
    "bass_styles": [
        "deep_sub",
        "rolling",
    ],
    "drum_styles": [
        "four_on_floor",
        "deep_house",
    ],
    "hat_density": "medium",
    "melody_density": "medium",
    "humanization": 0.18,
    "structure": [
        "INTRO",
        "MAIN",
        "BREAK",
        "MAIN",
        "OUTRO",
    ],
    "energy_map": {
        "intro": 30,
        "main": 75,
        "break": 45,
        "outro": 25,
    },
}


# ==========================================================
# MELODIC HOUSE
# ==========================================================

MELODIC_HOUSE = {
    "name": "Melodic House",
    "bpm": (120, 126),
    "keys": ALL_KEYS,
    "scales": [
        "minor",
        "dorian",
        "harmonic_minor",
    ],
    "progressions": [
        ["i", "VI", "III", "VII"],
        ["i", "VII", "VI", "VII"],
        ["i", "iv", "VI", "V"],
    ],
    "lead_styles": [
        "arpeggio",
        "pluck",
        "pad",
        "lead",
    ],
    "bass_styles": [
        "rolling",
        "sub",
    ],
    "drum_styles": [
        "four_on_floor",
        "melodic_house",
    ],
    "hat_density": "medium",
    "melody_density": "high",
    "humanization": 0.15,
    "structure": [
        "INTRO",
        "BUILD",
        "DROP",
        "BREAK",
        "DROP",
        "OUTRO",
    ],
    "energy_map": {
        "intro": 35,
        "build": 60,
        "drop": 95,
        "break": 40,
        "outro": 30,
    },
}


# ==========================================================
# PROGRESSIVE HOUSE
# ==========================================================

PROGRESSIVE_HOUSE = {
    "name": "Progressive House",
    "bpm": (124, 130),
    "keys": ALL_KEYS,
    "scales": [
        "minor",
        "harmonic_minor",
    ],
    "progressions": [
        ["i", "VI", "III", "VII"],
        ["i", "VII", "VI", "VII"],
        ["i", "v", "VI", "iv"],
    ],
    "lead_styles": [
        "lead_uplifting",
        "arpeggio",
        "super_saw",
        "pad",
    ],
    "bass_styles": [
        "rolling",
        "sub",
    ],
    "drum_styles": [
        "four_on_floor",
        "progressive",
    ],
    "hat_density": "medium_high",
    "melody_density": "high",
    "humanization": 0.12,
    "structure": [
        "INTRO",
        "BUILD",
        "DROP",
        "BREAK",
        "BUILD",
        "DROP",
        "OUTRO",
    ],
    "energy_map": {
        "intro": 30,
        "build": 70,
        "drop": 100,
        "break": 40,
        "outro": 25,
    },
}


# ==========================================================
# AFRO HOUSE
# ==========================================================

AFRO_HOUSE = {
    "name": "Afro House",
    "bpm": (118, 124),
    "keys": ALL_KEYS,
    "scales": [
        "minor",
        "dorian",
        "phrygian",
    ],
    "progressions": [
        ["i", "VII", "VI", "VII"],
        ["i", "VI", "III", "VII"],
        ["i", "iv", "v", "i"],
    ],
    "lead_styles": [
        "perc_melody",
        "pluck",
        "vocal_chop",
        "organic",
    ],
    "bass_styles": [
        "deep_sub",
        "rolling",
    ],
    "drum_styles": [
        "four_on_floor",
        "afro",
        "perc_heavy",
    ],
    "hat_density": "high",
    "melody_density": "medium",
    "humanization": 0.22,
    "structure": [
        "INTRO",
        "MAIN",
        "BREAK",
        "MAIN",
        "OUTRO",
    ],
    "energy_map": {
        "intro": 35,
        "main": 85,
        "break": 50,
        "outro": 30,
    },
}


# ==========================================================
# FESTIVAL HOUSE
# ==========================================================

FESTIVAL_HOUSE = {
    "name": "Festival House",
    "bpm": (126, 132),
    "keys": ALL_KEYS,
    "scales": [
        "minor",
        "harmonic_minor",
    ],
    "progressions": [
        ["i", "VI", "III", "VII"],
        ["i", "VII", "VI", "VII"],
        ["i", "v", "VI", "iv"],
    ],
    "lead_styles": [
        "big_lead",
        "super_saw",
        "pluck",
        "anthem",
    ],
    "bass_styles": [
        "rolling",
        "sub",
    ],
    "drum_styles": [
        "four_on_floor",
        "festival",
    ],
    "hat_density": "high",
    "melody_density": "high",
    "humanization": 0.10,
    "structure": [
        "INTRO",
        "BUILD",
        "DROP",
        "BREAK",
        "BUILD",
        "DROP",
        "OUTRO",
    ],
    "energy_map": {
        "intro": 40,
        "build": 75,
        "drop": 100,
        "break": 45,
        "outro": 35,
    },
}


# ==========================================================
# DARK TECHNO
# ==========================================================

DARK_TECHNO = {
    "name": "Dark Techno",
    "bpm": (128, 136),
    "keys": ALL_KEYS,
    "scales": [
        "minor",
        "phrygian",
        "harmonic_minor",
    ],
    "progressions": [
        ["i", "VII", "VI", "VII"],
        ["i", "VI", "VII", "i"],
        ["i", "iv", "v", "i"],
    ],
    "lead_styles": [
        "industrial",
        "acid",
        "stabs",
        "noise",
    ],
    "bass_styles": [
        "reese",
        "acid_bass",
        "sub",
    ],
    "drum_styles": [
        "techno",
        "industrial",
    ],
    "hat_density": "medium",
    "melody_density": "low",
    "humanization": 0.08,
    "structure": [
        "INTRO",
        "BUILD",
        "DROP",
        "BREAK",
        "DROP",
        "OUTRO",
    ],
    "energy_map": {
        "intro": 40,
        "build": 70,
        "drop": 100,
        "break": 45,
        "outro": 35,
    },
}


# ==========================================================
# MASTER LIBRARY
# ==========================================================

GENRE_LIBRARY = {
    # trap family
    "dark trap": DARK_TRAP,
    "phonk": PHONK,
    "drill": DRILL,

    # house / tech house family (Synapse Melodic competitive set)
    "tech house": TECH_HOUSE,
    "deep house": DEEP_HOUSE,
    "melodic house": MELODIC_HOUSE,
    "progressive house": PROGRESSIVE_HOUSE,
    "afro house": AFRO_HOUSE,
    "festival house": FESTIVAL_HOUSE,
    "dark techno": DARK_TECHNO,
}