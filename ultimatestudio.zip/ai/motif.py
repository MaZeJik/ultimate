"""
UltimateStudio - Motif Engine v1
Creates repeatable musical identity (hook system)
"""

from __future__ import annotations

import random
from dataclasses import dataclass

from core.pipeline import Module
from core.logger import info
from core.registry import registry


# ==========================================================
# MOTIF
# ==========================================================

@dataclass(slots=True)
class Motif:
    pattern: list[int]
    rhythm: list[float]
    variation: int


# ==========================================================
# ENGINE
# ==========================================================

class MotifEngine(Module):

    NAME = "Motif Engine"

    # core hook intervals (emotion-driven)
    BASE_PATTERNS = [
        [0, 3, 7, 10],
        [0, 5, 7, 12],
        [0, 2, 3, 7],
        [0, 7, 10, 12],
        [0, 3, 5, 7],
    ]

    RHYTHM_PATTERNS = [
        [0.0, 0.5, 1.0, 1.5],
        [0.0, 1.0, 1.5, 2.5],
        [0.0, 0.75, 1.5, 2.0],
    ]

    def create_motif(self):

        pattern = random.choice(self.BASE_PATTERNS)
        rhythm = random.choice(self.RHYTHM_PATTERNS)

        variation = random.randint(0, 2)

        # small controlled mutation (keeps identity)
        mutated = []

        for i, p in enumerate(pattern):

            if random.random() < 0.2:
                p += random.choice([-1, 1])  # micro variation

            mutated.append(p)

        return Motif(
            pattern=mutated,
            rhythm=rhythm,
            variation=variation
        )

    # ======================================================

    def execute(self, project):

        # create main hook
        motif = self.create_motif()

        # store motif
        project.add_metadata("motif", motif)

        # attach to melody seed, if the melody engine has already run.
        # (melody_engine stores notes as plain dicts with a "midi" key --
        # not as objects with a `.notes`/`.pitch` attribute interface,
        # which is what this method originally, incorrectly, assumed.)
        notes = project.get("melody_notes")

        if notes:
            for i, note in enumerate(notes[:16]):
                shift = motif.pattern[i % len(motif.pattern)]
                note["midi"] = note["midi"] + shift

        info(f"Motif created | pattern={motif.pattern}")

        return project


motif_engine = MotifEngine()

registry.register("motif_engine", motif_engine)