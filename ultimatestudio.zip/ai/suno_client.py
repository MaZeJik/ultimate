"""
UltimateStudio
ai/suno_client.py

A client for MusicAPI's Sonic endpoint (https://musicapi.ai), a
unified music-generation API that proxies Suno-family models. New
accounts get free credits with no credit card required, and the free
credits run the exact same endpoint as paid usage (full quality, no
watermark) -- they just draw down a free balance rather than a paid
one. Once free credits are used up, this project's design means
nothing breaks: ai_music_engine.py falls back to the local synthesis
engine automatically on any API/credit error.

This module could not be tested against a live server from inside
the sandbox that built it (outbound network access there is limited
to package registries). It's built strictly from the provider's
published documentation (docs.musicapi.ai). Test it against your own
free-tier key before relying on it, and watch the first response
shape in case the schema has since changed.

Usage:
    from ai.suno_client import MusicAPIClient
    client = MusicAPIClient(api_key="...")
    track = client.generate_and_wait(
        description="dark trap type beat, 808, aggressive, cinematic",
        title="Broken Empire",
        instrumental=True,
    )
    # track.audio_url
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import requests

from core.logger import error, info, warning


class SunoAPIError(Exception):
    pass


@dataclass
class SunoTrack:
    id: str
    title: str
    audio_url: Optional[str]
    stream_url: Optional[str]
    duration: Optional[float]
    status: str


class MusicAPIClient:
    def __init__(self, api_key: str, base_url: str = "https://api.musicapi.ai/api/v1", timeout: int = 30):
        if not api_key:
            raise SunoAPIError(
                "No music-generation API key configured. Sign up for free credits "
                "(no credit card) at https://musicapi.ai and set the SUNOAPI_KEY "
                "environment variable to your key."
            )
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update(
            {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
        )

    # ------------------------------------------------------

    def _request(self, method: str, path: str, **kwargs) -> dict:
        url = f"{self.base_url}{path}"
        try:
            resp = self.session.request(method, url, timeout=self.timeout, **kwargs)
        except requests.RequestException as exc:
            raise SunoAPIError(f"Network error calling {url}: {exc}") from exc

        if resp.status_code == 401:
            raise SunoAPIError("API key rejected (401) -- check SUNOAPI_KEY.")
        if resp.status_code == 402:
            raise SunoAPIError("Out of free/paid credits (402) -- top up at musicapi.ai or fall back to local synthesis.")
        if resp.status_code == 429:
            raise SunoAPIError("Rate-limited (429) -- back off and retry later.")
        if resp.status_code >= 400 and resp.status_code != 202:
            raise SunoAPIError(f"API error {resp.status_code}: {resp.text[:500]}")

        try:
            return resp.json()
        except ValueError as exc:
            raise SunoAPIError(f"API returned non-JSON response: {resp.text[:300]}") from exc

    def check_credits(self) -> dict:
        return self._request("GET", "/get-credits")

    # ------------------------------------------------------

    def generate(
        self,
        description: str,
        title: str = "",
        tags: str = "",
        instrumental: bool = True,
        model: str = "sonic-v4-5",
    ) -> str:
        """
        Kicks off a generation job. `description` drives the track via
        `gpt_description_prompt` (simple mode -- no lyrics needed,
        which is what an instrumental type-beat pipeline wants). Two
        clips are typically rendered per request. Returns the task id.
        """
        payload = {
            "custom_mode": False,
            "mv": model,
            "gpt_description_prompt": description[:400],
            "make_instrumental": instrumental,
        }
        if title:
            payload["title"] = title[:80]
        if tags:
            payload["tags"] = tags[:120]

        data = self._request("POST", "/sonic/create", json=payload)

        task_id = data.get("task_id") or data.get("data", {}).get("task_id")
        if not task_id:
            raise SunoAPIError(f"Unexpected generate() response shape: {data}")

        info(f"MUSIC API -> generation started, task_id={task_id}")
        return task_id

    def get_status(self, task_id: str) -> list[SunoTrack]:
        data = self._request("GET", f"/sonic/task/{task_id}")
        clips = data.get("data") or []

        tracks = []
        for clip in clips:
            tracks.append(
                SunoTrack(
                    id=clip.get("id", ""),
                    title=clip.get("title", ""),
                    audio_url=clip.get("audio_url"),
                    stream_url=clip.get("stream_audio_url") or clip.get("audio_url"),
                    duration=clip.get("duration"),
                    status=clip.get("state", data.get("status", "unknown")),
                )
            )
        return tracks

    def wait_for_completion(self, task_id: str, poll_every: float = 8.0, max_wait: float = 300.0) -> list[SunoTrack]:
        waited = 0.0
        while waited < max_wait:
            tracks = self.get_status(task_id)
            ready = [t for t in tracks if t.audio_url and t.status in ("succeeded", "complete", "streaming")]
            if ready:
                info(f"MUSIC API -> {len(ready)} track(s) ready after {waited:.0f}s")
                return ready

            failed = [t for t in tracks if t.status in ("failed", "error")]
            if failed and not ready:
                raise SunoAPIError(f"Generation failed for task {task_id}")

            time.sleep(poll_every)
            waited += poll_every
            info(f"MUSIC API -> waiting for generation... ({waited:.0f}s/{max_wait:.0f}s)")

        raise SunoAPIError(f"Generation timed out after {max_wait}s for task {task_id}")

    def generate_and_wait(
        self,
        description: str,
        title: str = "",
        tags: str = "",
        instrumental: bool = True,
        model: str = "sonic-v4-5",
        max_wait: float = 300.0,
    ) -> SunoTrack:
        task_id = self.generate(description=description, title=title, tags=tags, instrumental=instrumental, model=model)
        tracks = self.wait_for_completion(task_id, max_wait=max_wait)
        return tracks[0]

    def download(self, track: SunoTrack, dest_path: Path) -> Path:
        url = track.audio_url or track.stream_url
        if not url:
            raise SunoAPIError(f"Track {track.id} has no downloadable URL yet")

        dest_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            resp = self.session.get(url, timeout=60, stream=True)
            resp.raise_for_status()
            with open(dest_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=1 << 16):
                    f.write(chunk)
        except requests.RequestException as exc:
            raise SunoAPIError(f"Failed to download track audio: {exc}") from exc

        info(f"MUSIC API -> downloaded {dest_path}")
        return dest_path


# kept as an alias so existing imports (ai/ai_music_engine.py) don't
# need to change -- this client now targets MusicAPI, not a
# Suno-specific wrapper, but the class shape is the same.
SunoClient = MusicAPIClient
