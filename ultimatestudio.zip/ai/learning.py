"""
UltimateStudio
ai/learning.py

Persists a record of every generated track's genre/mood/BPM and hit
score to core.config.LEARNING_FILE, and now actually feeds that
history back into future generations.

The original version stored history in `project["learning_history"]`
-- but every `project_manager.new()` call creates a brand-new Project
with an empty dict, so that history was thrown away at the end of
every single run. The log always showed "1 tracks" no matter how
many times the app had actually been run, because nothing was ever
loaded from a previous run. This now reads/writes a real file on
disk, so the history actually accumulates across every run, forever
(see also music_director_engine.py, which now uses this history to
weight genre/mood selection toward what's historically scored well).
"""

from __future__ import annotations

import json
from datetime import datetime, timezone

from core.config import LEARNING_FILE
from core.logger import info, warning
from core.registry import registry

MAX_HISTORY = 2000


def load_history() -> list[dict]:
    if not LEARNING_FILE.exists():
        return []
    try:
        data = json.loads(LEARNING_FILE.read_text(encoding="utf8"))
        return data if isinstance(data, list) else []
    except (json.JSONDecodeError, OSError) as exc:
        warning(f"LEARNING -> history file unreadable ({exc}), starting fresh")
        return []


def save_history(history: list[dict]) -> None:
    LEARNING_FILE.parent.mkdir(parents=True, exist_ok=True)
    try:
        LEARNING_FILE.write_text(json.dumps(history[-MAX_HISTORY:], indent=2, ensure_ascii=False), encoding="utf8")
    except OSError as exc:
        warning(f"LEARNING -> failed to save history: {exc}")


def genre_mood_scores() -> dict[tuple[str, str], float]:
    """Average hit_score per (genre, mood) pair, from real history."""
    history = load_history()
    buckets: dict[tuple[str, str], list[float]] = {}
    for record in history:
        key = (record.get("genre"), record.get("mood"))
        if key[0] is None:
            continue
        buckets.setdefault(key, []).append(record.get("hit_score", 0))
    return {key: sum(scores) / len(scores) for key, scores in buckets.items()}


class LearningEngine:
    def execute(self, project):
        producer = project.get("producer_brain", {})
        fit = project.get("genre_fit", {})
        hit = project.get("hit_score", {})
        plan = project.get("composition_plan", {})

        record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "genre": project.get("genre") or producer.get("genre"),
            "mood": project.get("mood"),
            "bpm": producer.get("bpm", project.get("bpm")),
            "genre_fit": fit.get("score", 0),
            "hit_score": hit.get("score", 0),
            "grade": hit.get("grade", "D"),
            "sections": len(plan.get("sections", [])),
            "bars": plan.get("total_bars", 0),
        }

        history = load_history()
        history.append(record)
        save_history(history)

        scores = [x.get("hit_score", 0) for x in history]
        average = sum(scores) / len(scores) if scores else 0
        best = max(scores) if scores else 0
        worst = min(scores) if scores else 0

        project["learning_history_size"] = len(history)
        project["learning_stats"] = {
            "tracks": len(history),
            "average_hit_score": round(average, 2),
            "best_hit_score": best,
            "worst_hit_score": worst,
        }

        info(f"LEARNING -> {len(history)} tracks total (all-time) | AVG {average:.2f}")

        return project


learning_engine = LearningEngine()

registry.register("learning_engine", learning_engine)
