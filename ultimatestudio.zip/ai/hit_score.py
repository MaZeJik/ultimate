from __future__ import annotations

from core.registry import registry
from core.logger import info


class HitEngine:

    def execute(self, project):

        producer = project.get("producer_brain", {})
        genre_fit = project.get("genre_fit", {})
        arrangement = project.get("arrangement", [])
        composition = project.get("composition_plan", {})

        score = 50.0

        # ---------------------------------------------
        # GENRE FIT
        # ---------------------------------------------

        score += genre_fit.get("score", 50) * 0.30

        # ---------------------------------------------
        # BPM
        # ---------------------------------------------

        bpm = producer.get("bpm", 140)

        if 135 <= bpm <= 150:
            score += 8
        elif 120 <= bpm <= 170:
            score += 5

        # ---------------------------------------------
        # ENERGY
        # ---------------------------------------------

        energy = producer.get("energy", 0.8)

        score += max(0.0, 10 - abs(0.90 - energy) * 25)

        # ---------------------------------------------
        # SWING
        # ---------------------------------------------

        swing = producer.get("swing", 0.12)

        score += max(0.0, 6 - abs(0.12 - swing) * 50)

        # ---------------------------------------------
        # HUMANIZATION
        # ---------------------------------------------

        human = producer.get("humanization", 0.80)

        score += max(0.0, 6 - abs(0.80 - human) * 50)

        # ---------------------------------------------
        # STRUCTURE
        # ---------------------------------------------

        sections = composition.get("sections", [])

        if 7 <= len(sections) <= 10:
            score += 8

        # ---------------------------------------------
        # ARRANGEMENT
        # ---------------------------------------------

        if arrangement:
            score += 6

        # ---------------------------------------------
        # LIMIT
        # ---------------------------------------------

        score = round(max(0.0, min(100.0, score)), 2)

        if score >= 90:
            grade = "A+"
        elif score >= 80:
            grade = "A"
        elif score >= 70:
            grade = "B"
        elif score >= 60:
            grade = "C"
        else:
            grade = "D"

        project["hit_score"] = {

            "score": score,
            "grade": grade,
            "commercial_probability": round(score / 100, 2),
            "release_ready": score >= 80,

            "details": {

                "genre_fit": genre_fit.get("score", 0),
                "bpm": bpm,
                "energy": energy,
                "swing": swing,
                "humanization": human,
                "sections": len(sections)

            }

        }

        info(
            f"HIT SCORE -> {score:.2f} ({grade})"
        )

        return project


hit_engine = HitEngine()

registry.register(
    "hit_engine",
    hit_engine
)