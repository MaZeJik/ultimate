"""
UltimateStudio
ai/title_engine.py

YouTube title generator.

Trap titles keep the classic "emoji + adjective + Type Beat" shape.
House / Tech House titles switch to the competitive club-mix format
used by channels like Synapse Melodic:
  ADDICTIVE TECH HOUSE Mix [2026] | Underground Night Party
"""

from __future__ import annotations

import random

from core.pipeline import Module
from core.logger import info
from core.registry import registry


HOUSE_GENRES = {
    "tech house", "deep house", "melodic house", "progressive house",
    "afro house", "festival house", "dark techno", "techno", "minimal",
}


class TitleEngine(Module):

    NAME = "Title Engine"

    # --- trap family ---
    PREFIXES = [
        "Dark", "Ultimate", "Immortal", "Broken", "Lost", "Night",
        "Ghost", "Savage", "Inferno", "Shadow", "Neon", "Cyber",
    ]
    SUFFIXES = [
        "Dream", "Empire", "Revenge", "Protocol", "City", "Soul",
        "Sky", "Dimension", "Vision", "Future", "Machine", "System",
    ]
    EMOJIS = ["🔥", "⚡", "💀", "🌑", "🚀", "🎧", "🎵", "👑"]

    # --- house / tech house family ---
    HOUSE_HOOKS = [
        "ADDICTIVE",
        "BEST",
        "NONSTOP",
        "EXCLUSIVE",
        "ULTIMATE",
        "DO NOT SKIP",
        "PURE",
        "HEAVY",
        "HYPNOTIC",
        "DARK LUXURY",
    ]
    HOUSE_MIDDLES = [
        "TECH HOUSE",
        "ACID TECH HOUSE",
        "GROOVY TECH HOUSE",
        "DARK TECH HOUSE",
        "DEEP HOUSE",
        "MELODIC HOUSE",
        "PROGRESSIVE HOUSE",
        "AFRO HOUSE",
        "UNDERGROUND TECH HOUSE",
    ]
    HOUSE_TAILS = [
        "Mix [2026] | Ultimate Night Party",
        "Mix [2026] | Secret Warehouse",
        "Mix [2026] | Underground Nightclub",
        "Mix [2026] | Club Party",
        "DJ Mix [2026] | Peak Time Club",
        "Set [2026] | Dark Luxury Night",
        "[2026] | Warehouse Rave",
        "Mix [2026] | Late Night Drive",
        "Session [2026] | Underground",
    ]

    def _house_genre_label(self, genre: str) -> str:
        g = genre.lower()
        mapping = {
            "tech house": "TECH HOUSE",
            "deep house": "DEEP HOUSE",
            "melodic house": "MELODIC HOUSE",
            "progressive house": "PROGRESSIVE HOUSE",
            "afro house": "AFRO HOUSE",
            "festival house": "FESTIVAL HOUSE",
            "dark techno": "DARK TECHNO",
            "techno": "TECHNO",
        }
        return mapping.get(g, "TECH HOUSE")

    def build_title_candidates(self, project, n: int = 5) -> list[str]:
        genre = str(project.genre or "tech house").lower()
        mood = str(project.mood or "dark").lower()
        candidates = []

        if genre in HOUSE_GENRES or "house" in genre or "techno" in genre:
            label = self._house_genre_label(genre)
            for _ in range(n):
                hook = random.choice(self.HOUSE_HOOKS)
                # sometimes force the real genre into the middle
                middle = label if random.random() < 0.55 else random.choice(self.HOUSE_MIDDLES)
                tail = random.choice(self.HOUSE_TAILS)
                # optional mood accent for dark/luxury
                if mood in ("dark", "underground", "luxury", "mysterious") and random.random() < 0.35:
                    title = f"{hook} {middle} | {mood.upper()} Night [2026]"
                else:
                    title = f"{hook} {middle} {tail}"
                candidates.append(title[:100])
        else:
            for _ in range(n):
                prefix = random.choice(self.PREFIXES)
                suffix = random.choice(self.SUFFIXES)
                emoji = random.choice(self.EMOJIS)
                candidates.append(
                    f"{emoji} {prefix} {suffix} | {genre} | {mood} Type Beat 2026"
                )

        return candidates

    def build_title(self, project):
        return self.build_title_candidates(project, n=1)[0]

    def execute(self, project):
        candidates = self.build_title_candidates(project)
        title = candidates[0]

        try:
            from ai.llm_director import get_director
            director = get_director()
            if director is not None:
                hit_score = project.get("hit_score", {}).get("score", 0)
                chosen = director.pick_best_title(
                    candidates, project.genre, project.mood, hit_score
                )
                if chosen:
                    title = chosen[:100]
        except Exception as exc:
            info(f"LLM title selection unavailable ({exc}), using template title")

        project.title = title
        project.add_metadata("youtube_title", title)
        info(f"Title Generated -> {title}")
        return project


title_engine = TitleEngine()
registry.register("title_engine", title_engine)