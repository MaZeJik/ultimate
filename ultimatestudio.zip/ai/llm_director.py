"""
UltimateStudio
ai/llm_director.py

Uses a real LLM (Gemini, free tier -- no credit card, ~1500
requests/day) to make an actual creative judgment call instead of
picking from a fixed template. Specifically: title_engine.py builds
several template-based title candidates ("emoji + adjective + genre
+ Type Beat 2026"); this asks the LLM to pick and refine the
strongest one for the actual genre/mood/hit-score context, which is
a genuinely different kind of decision than template substitution or
weighted random choice.

This is intentionally scoped narrow (one clear decision, one call
per track) rather than routing every decision through an LLM --
that would multiply API calls for marginal benefit and risk burning
through the free daily quota fast. If GEMINI_API_KEY isn't set, or
the call fails for any reason, this falls back to the best template
candidate with no interruption to the pipeline.

This module could not be tested against the live Gemini API from
inside the sandbox that built it (no route to generativelanguage.
googleapis.com there). Built against the official google-genai SDK;
verify with your own free-tier key.
"""

from __future__ import annotations

from core.logger import info, warning


class LLMDirectorError(Exception):
    pass


class LLMDirector:
    MODEL = "gemini-2.5-flash"

    def __init__(self, api_key: str):
        self.api_key = api_key
        self._client = None

    def _get_client(self):
        if self._client is not None:
            return self._client
        try:
            from google import genai
        except ImportError as exc:
            raise LLMDirectorError("Missing 'google-genai'. Run: pip install google-genai") from exc

        self._client = genai.Client(api_key=self.api_key)
        return self._client

    def pick_best_title(self, candidates: list[str], genre: str, mood: str, hit_score: float) -> str | None:
        """
        Asks the LLM to choose (and lightly polish) the strongest title
        from a list of candidates, given the track's actual context.
        Returns None on any failure so the caller can fall back
        cleanly to candidates[0].
        """
        if not self.api_key:
            return None
        if not candidates:
            return None

        try:
            client = self._get_client()
        except LLMDirectorError as exc:
            warning(f"LLM DIRECTOR -> {exc}")
            return None

        prompt = (
            "You are a YouTube title expert for instrumental type-beat music. "
            f"Genre: {genre}. Mood: {mood}. Internal quality score: {hit_score}/100.\n\n"
            "Here are candidate titles:\n"
            + "\n".join(f"- {c}" for c in candidates)
            + "\n\nPick the single strongest one for maximizing YouTube click-through "
            "rate, and lightly polish it if useful (keep it under 100 characters, "
            "keep any emoji, don't invent a genre/mood that wasn't given). "
            "Reply with ONLY the final title text, nothing else."
        )

        try:
            response = client.models.generate_content(model=self.MODEL, contents=prompt)
            text = (response.text or "").strip().strip('"')
        except Exception as exc:  # noqa: BLE001 - any API failure just means "use the template fallback"
            warning(f"LLM DIRECTOR -> Gemini call failed ({exc}), using template title instead")
            return None

        if not text or len(text) > 120:
            return None

        info(f"LLM DIRECTOR -> chose title: {text}")
        return text


    def write_description(self, template_description: str, genre: str, mood: str, bpm: int) -> str | None:
        """
        Given the template-generated description as a factual base
        (genre/mood/BPM/hashtags), asks the LLM to write a more
        engaging opening hook while preserving the factual lines.
        Returns None on any failure so the caller falls back to the
        template description unchanged.
        """
        if not self.api_key:
            return None

        try:
            client = self._get_client()
        except LLMDirectorError as exc:
            warning(f"LLM DIRECTOR -> {exc}")
            return None

        prompt = (
            "You write YouTube video descriptions for instrumental type-beat music. "
            f"Genre: {genre}. Mood: {mood}. BPM: {bpm}.\n\n"
            "Write a short, engaging 2-3 sentence opening hook for the description "
            "(no emojis spam, no clickbait lies, just genuinely compelling copy that "
            "makes someone want to keep listening). Reply with ONLY the hook text, "
            "nothing else -- no preamble, no quotes around it."
        )

        try:
            response = client.models.generate_content(model=self.MODEL, contents=prompt)
            hook = (response.text or "").strip().strip('"')
        except Exception as exc:  # noqa: BLE001 - any API failure just means "use the template description"
            warning(f"LLM DIRECTOR -> Gemini call failed ({exc}), using template description instead")
            return None

        if not hook or len(hook) > 500:
            return None

        info("LLM DIRECTOR -> wrote a custom description hook")
        return hook + "\n\n" + template_description


_director: LLMDirector | None = None


def get_director() -> LLMDirector | None:
    global _director
    from core.config import SETTINGS

    if not SETTINGS.gemini_api_key:
        return None
    if _director is None:
        _director = LLMDirector(api_key=SETTINGS.gemini_api_key)
    return _director
