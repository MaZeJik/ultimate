"""
UltimateStudio
ai/seo_engine.py

Description + tags. House tracks get club-mix SEO language instead of
generic "type beat / 808" tags.
"""

from __future__ import annotations

import random

from core.pipeline import Module
from core.logger import info
from core.registry import registry


HOUSE_GENRES = {
    "tech house", "deep house", "melodic house", "progressive house",
    "afro house", "festival house", "dark techno", "techno", "minimal",
}


class SEOEngine(Module):

    NAME = "SEO Engine"

    BASE_TAGS_TRAP = [
        "type beat", "instrumental", "trap beat", "dark trap", "phonk",
        "drift phonk", "dark techno", "cyberpunk", "music", "bass", "808",
        "cinematic", "gaming music", "workout music", "epic beat",
    ]

    BASE_TAGS_HOUSE = [
        "tech house", "tech house mix", "tech house 2026", "house music",
        "deep house", "club mix", "dj mix", "underground", "night drive",
        "warehouse rave", "peak time", "electronic music", "dance music",
        "minimal tech", "acid tech house", "groovy tech house",
        "club party", "bass boosted", "dark luxury",
    ]

    HASHTAGS_TRAP = [
        "#typebeat", "#darktrap", "#phonk", "#darktechno",
        "#instrumental", "#music", "#beats", "#producer", "#trap", "#cyberpunk",
    ]

    HASHTAGS_HOUSE = [
        "#techhouse", "#housemusic", "#clubmix", "#djmix",
        "#underground", "#electronicmusic", "#techhouse2026",
        "#nightdrive", "#warehouserave", "#dance",
    ]

    DESCRIPTION_END_TRAP = """
🎧 Produced with UltimateStudio
🔔 Subscribe for more music.

#typebeat #darktrap #phonk #instrumental
"""

    DESCRIPTION_END_HOUSE = """
🎧 Produced with UltimateStudio
🔔 Subscribe for more underground electronic journeys.

#techhouse #housemusic #clubmix #underground #electronicmusic
"""

    def build_keywords(self, project):
        genre = str(project.genre or "").lower()
        mood = str(project.mood or "").lower()
        keywords = set()
        keywords.add(genre)
        keywords.add(mood)

        if genre in HOUSE_GENRES or "house" in genre:
            for tag in self.BASE_TAGS_HOUSE:
                keywords.add(tag)
        else:
            for tag in self.BASE_TAGS_TRAP:
                keywords.add(tag)

        return sorted(k for k in keywords if k)

    def build_description(self, project):
        genre = str(project.genre or "tech house")
        mood = str(project.mood or "dark")
        bpm = project.get("bpm", 124)
        duration = project.get("duration", 120)
        is_house = genre.lower() in HOUSE_GENRES or "house" in genre.lower()

        if is_house:
            intro = (
                f"Step into the underground.\n\n"
                f"This {genre} session delivers addictive grooves, "
                f"deep rolling basslines and pure night energy — "
                f"built for warehouse raves, peak-time club sets and late-night drives.\n\n"
                f"Genre : {genre}\n"
                f"Mood : {mood}\n"
                f"BPM : {bpm}\n"
                f"Duration : {duration} sec\n\n"
            )
            hashtags = " ".join(random.sample(self.HASHTAGS_HOUSE, min(5, len(self.HASHTAGS_HOUSE))))
            end = self.DESCRIPTION_END_HOUSE
        else:
            intro = (
                f"{genre} instrumental with {mood.lower()} atmosphere.\n\n"
                f"Genre : {genre}\n"
                f"Mood : {mood}\n"
                f"BPM : {bpm}\n"
                f"Duration : {duration} sec\n\n"
            )
            hashtags = " ".join(random.sample(self.HASHTAGS_TRAP, min(5, len(self.HASHTAGS_TRAP))))
            end = self.DESCRIPTION_END_TRAP

        return intro + hashtags + "\n\n" + end

    def execute(self, project):
        keywords = self.build_keywords(project)

        try:
            from ai.trend_research import trend_research
            trending = trend_research.trending_tags(project.genre)
            if trending:
                keywords = list(dict.fromkeys(trending + keywords))
                info(f"SEO -> blended {len(trending)} real trending tag(s)")
        except Exception as exc:
            info