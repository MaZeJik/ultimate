"""
UltimateStudio
ai/viral_intelligence.py
"""

from __future__ import annotations

import random

from core.pipeline import Module
from core.logger import info
from core.registry import registry


class ViralIntelligenceEngine(Module):

    NAME = "Viral Intelligence Engine"

    def simulate_retention(self, project):

        motif = project.metadata.get("motif")
        brain = project.metadata.get("music_brain")

        base = 0.5

        # motif = hook gücü
        if motif:
            base += 0.2

        # energy impact
        energy = brain.energy_map if brain else {}
        peak = max(energy.values()) if energy else 50

        if peak > 80:
            base += 0.2

        # randomness (algorithm noise)
        base += random.uniform(-0.1, 0.1)

        return max(0.0, min(1.0, base))

    # ======================================================

    def execute(self, project):

        retention = self.simulate_retention(project)

        project.add_metadata("viral_score", retention)

        # feedback loop → future learning influence
        project.add_metadata("learning_feedback", {
            "viral_score": retention,
            "success_bias": retention * 0.8 + random.uniform(0, 0.2)
        })

        info(f"Viral Score -> {retention:.2f}")

        return project


viral_intelligence_engine = ViralIntelligenceEngine()

registry.register("viral_intelligence_engine", viral_intelligence_engine)