"""
UltimateStudio
ai/prompt_engine.py

Early metadata prompt (title/description/visual/music tags).
House-aware so music_mode=ai and thumbnail prompts speak the
right language for tech house tracks.
"""

from __future__ import annotations

import random
from dataclasses import dataclass

from core.pipeline import Module
from core.logger import info
from core.registry import registry


HOUSE_GENRES = {
    "tech house", "deep house", "melodic house", "progressive house",
    "afro house", "festival house", "dark techno", "techno", "minimal",
}


@dataclass(slots=True)
class Prompt:
    title: str
    description: str
    visual_prompt: str
    thumbnail_prompt: str
    music_prompt: str
    tags: list[str]


class PromptEngine(Module):

    NAME = "Prompt Engine"

    GENRES = [
        "Tech House", "Deep House", "Dark Techno", "Dark Trap",
        "Drift Phonk", "Melodic House", "Progressive House", "Industrial",
    ]

    MOODS = [
        "Dark", "Aggressive", "Emotional", "Powerful",
        "Mysterious", "Energetic", "Underground", "Luxury",
    ]

    VISUALS_TRAP = [
        "Neon cyber city", "Dark futuristic skyline", "Rainy Tokyo street",
        "Underground tunnel", "Destroyed metropolis", "Abandoned factory",
        "Black desert", "Cyber highway",
    ]

    VISUALS_HOUSE = [
        "Dark luxury underground warehouse club",
        "Premium industrial nightclub interior",
        "Secret warehouse rave at night",
        "Minimalist high-end club corridor with fog",
        "Concrete underground dancefloor",
        "VIP lounge with volumetric light beams",
        "Abandoned factory converted into a club",
        "Black mirrored club hallway",
    ]

    def build(self, project):
        genre = project.genre or random.choice(self.GENRES)
        mood = project.mood or random.choice(self.MOODS)
        genre_l = str(genre).lower()
        is_house = genre_l in HOUSE_GENRES or "house" in genre_l

        visual = random.choice(self.VISUALS_HOUSE if is_house else self.VISUALS_TRAP)

        if is_house:
            title = f"{mood} {genre}"
            description = (
                f"{genre} session with {mood.lower()} underground atmosphere — "
                f"built for night drives and warehouse energy."
            )
            thumbnail = (
                f"Ultra realistic, {visual}, fixed camera, slow motion aesthetic, "
                f"volumetric fog, cinematic lighting, 8K, {mood.lower()} atmosphere, "
                f"no text, no watermark"
            )
            music = (
                f"{genre}, {mood}, {project.bpm} BPM, "
                f"rolling bass, four on the floor, hypnotic groove, "
                f"{project.duration} seconds, instrumental"
            )
            tags = [
                genre, mood, "Tech House Mix", "Club Mix", "Underground",
                "Electronic", "DJ Mix", "Night Drive",
            ]
        else:
            title = f"{mood} {genre}"
            description = f"{genre} instrumental with {mood.lower()} atmosphere."
            thumbnail = (
                f"Ultra realistic, {visual}, cinematic lighting, 8K, "
                f"{mood.lower()} atmosphere."
            )
            music = (
                f"{genre}, {mood}, {project.bpm} BPM, {project.duration} seconds."
            )
            tags = [
                genre, mood, "Type Beat", "Instrumental", "Music", "Dark", "Bass", "808",
            ]

        return Prompt(title, description, visual, thumbnail, music, tags)

    def execute(self, project):
        prompt = self.build(project)

        if not project.title:
            project.title = prompt.title

        project.description = prompt.description
        project.tags = prompt.tags
        project.add_metadata("prompt", prompt)

        info(f"Prompt Created -> {project.title}")
        return project


prompt_engine = PromptEngine()
registry.register("prompt_engine", prompt_engine)