"""
UltimateStudio
ai/ai_music_engine.py

When SETTINGS.music_mode == "ai", replaces the local synthesis chain
with a real generated track from the configured music provider
(kie / sunoapi_org / musicapi).

On success sets project["_ai_music_used"] = True so workflow skips
redundant synthesis stages.
"""

from __future__ import annotations

import random
import subprocess
import time
import wave
from pathlib import Path

import numpy as np

from core.config import OUTPUT_AUDIO, SETTINGS
from core.logger import error, info, warning
from core.registry import registry

MAX_RETRIES = 3
RETRY_BACKOFF_SEC = 15

HOUSE_GENRES = {
    "tech house", "deep house", "melodic house", "progressive house",
    "afro house", "festival house", "dark techno", "techno", "minimal",
}


class AIMusicEngine:

    def build_description(self, project) -> str:
        genre = str(project.get("genre", "tech house")).lower()
        mood = str(project.get("mood", "dark")).lower()
        bpm = project.get("bpm", 124)
        duration = project.get("duration", 120)

        if genre in HOUSE_GENRES or "house" in genre or "techno" in genre:
            extras = []
            if "tech" in genre or genre == "minimal":
                extras.extend(["groovy tech house", "hypnotic minimal groove", "rolling bassline"])
            if "deep" in genre:
                extras.extend(["deep sub bass", "warm chords"])
            if "melodic" in genre or "progressive" in genre:
                extras.extend(["melodic lead", "emotional progression"])
            if "afro" in genre:
                extras.extend(["organic percussion", "tribal groove"])
            if "techno" in genre:
                extras.extend(["driving techno kick", "industrial atmosphere"])
            if random.random() < 0.25:
                extras.append("subtle acid 303 movement")

            extra_str = ", ".join(extras) if extras else "club ready groove"
            return (
                f"{genre} instrumental, {mood} atmosphere, {bpm} BPM, "
                f"four on the floor kick, {extra_str}, "
                f"peak time club energy, underground warehouse vibe, "
                f"no vocals, professional mix and mastering, "
                f"about {duration} seconds"
            )

        return (
            f"{genre} instrumental type beat, {mood} atmosphere, {bpm} BPM, "
            f"no vocals, cinematic, professional mix and mastering"
        )

    def build_tags(self, project) -> str:
        genre = str(project.get("genre", "tech house")).lower()
        mood = str(project.get("mood", "dark")).lower()

        if genre in HOUSE_GENRES or "house" in genre or "techno" in genre:
            return f"{genre}, {mood}, instrumental, club mix, underground, electronic"
        return f"{genre}, {mood}, instrumental, type beat"

    def _decode_to_wav(self, src_path: Path) -> Path:
        """API returns mp3; convert to wav for the rest of the pipeline."""
        wav_path = src_path.with_suffix(".wav")
        cmd = [
            "ffmpeg", "-y", "-loglevel", "error",
            "-i", str(src_path),
            "-ar", "44100", "-ac", "2",
            str(wav_path),
        ]
        subprocess.run(cmd, check=True)
        return wav_path

    def _load_wav_as_array(self, wav_path: Path) -> np.ndarray:
        with wave.open(str(wav_path), "rb") as w:
            n = w.getnframes()
            channels = w.getnchannels()
            raw = w.readframes(n)
            data = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
            if channels == 2:
                data = data.reshape(-1, 2).T
            else:
                data = np.stack([data, data])
        return data

    def execute(self, project):
        if SETTINGS.music_mode != "ai":
            return project

        try:
            from ai.suno_client import MusicAPIClient, SunoAPIError
        except ImportError as exc:
            warning(f"AI MUSIC -> missing dependency ({exc}), falling back to synthetic")
            return project

        if not SETTINGS.suno_api_key:
            self._fail(
                project,
                "No music-generation API key configured. "
                "Set SUNOAPI_KEY in .env (kie.ai or sunoapi.org key).",
            )
            return project

        try:
            client = MusicAPIClient(
                api_key=SETTINGS.suno_api_key,
                base_url=getattr(SETTINGS, "suno_api_base", "https://api.kie.ai"),
                provider=getattr(SETTINGS, "music_provider", "kie"),
            )
        except SunoAPIError as exc:
            self._fail(project, str(exc))
            return project

        description = self.build_description(project)
        tags = self.build_tags(project)
        genre = str(project.get("genre", "track"))
        title = project.get("title") or f"{genre} mix"
        title = str(title)[:80]

        info(f"AI MUSIC -> requesting generation: {description}")

        last_error: str = ""
        wav_path: Path | None = None

        for attempt in range(1, MAX_RETRIES + 1):
            try:
                track = client.generate_and_wait(
                    description=description,
                    title=title,
                    tags=tags,
                    instrumental=True,
                )
                project_id = str(project.get("id", "track"))[:8]
                mp3_path = OUTPUT_AUDIO / f"{project_id}_ai.mp3"
                client.download(track, mp3_path)
                wav_path = self._decode_to_wav(mp3_path)
                break
            except SunoAPIError as exc:
                last_error = str(exc)
                if "401" in last_error or "key rejected" in last_error.lower():
                    break
                warning(f"AI MUSIC -> attempt {attempt}/{MAX_RETRIES} failed: {exc}")
                if attempt < MAX_RETRIES:
                    time.sleep(RETRY_BACKOFF_SEC)
            except subprocess.CalledProcessError as exc:
                last_error = f"ffmpeg decode failed: {exc}"
                break
            except Exception as exc:
                last_error = str(exc)
                warning(f"AI MUSIC -> attempt {attempt}/{MAX_RETRIES} unexpected: {exc}")
                if attempt < MAX_RETRIES:
                    time.sleep(RETRY_BACKOFF_SEC)

        if wav_path is None:
            self._fail(project, last_error or "generation did not produce a usable file")
            return project

        master_audio = self._load_wav_as_array(wav_path)

        provider = getattr(SETTINGS, "music_provider", "kie")
        project["master_audio"] = master_audio
        project["master_info"] = {
            "peak": float(np.max(np.abs(master_audio))),
            "rms": float(np.sqrt(np.mean(master_audio ** 2))),
            "channels": 2,
            "samples": int(master_audio.shape[1]),
            "sample_rate": 44100,
            "source": provider,
        }
        project["audio_file"] = str(wav_path)
        project["_ai_music_used"] = True

        info("=" * 60)
        info(f"AI MUSIC -> SUCCESS ({provider}): real generated track ready ({wav_path})")
        info("=" * 60)
        return project

    def _fail(self, project, reason: str) -> None:
        project["_ai_music_failed"] = reason
        if SETTINGS.music_strict_ai:
            error("=" * 60)
            error(
                f"AI MUSIC -> FAILED, strict mode is ON so this run will NOT "
                f"fall back silently: {reason}"
            )
            error("=" * 60)
        else:
            warning(f"AI MUSIC -> {reason}. Falling back to local synthesis.")


ai_music_engine = AIMusicEngine()
registry.register("ai_music_engine", ai_music_engine)