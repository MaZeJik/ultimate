"""
UltimateStudio
ai/youtube_publisher.py

Publishes a finished project (video + generated title/description/
tags/thumbnail) to YouTube via the real YouTube Data API v3, using
OAuth2 (InstalledAppFlow -- a one-time browser login, then a cached
refresh token so future runs don't need to log in again).

Setup (see SETUP_YOUTUBE.md):
  1. Create a project in Google Cloud Console, enable "YouTube Data
     API v3"
  2. Create OAuth 2.0 credentials (Desktop app), download the JSON
     as client_secret.json into D:\\UltimateStudio\\config\\
  3. First run opens a browser for one-time login; after that a
     cached token file handles it automatically

This module could not be tested against the live YouTube API from
inside the sandbox that built it (no OAuth browser flow is possible
there, and no route to googleapis.com). Built strictly against the
official, documented API (videos.insert, thumbnails.set). Test the
OAuth flow and an actual upload yourself before relying on it for
unattended publishing.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from core.config import CONFIG_DIR
from core.logger import error, info, warning

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]
CLIENT_SECRET_FILE = CONFIG_DIR / "client_secret.json"
TOKEN_FILE = CONFIG_DIR / "youtube_token.json"


class YouTubePublishError(Exception):
    pass


class YouTubePublisher:
    def __init__(self):
        self._service = None

    # ------------------------------------------------------
    # auth
    # ------------------------------------------------------

    def _get_credentials(self):
        try:
            from google.auth.transport.requests import Request
            from google.oauth2.credentials import Credentials
            from google_auth_oauthlib.flow import InstalledAppFlow
        except ImportError as exc:
            raise YouTubePublishError(
                "Missing YouTube upload dependencies. Run: "
                "pip install google-api-python-client google-auth-oauthlib google-auth-httplib2"
            ) from exc

        creds = None
        if TOKEN_FILE.exists():
            creds = Credentials.from_authorized_user_file(str(TOKEN_FILE), SCOPES)

        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())

        if not creds or not creds.valid:
            if not CLIENT_SECRET_FILE.exists():
                raise YouTubePublishError(
                    f"No {CLIENT_SECRET_FILE.name} found in {CONFIG_DIR}. "
                    "Download OAuth 2.0 'Desktop app' credentials from Google Cloud "
                    "Console (YouTube Data API v3 enabled) and save them there. "
                    "See SETUP_YOUTUBE.md."
                )
            flow = InstalledAppFlow.from_client_secrets_file(str(CLIENT_SECRET_FILE), SCOPES)
            info("YOUTUBE -> opening browser for one-time login...")
            creds = flow.run_local_server(port=0)
            TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
            TOKEN_FILE.write_text(creds.to_json(), encoding="utf8")
            info(f"YOUTUBE -> login cached at {TOKEN_FILE} (future runs won't need the browser)")

        return creds

    def _get_service(self):
        if self._service is not None:
            return self._service

        try:
            from googleapiclient.discovery import build
        except ImportError as exc:
            raise YouTubePublishError(
                "Missing 'google-api-python-client'. Run: pip install google-api-python-client"
            ) from exc

        creds = self._get_credentials()
        self._service = build("youtube", "v3", credentials=creds)
        return self._service

    # ------------------------------------------------------
    # upload
    # ------------------------------------------------------

    def upload(
        self,
        video_path: Path,
        title: str,
        description: str,
        tags: list[str],
        category_id: str = "10",  # 10 = Music
        privacy_status: str = "public",
        thumbnail_path: Optional[Path] = None,
    ) -> str:
        try:
            from googleapiclient.http import MediaFileUpload
        except ImportError as exc:
            raise YouTubePublishError("Missing 'google-api-python-client'.") from exc

        if not video_path.exists():
            raise YouTubePublishError(f"Video file not found: {video_path}")

        service = self._get_service()

        body = {
            "snippet": {
                "title": title[:100],
                "description": description[:5000],
                "tags": tags[:500],
                "categoryId": category_id,
            },
            "status": {
                "privacyStatus": privacy_status,
                "selfDeclaredMadeForKids": False,
            },
        }

        media = MediaFileUpload(str(video_path), chunksize=1024 * 1024 * 8, resumable=True, mimetype="video/mp4")

        info(f"YOUTUBE -> uploading '{title}' ({video_path.name})")
        request = service.videos().insert(part="snippet,status", body=body, media_body=media)

        response = None
        while response is None:
            status, response = request.next_chunk()
            if status:
                info(f"YOUTUBE -> upload progress: {int(status.progress() * 100)}%")

        video_id = response["id"]
        info(f"YOUTUBE -> upload complete: https://youtube.com/watch?v={video_id}")

        if thumbnail_path and thumbnail_path.exists():
            try:
                service.thumbnails().set(videoId=video_id, media_body=MediaFileUpload(str(thumbnail_path))).execute()
                info("YOUTUBE -> custom thumbnail set")
            except Exception as exc:  # noqa: BLE001 - thumbnail failure shouldn't undo a successful upload
                warning(f"YOUTUBE -> thumbnail upload failed ({exc}), video is still published without it")

        return video_id

    def publish_project(self, project, privacy_status: str = "public") -> Optional[str]:
        """Convenience wrapper: pulls title/description/tags/video/thumbnail
        straight from a finished project dict."""
        try:
            from core.quality_gate import check_project

            gate_result = check_project(project)
            if not gate_result.passed:
                error(f"YOUTUBE -> publish blocked by quality gate: {'; '.join(gate_result.problems)}")
                return None
        except ImportError:
            pass  # quality_gate optional -- don't block publishing if it's missing

        video_file = project.get("video_file")
        if not video_file or not Path(video_file).exists():
            warning("YOUTUBE -> no video file on project, skipping publish")
            return None

        title = project.get("title") or "Untitled"
        description = project.get("description") or ""
        tags = project.get("tags") or []

        thumbnail_path = None
        thumb_meta = project.get("thumbnail_file")
        if thumb_meta:
            candidate = Path(thumb_meta)
            if candidate.exists():
                thumbnail_path = candidate

        try:
            return self.upload(
                video_path=Path(video_file),
                title=title,
                description=description,
                tags=tags,
                privacy_status=privacy_status,
                thumbnail_path=thumbnail_path,
            )
        except YouTubePublishError as exc:
            error(f"YOUTUBE -> publish failed: {exc}")
            return None

    # ------------------------------------------------------
    # analytics (real performance feedback for ai/learning.py)
    # ------------------------------------------------------

    def get_video_stats(self, video_id: str) -> Optional[dict]:
        """
        Pulls real view count / like count / comment count from the
        YouTube Data API (statistics.list -- available immediately,
        no separate Analytics API scope needed). For deeper metrics
        (average view duration, CTR, audience retention curve) the
        YouTube Analytics API is needed instead, which requires the
        additional 'yt-analytics.readonly' scope; that's a bigger
        setup step left for when the basic loop is confirmed working.
        """
        try:
            service = self._get_service()
            response = service.videos().list(part="statistics", id=video_id).execute()
        except Exception as exc:  # noqa: BLE001 - analytics failures shouldn't break anything else
            warning(f"YOUTUBE -> couldn't fetch stats for {video_id}: {exc}")
            return None

        items = response.get("items", [])
        if not items:
            return None

        stats = items[0].get("statistics", {})
        return {
            "video_id": video_id,
            "views": int(stats.get("viewCount", 0)),
            "likes": int(stats.get("likeCount", 0)),
            "comments": int(stats.get("commentCount", 0)),
        }

    def refresh_learning_stats(self) -> int:
        """
        For every published video recorded in learning history, pulls
        current view/like/comment counts and updates the record with
        real performance data (see ai/learning.py). Returns how many
        records were updated.
        """
        try:
            from ai.learning import load_history, save_history
        except ImportError:
            return 0

        history = load_history()
        updated = 0

        for record in history:
            video_id = record.get("youtube_video_id")
            if not video_id:
                continue

            stats = self.get_video_stats(video_id)
            if stats is None:
                continue

            record["youtube_views"] = stats["views"]
            record["youtube_likes"] = stats["likes"]
            record["youtube_comments"] = stats["comments"]
            updated += 1

        if updated:
            save_history(history)
            info(f"YOUTUBE -> refreshed real performance data for {updated} track(s)")

        return updated


youtube_publisher = YouTubePublisher()
