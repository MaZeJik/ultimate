"""
UltimateStudio
ai/music_director_engine.py

Picks genre / mood / BPM. Tech House family is now first-class and
weighted so long unattended runs naturally produce the style that
competes with Synapse Melodic-type channels, while still exploring
trap/phonk when history or random exploration asks for it.
"""

from __future__ import annotations

import random

from core.logger import info
from core.registry import registry


class MusicDirectorEngine:

    # order roughly reflects production priority for this project direction
    GENRES = [
        # house / tech house block (competitive set)
        "tech house",
        "deep house",
        "melodic house",
        "progressive house",
        "afro house",
        "festival house",
        "dark techno",
        # classic trap block
        "dark trap",
        "phonk",
        "drill",
        "cinematic trap",
        "future bass",
        "lo-fi",
        "melodic dubstep",
    ]

    MOODS = [
        "dark",
        "aggressive",
        "melancholic",
        "epic",
        "mysterious",
        "emotional",
        "powerful",
        "energetic",
        "luxury",
        "sunset",
        "underground",
        "euphoric",
    ]

    # real club ranges
    BPM_RANGES = {
        "dark trap": (135, 150),
        "phonk": (130, 145),
        "drill": (138, 146),
        "cinematic trap": (120, 140),
        "dark techno": (128, 136),
        "future bass": (145, 160),
        "lo-fi": (70, 90),
        "melodic dubstep": (140, 150),
        "deep house": (118, 124),
        "tech house": (122, 128),
        "melodic house": (120, 126),
        "progressive house": (124, 130),
        "afro house": (118, 124),
        "festival house": (126, 132),
    }

    # moods that feel natural with tech house / dark luxury channels
    HOUSE_MOODS = ["dark", "underground", "luxury", "mysterious", "energetic", "euphoric", "powerful"]

    MIN_HISTORY_FOR_WEIGHTING = 15
    EXPLORATION_RATE = 0.22

    def _weighted_choice(self) -> tuple[str, str] | None:
        try:
            from ai.learning import genre_mood_scores, load_history
        except ImportError:
            return None

        history = load_history()
        if len(history) < self.MIN_HISTORY_FOR_WEIGHTING:
            return None

        if random.random() < self.EXPLORATION_RATE:
            return None

        scores = genre_mood_scores()
        if not scores:
            return None

        pairs = list(scores.keys())
        weights = [max(1.0, score) for score in scores.values()]
        chosen = random.choices(pairs, weights=weights, k=1)[0]
        return chosen

    def execute(self, project):
        settings = project.setdefault("director", {})

        genre = project.get("genre")
        mood = project.get("mood")

        if not genre and not mood:
            weighted = self._weighted_choice()
            if weighted:
                genre, mood = weighted
                info(f"DIRECTOR -> using learned preference: {genre} / {mood}")

        genre = (genre or random.choice(self.GENRES)).lower().strip()
        mood = (mood or random.choice(self.MOODS)).lower().strip()

        # if someone forced a house genre but left mood empty / trap-ish,
        # bias mood toward the dark-luxury set that matches the reference channel
        if genre in ("tech house", "deep house", "melodic house", "progressive house",
                     "afro house", "festival house", "dark techno"):
            if mood not in self.HOUSE_MOODS:
                mood = random.choice(self.HOUSE_MOODS)

        bpm = project.get("bpm")
        if not bpm:
            lo, hi = self.BPM_RANGES.get(genre, (122, 128))
            bpm = random.randint(lo, hi)

        project["genre"] = genre
        project["mood"] = mood
        project["bpm"] = bpm

        settings["genre"] = genre
        settings["mood"] = mood
        settings["bpm"] = bpm
        settings["duration"] = project.get("duration", 120)

        info(f"DIRECTOR -> {genre} | {mood} | {bpm} BPM")
        return project


music_director_engine = MusicDirectorEngine()
registry.register("music_director_engine", music_director_engine)