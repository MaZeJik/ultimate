"""
UltimateStudio
ai/music_brain.py

High-level musical profile written onto the project.
Tech House family fully specified so downstream engines
(swing, groove, humanizer, master target LUFS) behave correctly.
"""

from __future__ import annotations

import random

from core.registry import registry
from core.logger import info


class MusicBrain:

    GENRES = {
        # trap
        "dark trap": {
            "bpm": (135, 150),
            "energy": 0.92,
            "scale": "minor",
            "swing": 0.12,
            "humanization": 0.82,
            "lufs": -8,
        },
        "phonk": {
            "bpm": (150, 170),
            "energy": 0.95,
            "scale": "minor",
            "swing": 0.18,
            "humanization": 0.80,
            "lufs": -8,
        },
        "drill": {
            "bpm": (138, 145),
            "energy": 0.90,
            "scale": "minor",
            "swing": 0.14,
            "humanization": 0.84,
            "lufs": -8,
        },
        # house / tech house
        "tech house": {
            "bpm": (122, 128),
            "energy": 0.82,
            "scale": "minor",
            "swing": 0.04,
            "humanization": 0.55,   # tighter, more machine feel
            "lufs": -7,
        },
        "deep house": {
            "bpm": (118, 124),
            "energy": 0.70,
            "scale": "minor",
            "swing": 0.06,
            "humanization": 0.60,
            "lufs": -8,
        },
        "melodic house": {
            "bpm": (120, 126),
            "energy": 0.75,
            "scale": "minor",
            "swing": 0.05,
            "humanization": 0.58,
            "lufs": -7,
        },
        "progressive house": {
            "bpm": (124, 130),
            "energy": 0.85,
            "scale": "minor",
            "swing": 0.03,
            "humanization": 0.50,
            "lufs": -7,
        },
        "afro house": {
            "bpm": (118, 124),
            "energy": 0.78,
            "scale": "minor",
            "swing": 0.08,
            "humanization": 0.65,
            "lufs": -8,
        },
        "festival house": {
            "bpm": (126, 132),
            "energy": 0.92,
            "scale": "minor",
            "swing": 0.02,
            "humanization": 0.48,
            "lufs": -6,
        },
        "dark techno": {
            "bpm": (128, 136),
            "energy": 0.88,
            "scale": "minor",
            "swing": 0.02,
            "humanization": 0.45,
            "lufs": -7,
        },
    }

    KEYS = [
        "C Minor",
        "D Minor",
        "E Minor",
        "F Minor",
        "F# Minor",
        "G Minor",
        "A Minor",
        "A# Minor",
        "B Minor",
    ]

    def execute(self, project):
        director = project.get("director", {})
        genre = (director.get("genre") or project.get("genre") or "tech house").lower()

        profile = self.GENRES.get(genre, self.GENRES.get("tech house", self.GENRES["dark trap"]))

        bpm = director.get("bpm") or project.get("bpm") or random.randint(*profile["bpm"])

        brain = {
            "genre": genre,
            "bpm": bpm,
            "scale": profile["scale"],
            "key": director.get("key") or project.get("key") or random.choice(self.KEYS),
            "energy": profile["energy"],
            "humanization": profile["humanization"],
            "swing": profile["swing"],
            "target_lufs": profile["lufs"],
            "sample_rate": 44100,
            "bit_depth": 24,
            "duration": director.get("duration", project.get("duration", 120)),
            "seed": random.randint(100000, 99999999),
        }

        project["music_brain"] = brain
        # keep top-level keys consistent
        project["bpm"] = bpm
        project["key"] = brain["key"]
        project["scale"] = brain["scale"]

        info(f"MUSIC BRAIN READY -> {genre} {bpm} BPM | swing={profile['swing']} lufs={profile['lufs']}")
        return project


music_brain = MusicBrain()
registry.register("music_brain", music_brain)