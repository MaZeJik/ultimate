"""
UltimateStudio
ai/composition_planner.py

Plans section structure from duration + BPM.

House / Tech House now get a proper club structure
(intro → build → drop → break → drop2 → outro) instead of the
old trap-oriented or overly simple plan.
"""

from __future__ import annotations

from core.registry import registry

# proportional weights must sum ~1.0
# (name, weight, energy)
TRAP_WEIGHTS = [
    ("intro", 0.10, 0.25),
    ("verse", 0.20, 0.45),
    ("build", 0.10, 0.70),
    ("drop", 0.20, 1.00),
    ("break", 0.10, 0.35),
    ("drop2", 0.20, 0.95),
    ("outro", 0.10, 0.20),
]

HOUSE_WEIGHTS = [
    ("intro", 0.12, 0.30),
    ("build", 0.15, 0.65),
    ("drop", 0.25, 1.00),
    ("break", 0.12, 0.40),
    ("drop2", 0.24, 0.95),
    ("outro", 0.12, 0.25),
]

SIMPLE_WEIGHTS = [
    ("intro", 0.15, 0.30),
    ("main", 0.65, 0.80),
    ("outro", 0.20, 0.30),
]

HOUSE_GENRES = {
    "tech house", "deep house", "melodic house", "progressive house",
    "afro house", "festival house", "dark techno", "techno", "minimal",
}


class CompositionPlanner:
    MIN_SECTION_BARS = 4

    def bars_for_duration(self, duration_sec: float, bpm: float) -> int:
        seconds_per_bar = (60.0 / bpm) * 4
        bars = round(duration_sec / seconds_per_bar / 4) * 4
        return max(16, bars)

    def distribute(self, weights: list[tuple[str, float, float]], total_bars: int) -> list[dict]:
        plan = []
        allocated = 0

        for i, (name, weight, energy) in enumerate(weights):
            if i == len(weights) - 1:
                bars = max(self.MIN_SECTION_BARS, total_bars - allocated)
            else:
                bars = max(self.MIN_SECTION_BARS, round(total_bars * weight / 4) * 4)
                allocated += bars
            plan.append({"section": name, "bars": bars, "energy": energy})

        return plan

    def execute(self, project):
        style = project.get("style_profile", {})
        bpm = style.get("bpm", project.get("bpm", 124))
        genre = str(style.get("genre", project.get("genre", "tech house"))).lower()
        duration = project.get("duration", 120)

        total_bars = self.bars_for_duration(duration, bpm)

        if genre in HOUSE_GENRES or "house" in genre or "techno" in genre:
            plan = self.distribute(HOUSE_WEIGHTS, total_bars)
        elif genre in ("dark trap", "phonk", "drill", "cinematic trap"):
            plan = self.distribute(TRAP_WEIGHTS, total_bars)
        else:
            plan = self.distribute(SIMPLE_WEIGHTS, total_bars)

        actual_bars = sum(x["bars"] for x in plan)
        actual_seconds = actual_bars * (60.0 / bpm) * 4

        project["composition_plan"] = {
            "genre": genre,
            "bpm": bpm,
            "sections": plan,
            "total_bars": actual_bars,
            "estimated_seconds": round(actual_seconds, 1),
        }

        return project


composition_planner = CompositionPlanner()
registry.register("composition_planner", composition_planner)