"""
UltimateStudio
ai/producer_brain.py

Builds per-section layer map + aggregate producer_brain dict that
instrument engines actually read.

House / Tech House gets club-aware layering:
  - intro: soft (no full kick wall, light atmosphere)
  - build: drums + bass come in
  - drop / drop2: full energy
  - break: strip back (no counter, lighter fx)
"""

from __future__ import annotations

from core.registry import registry


HOUSE_GENRES = {
    "tech house", "deep house", "melodic house", "progressive house",
    "afro house", "festival house", "dark techno", "techno", "minimal",
}


class ProducerBrain:

    def execute(self, project):
        composition_plan = project.get("composition_plan", {})
        sections = composition_plan.get("sections", [])
        genre = str(project.get("genre", "")).lower()
        is_house = genre in HOUSE_GENRES or "house" in genre or "techno" in genre

        layers = []

        for section in sections:
            e = float(section.get("energy", 0.5))
            name = section.get("section", "main")

            if is_house:
                state = {
                    "section": name,
                    "bars": section["bars"],
                    "drums": e > 0.30,
                    "bass": e > 0.30,
                    "synth": e > 0.40,
                    "piano": False,              # house rarely wants piano stabs by default
                    "counter": e > 0.70,
                    "atmosphere": True,
                    "fx": e > 0.50,
                    "automation": True,
                }
                if name == "intro":
                    state["drums"] = False
                    state["bass"] = False
                    state["synth"] = False
                    state["fx"] = False
                elif name == "build":
                    state["drums"] = True
                    state["bass"] = True
                    state["synth"] = e > 0.50
                    state["fx"] = True
                elif name in ("drop", "drop2", "main"):
                    state["drums"] = True
                    state["bass"] = True
                    state["synth"] = True
                    state["counter"] = True
                    state["fx"] = True
                elif name == "break":
                    state["drums"] = True
                    state["bass"] = False
                    state["synth"] = False
                    state["counter"] = False
                    state["fx"] = False
                elif name == "outro":
                    state["drums"] = e > 0.25
                    state["bass"] = False
                    state["synth"] = False
                    state["fx"] = False
            else:
                # trap / default
                state = {
                    "section": name,
                    "bars": section["bars"],
                    "drums": True,
                    "bass": e > 0.35,
                    "synth": e > 0.25,
                    "piano": e < 0.60,
                    "counter": e > 0.60,
                    "atmosphere": True,
                    "fx": e > 0.45,
                    "automation": True,
                }
                if name == "intro":
                    state["drums"] = False
                    state["bass"] = False
                elif name == "break":
                    state["counter"] = False
                elif name in ("drop", "drop2"):
                    state["counter"] = True
                    state["fx"] = True

            layers.append(state)

        project["producer_map"] = layers

        total_bars = composition_plan.get("total_bars")
        if not total_bars:
            total_bars = sum(s["bars"] for s in sections) if sections else 64

        avg_energy = (
            sum(s["energy"] for s in sections) / len(sections) if sections else 0.7
        )

        project["producer_brain"] = {
            "bpm": composition_plan.get("bpm", project.get("bpm", 124 if is_house else 140)),
            "bars": total_bars,
            "energy": avg_energy,
            "sections": sections,
            "genre": genre,
            "is_house": is_house,
        }

        return project


producer_brain = ProducerBrain()
registry.register("producer_brain", producer_brain)