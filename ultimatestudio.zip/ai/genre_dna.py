"""
UltimateStudio
ai/genre_dna.py

Genre DNA — production parameters that instrument engines actually read.
Expanded with full Tech House / House family so the pipeline can compete
with channels like Synapse Melodic (groovy four-on-floor, rolling bass,
tight hats, minimal swing, dark-luxury energy).
"""

from core.registry import registry
from core.logger import info


class GenreDNAEngine:

    DNA = {
        # ------------------------------------------------------------------
        # TRAP FAMILY (existing)
        # ------------------------------------------------------------------
        "dark trap": {
            "bpm": (135, 150),
            "key": "minor",
            "kick": "808",
            "snare": "trap",
            "hat": "triplet",
            "bass": "808",
            "melody": "dark",
            "pad": True,
            "reverb": 0.25,
            "stereo": 1.10,
            "swing": 0.12,
            "energy": 0.90,
        },
        "phonk": {
            "bpm": (145, 170),
            "key": "minor",
            "kick": "phonk",
            "snare": "clap",
            "hat": "fast",
            "bass": "cowbell",
            "melody": "bell",
            "pad": False,
            "reverb": 0.18,
            "stereo": 1.00,
            "swing": 0.15,
            "energy": 0.95,
        },
        "drill": {
            "bpm": (138, 148),
            "key": "minor",
            "kick": "drill",
            "snare": "drill",
            "hat": "roll",
            "bass": "808",
            "melody": "piano",
            "pad": False,
            "reverb": 0.20,
            "stereo": 1.05,
            "swing": 0.10,
            "energy": 0.88,
        },

        # ------------------------------------------------------------------
        # TECH HOUSE / HOUSE FAMILY  (Synapse Melodic competitive set)
        # ------------------------------------------------------------------
        "tech house": {
            "bpm": (122, 128),
            "key": "minor",
            "kick": "four_on_floor",
            "snare": "clap_light",
            "hat": "closed_offbeat",
            "bass": "rolling",
            "melody": "pluck_minimal",
            "pad": True,
            "reverb": 0.22,
            "stereo": 1.15,
            "swing": 0.04,          # almost straight — classic tech house
            "energy": 0.82,
            "groove": 0.55,         # high groove priority
            "acid": 0.35,           # chance of 303-ish movement
        },
        "deep house": {
            "bpm": (118, 124),
            "key": "minor",
            "kick": "four_on_floor",
            "snare": "clap_soft",
            "hat": "closed_offbeat",
            "bass": "deep_sub",
            "melody": "chord_stab",
            "pad": True,
            "reverb": 0.32,
            "stereo": 1.20,
            "swing": 0.06,
            "energy": 0.70,
            "groove": 0.60,
            "acid": 0.10,
        },
        "melodic house": {
            "bpm": (120, 126),
            "key": "minor",
            "kick": "four_on_floor",
            "snare": "clap_light",
            "hat": "closed_offbeat",
            "bass": "rolling",
            "melody": "arpeggio",
            "pad": True,
            "reverb": 0.28,
            "stereo": 1.25,
            "swing": 0.05,
            "energy": 0.75,
            "groove": 0.50,
            "acid": 0.15,
        },
        "progressive house": {
            "bpm": (124, 130),
            "key": "minor",
            "kick": "four_on_floor",
            "snare": "clap",
            "hat": "closed_offbeat",
            "bass": "rolling",
            "melody": "lead_uplifting",
            "pad": True,
            "reverb": 0.30,
            "stereo": 1.30,
            "swing": 0.03,
            "energy": 0.85,
            "groove": 0.45,
            "acid": 0.20,
        },
        "afro house": {
            "bpm": (118, 124),
            "key": "minor",
            "kick": "four_on_floor",
            "snare": "perc",
            "hat": "shaker",
            "bass": "deep_sub",
            "melody": "perc_melody",
            "pad": True,
            "reverb": 0.26,
            "stereo": 1.18,
            "swing": 0.08,
            "energy": 0.78,
            "groove": 0.70,
            "acid": 0.05,
        },
        "festival house": {
            "bpm": (126, 132),
            "key": "minor",
            "kick": "four_on_floor",
            "snare": "clap",
            "hat": "open_hat",
            "bass": "rolling",
            "melody": "big_lead",
            "pad": True,
            "reverb": 0.24,
            "stereo": 1.35,
            "swing": 0.02,
            "energy": 0.92,
            "groove": 0.40,
            "acid": 0.25,
        },
        "dark techno": {
            "bpm": (128, 136),
            "key": "minor",
            "kick": "techno",
            "snare": "rim",
            "hat": "closed_straight",
            "bass": "reese",
            "melody": "industrial",
            "pad": False,
            "reverb": 0.18,
            "stereo": 1.05,
            "swing": 0.02,
            "energy": 0.88,
            "groove": 0.30,
            "acid": 0.40,
        },
    }

    # simple aliases so "techhouse", "tech-house" etc. still resolve
    ALIASES = {
        "techhouse": "tech house",
        "tech-house": "tech house",
        "deephouse": "deep house",
        "deep-house": "deep house",
        "melodichouse": "melodic house",
        "progressivehouse": "progressive house",
        "afrohouse": "afro house",
        "festivalhouse": "festival house",
        "darktechno": "dark techno",
        "techno": "dark techno",
        "minimal": "tech house",
        "minimal tech": "tech house",
        "acid tech house": "tech house",
        "groovy tech house": "tech house",
    }

    def execute(self, project):
        raw = project.get("genre", "dark trap")
        genre = str(raw).lower().strip()
        genre = self.ALIASES.get(genre, genre)

        dna = self.DNA.get(genre, self.DNA["dark trap"]).copy()
        project["genre_dna"] = dna
        # also keep a clean canonical name so later engines don't fight aliases
        project["genre"] = genre

        info(f"GENRE DNA READY -> {genre} | bpm={dna['bpm']} energy={dna['energy']}")
        return project


genre_dna = GenreDNAEngine()
registry.register("genre_dna", genre_dna)