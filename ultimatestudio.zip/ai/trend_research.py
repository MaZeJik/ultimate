"""
UltimateStudio
ai/trend_research.py

A real (not simulated) competitor/keyword research pass, in the
spirit of TubeBuddy/VidIQ: uses the YouTube Data API's search
endpoint to find currently-performing videos for a genre, and pulls
their tags via videos.list -- a genuine "what's actually tagged on
videos ranking for this search term right now" signal, which is
exactly what those tools are built on top of.

Reuses the same OAuth credentials as ai/youtube_publisher.py (no
separate setup needed if you've already configured YouTube
publishing). Read-only: this never modifies anything on YouTube.
"""

from __future__ import annotations

from collections import Counter

from core.logger import info, warning


class TrendResearchError(Exception):
    pass


class TrendResearch:
    def __init__(self):
        self._service = None

    def _get_service(self):
        if self._service is not None:
            return self._service

        try:
            from ai.youtube_publisher import youtube_publisher
        except ImportError as exc:
            raise TrendResearchError("ai/youtube_publisher.py not available") from exc

        try:
            self._service = youtube_publisher._get_service()
        except Exception as exc:  # noqa: BLE001 - surfaced as TrendResearchError for a consistent interface
            raise TrendResearchError(f"couldn't authenticate: {exc}") from exc

        return self._service

    def top_videos_for_query(self, query: str, max_results: int = 15) -> list[dict]:
        """Real YouTube search results for a query, ordered by relevance/view count."""
        service = self._get_service()

        try:
            search_response = (
                service.search()
                .list(q=query, part="id,snippet", type="video", maxResults=max_results, order="viewCount")
                .execute()
            )
        except Exception as exc:  # noqa: BLE001 - any API failure just means "no trend data this run"
            warning(f"TREND RESEARCH -> search failed for '{query}': {exc}")
            return []

        video_ids = [item["id"]["videoId"] for item in search_response.get("items", [])]
        if not video_ids:
            return []

        try:
            details_response = service.videos().list(part="snippet,statistics", id=",".join(video_ids)).execute()
        except Exception as exc:  # noqa: BLE001
            warning(f"TREND RESEARCH -> video details failed: {exc}")
            return []

        results = []
        for item in details_response.get("items", []):
            snippet = item.get("snippet", {})
            stats = item.get("statistics", {})
            results.append(
                {
                    "title": snippet.get("title", ""),
                    "tags": snippet.get("tags", []),
                    "views": int(stats.get("viewCount", 0)),
                    "channel": snippet.get("channelTitle", ""),
                }
            )

        return results

    def trending_tags(self, genre: str, top_n: int = 25) -> list[str]:
        """
        The actual tags used by currently top-performing videos for
        this genre's "type beat" search -- a real competitive signal,
        not a guess. Returns [] on any failure (no API access, no
        results) so the caller can fall back to the existing static
        tag pool.
        """
        query = f"{genre} type beat"
        videos = self.top_videos_for_query(query)

        if not videos:
            return []

        tag_counter: Counter[str] = Counter()
        for video in videos:
            for tag in video.get("tags", []):
                tag_counter[tag.lower()] += 1

        top_tags = [tag for tag, _count in tag_counter.most_common(top_n)]
        info(f"TREND RESEARCH -> found {len(top_tags)} trending tag(s) for '{query}' from {len(videos)} video(s)")
        return top_tags

    def competitor_summary(self, genre: str) -> dict | None:
        """A quick competitive snapshot: average views, top channel names, common title patterns."""
        videos = self.top_videos_for_query(f"{genre} type beat")
        if not videos:
            return None

        avg_views = sum(v["views"] for v in videos) / len(videos)
        top_channels = Counter(v["channel"] for v in videos).most_common(5)

        return {
            "genre": genre,
            "sample_size": len(videos),
            "average_views": int(avg_views),
            "top_channels": [c for c, _ in top_channels],
        }


trend_research = TrendResearch()
