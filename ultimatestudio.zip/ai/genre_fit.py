from core.registry import registry
from core.logger import info


class GenreFitEngine:

    def execute(self, project):

        dna = project.get("genre_dna", {})
        producer = project.get("producer_brain", {})

        if not dna or not producer:

            info("GENRE FIT -> missing data")

            project["genre_fit"] = {}

            return project

        score = 100.0

        bpm = producer.get("bpm", 140)
        bpm_min, bpm_max = dna.get("bpm", (120, 160))

        if bpm < bpm_min:
            score -= (bpm_min - bpm) * 0.5

        elif bpm > bpm_max:
            score -= (bpm - bpm_max) * 0.5

        if producer.get("scale", "minor") != dna.get("key", "minor"):
            score -= 10

        energy = producer.get("energy", 0.8)
        target_energy = dna.get("energy", 0.8)

        score -= abs(target_energy - energy) * 40

        swing = producer.get("swing", 0.12)
        target_swing = dna.get("swing", 0.12)

        score -= abs(target_swing - swing) * 60

        stereo = producer.get("stereo_width", 1.0)
        target_stereo = dna.get("stereo", 1.0)

        score -= abs(target_stereo - stereo) * 20

        score = max(0.0, min(100.0, round(score, 2)))

        project["genre_fit"] = {

            "genre": producer.get("genre"),

            "score": score,

            "status": (
                "excellent"
                if score >= 90 else
                "good"
                if score >= 75 else
                "average"
                if score >= 60 else
                "poor"
            )

        }

        info(
            f"GENRE FIT -> {score:.2f}"
        )

        return project


genre_fit_engine = GenreFitEngine()

registry.register(
    "genre_fit_engine",
    genre_fit_engine
)