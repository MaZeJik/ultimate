"""
UltimateStudio
ai/genre_selector.py
"""

from __future__ import annotations

from ai.genre_profiles import GENRE_LIBRARY


class GenreSelector:

    DEFAULT = "dark trap"

    @classmethod
    def select(cls, genre: str) -> dict:

        if not genre:
            return GENRE_LIBRARY[cls.DEFAULT]

        genre = genre.strip().lower()

        return GENRE_LIBRARY.get(
            genre,
            GENRE_LIBRARY[cls.DEFAULT]
        )


genre_selector = GenreSelector()