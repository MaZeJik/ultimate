"""
UltimateStudio
watchdog.py

Runs batch_run.py as a subprocess and restarts it automatically if
the whole process dies (crash, OOM kill, etc.) -- something internal
try/except blocks in the pipeline can't protect against, since those
only work while the interpreter is still running. This is the
external supervisor layer for actual 24/7 unattended operation.

Usage:
    python watchdog.py --count 5 --publish
    (any arguments are passed straight through to batch_run.py)

Stops restarting (gives up) if the process crashes MAX_CRASHES times
within CRASH_WINDOW_SEC -- a fast crash loop almost always means a
real configuration problem, not a transient failure, and restarting
forever would just spam retries without ever fixing anything.
"""

from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

from core.logger import error, info, warning

MAX_CRASHES = 5
CRASH_WINDOW_SEC = 600  # 10 minutes
RESTART_DELAY_SEC = 15

BATCH_RUN_SCRIPT = Path(__file__).resolve().parent / "batch_run.py"


def main() -> None:
    args = sys.argv[1:]
    crash_times: list[float] = []

    info(f"WATCHDOG -> starting supervised run of batch_run.py {' '.join(args)}")

    while True:
        start = time.time()
        info("WATCHDOG -> launching batch_run.py")

        try:
            result = subprocess.run([sys.executable, str(BATCH_RUN_SCRIPT), *args])
        except KeyboardInterrupt:
            info("WATCHDOG -> stopped by user")
            return

        if result.returncode == 0:
            info("WATCHDOG -> batch_run.py finished normally, exiting")
            return

        warning(f"WATCHDOG -> batch_run.py exited with code {result.returncode} (crashed)")

        now = time.time()
        crash_times.append(now)
        crash_times = [t for t in crash_times if now - t < CRASH_WINDOW_SEC]

        if len(crash_times) >= MAX_CRASHES:
            error(
                f"WATCHDOG -> {len(crash_times)} crashes within {CRASH_WINDOW_SEC}s -- "
                "this looks like a real configuration problem, not a transient failure. "
                "Giving up rather than crash-looping forever. Check the log above for the actual error."
            )
            sys.exit(1)

        info(f"WATCHDOG -> restarting in {RESTART_DELAY_SEC}s...")
        time.sleep(RESTART_DELAY_SEC)


if __name__ == "__main__":
    main()
